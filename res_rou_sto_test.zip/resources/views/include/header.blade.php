<header class="header-wrap style2">
         <div class="header-bottom">
            <div class="container">
               <nav class="navbar navbar-expand-md navbar-light">
                  <a class="navbar-brand" href="{{route('home.index')}}">
                  <!-- <img class="logo-light" src="assets/img/dreams.png" alt="logo"> -->
                  <img class="logo-dark" src="{{url('front-assets/img/new/logo-newdream21.png')}}" alt="logo">
                  </a>
                  <div class="collapse navbar-collapse main-menu-wrap" id="navbarSupportedContent">
                     <div class="menu-close xl-none">
                        <a href="javascript:void(0)"> <i class="ri-close-line"></i></a>
                     </div>

                     <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                           <a href="{{route('home.index')}}" class="nav-link">
                           Home
                           </a>
                        </li>
                        <li class="nav-item">
                           <a href="{{route('home.about')}}" class="nav-link">
                           About Us
                           </a>
                        </li>
                        
                        <li class="nav-item has-dropdown">
                           <span class="menu-expand"><i class="ri-arrow-down-s-line"></i></span>
                           <a href="#" class="nav-link">
                           Products
                           <i class="ri-arrow-down-s-line"></i>
                           </a>
                           <?php 

                                $services = DB::table('services')

                                ->join('categories', 'services.category', '=', 'categories.id')

                                ->select('services.*', 'categories.title as category_title')
                                ->where('status',1)
                                ->groupBy('categories.title')
                                ->orderBy('services.id','asc')
                                ->get();

                                ?>
                           <ul class="dropdown-menu" style="display: none;">
                           <?php foreach($services as $service): ?>
                              <?php if($service->category_title): 
                                
                                 $currentUrl = url()->current();
                                 $serviceUrl = route('home.category', ['segment' => str_replace(' ', '-', $service->category_title)]);
                              ?>
                             <li class="nav-item">
                                 <a href="{{$serviceUrl}}" class="nav-link {{ $currentUrl == $serviceUrl ? 'active' : '' }}">{{ $service->category_title }}</a>
                              </li>
                              <?php endif; ?>
                              <?php endforeach; ?>
                           </ul>
                        </li>
                        <li class="nav-item">
                           <a href="{{route('home.pricing')}}" class="nav-link">
                           Pricing
                           </a>
                        </li>
                        <li class="nav-item">
                           <a href="{{route('home.payment')}}" class="nav-link">
                           Payment
                           </a>
                        </li>
                        <li class="nav-item">
                           <a href="{{route('home.career')}}" class="nav-link">
                           Career
                           </a>
                        </li>
                        <li class="nav-item">
                           <a href="{{route('home.contact')}}" class="nav-link">
                           Contact Us
                           </a>
                        </li>
                        <li class="nav-item has-dropdown">
                           <span class="menu-expand"><i class="ri-arrow-down-s-line"></i></span>
                           <a href="#" class="nav-link">
                           Other
                           <i class="ri-arrow-down-s-line"></i>
                           </a>
                           <ul class="dropdown-menu" style="display: none;">
                              <li class="nav-item">
                                 <a href="{{route('home.kyc')}}" class="nav-link">KYC & Service Agreement</a>
                              </li>
                              <li class="nav-item">
                                 <a href="{{route('home.refund')}}" class="nav-link">Refund Policy</a>
                              </li>
                              <li class="nav-item">
                                 <a href="{{route('home.disclaimer')}}" class="nav-link">Disclaimer</a>
                              </li>
                              <li class="nav-item">
                                 <a href="{{route('home.privacy')}}" class="nav-link">Privacy Policy</a>
                              </li>
                              <li class="nav-item">
                                 <a href="{{route('home.terms')}}" class="nav-link">Term & Conditions</a>
                              </li>
                              <li class="nav-item">
                                 <a href="{{route('home.investor')}}" class="nav-link">Investor Charter</a>
                              </li>
                              <li class="nav-item">
                                 <a href="{{route('home.complaint')}}" class="nav-link">Complaint Data</a>
                              </li>
                              <li class="nav-item">
                                 <a href="{{route('home.disclosure')}}" class="nav-link">Disclosure</a>
                              </li>
                              <li class="nav-item">
                                 <a href="{{route('home.grievance')}}" class="nav-link">Grievance Redressal Process</a>
                              </li>
                              <li class="nav-item">
                                 <a href="{{route('home.faq')}}" class="nav-link">FAQs</a>
                              </li>
                              <li class="nav-item">
                                 <a href="{{route('home.RegulatoryInformation')}}" class="nav-link">Regulatory Information</a>
                              </li>
                              <li class="nav-item">
                                 <a href="{{route('home.StandardWarning')}}" class="nav-link">Standard Warning</a>
                              </li>
                           </ul>
                        </li>
                     </ul>
                     <div class="others-options  lg-none">
                        <div class="header-btn lg-none">
                           <a href="{{route('home.contact')}}" class="btn style1">Enquiry Now</a>
                        </div>
                     </div>
                  </div>
               </nav>
               <div class="mobile-bar-wrap">
                  <div class="mobile-sidebar">
                     <i class="ri-menu-4-line"></i>
                  </div>
                  <button class="searchbtn xl-none" type="button">
                  <i class="flaticon-search"></i>
                  </button>
                  <div class="mobile-menu xl-none">
                     <a href="javascript:void(0)"><i class="ri-menu-line"></i></a>
                  </div>
               </div>
            </div>
         </div>
      </header>