@extends('admin.layout.app')
@section('content')
<div class="page-wrapper" style="min-height: 366px;">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-xl-12">

                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Add {{$title}}</h3>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="bank-inner-details">
                            <div class="row">
                                <div class="col-lg-12 col-md-12">
                                    <form id="formSubmit" action="{{ route('admin.gamerate.store')}}" method="post" enctype="multipart/form-data">
                                        @csrf
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                  <label>Play List<span class="login-danger">*</span></label>
                                                  <div>
                                                    <select class="form-control " name="play" id="play">
                                                   <option>Select Play </option>
                                                    @foreach($plays as $play)
                                                    <option value="{{ $play->id }}">{{$play->title}}</option>
                                                    @endforeach
                                                </select>
                                                  </div>
                                                  @error('play')
                                                      <p style="color:red;">{{ $message }}</p>
                                                  @enderror
                                              </div>
                                          </div>
                                        <div class="col-lg-12 col-md-12">
                                              <div class="form-group ">
                                                 <label>Title<span class="text-danger">*</span></label>
                                                 <input type="text" name="title" class="form-control" id="title" value="{{ old('title') }}">
                                              </div>
                                                @error('title')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                        <div class="col-lg-12 col-md-12">
                                              <div class="form-group ">
                                                 <label>Unit<span class="text-danger">*</span></label>
                                                 <input type="number" name="unit" class="form-control" id="unit" value="{{ old('unit') }}">
                                              </div>
                                                @error('unit')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                        <div class="col-lg-12 col-md-12">
                                              <div class="form-group ">
                                                 <label>Rate<span class="text-danger">*</span></label>
                                                 <input type="number" name="rate" class="form-control" id="rate" value="{{ old('rate') }}">
                                              </div>
                                                @error('rate')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                        </div>
                                        <div class="bank-details-btn ">
                                            <button type="submit" class="btn bank-cancel-btn me-2">Add {{$title}}</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection