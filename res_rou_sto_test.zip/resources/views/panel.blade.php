<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indore Bazar</title>
    <meta name="description" content="We Provide the fastest updated kalyan chart,our kalyan chart has all old 2018 2019 kalyan matka jodi records, check out our kalyan chart now.">
    <link rel="stylesheet" href="{{url('front-assets/style.css')}}">
    <link rel="stylesheet" href="https://storage.googleapis.com/sattamatka-cdn-bucket/index_files/bootstrap.min.css">
    <script data-cfasync="false" src="{{url('tbutton.js')}}"></script>

    <style>
        /* Base styles */
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: #000;
            color: #fff;
            font-size: 16px;
            line-height: 1.5;
            margin: 0;
            padding: 0;
        }

        /* Header styles */
        .header {
            text-align: center;
            padding: 20px;
        }

        /* Table styles */
        table {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            background: #fff;
            border-collapse: collapse;
            color: #000;
        }

        th, td {
            padding: 10px;
            text-align: center;
            /*border: 1px solid #ddd;*/
        }

        th {
            background: #1b2a49;
            color: #fff;
        }

        /* Navigation buttons */
        .nav-buttons {
            text-align: center;
            padding: 20px;
        }

        .nav-buttons a {
            display: inline-block;
            padding: 10px 20px;
            background: #0062cc;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin: 5px;
        }

        /* Footer styles */
        .footer-last {
            background: #1b2a49;
            padding: 20px;
            text-align: center;
            color: #fff;
        }

        .footer-last h4 {
            margin: 0 0 15px;
        }

        .footer-last .btn {
            margin: 5px;
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            body {
                font-size: 14px;
            }

            table {
                font-size: 12px;
            }

            th, td {
                padding: 5px;
            }
        }

        @media (max-width: 480px) {
            body {
                font-size: 12px;
            }

            table {
                font-size: 10px;
            }

            .nav-buttons a {
                display: block;
                margin: 10px auto;
                max-width: 200px;
            }
        }
        .text-danger {
    color: red;
}
    </style>
</head>

<body>
    <div class="header">
         <a href="{{url('/')}}">
             <img class="logo ptb-10 mb-0" src="{{url('front-assets/images/logo.jpg')}}" alt="SattaMatka">
        </a>
    
    </div>

    <div class="nav-buttons">
        <a href="javascript:void(0);" onclick="bottomFunction()">Go To Bottom</a>
    </div>

    <div class="main-content">
        <div class="table-container">
            <h2 class="text-center">TIME BAZAR</h2>
<table>
    <thead>
        <tr>
            <th>Week Range</th>
            <th colspan="3">Monday</th>
            <th colspan="3">Tuesday</th>
            <th colspan="3">Wednesday</th>
            <th colspan="3">Thursday</th>
            <th colspan="3">Friday</th>
            <th colspan="3">Saturday</th>
            <th colspan="3">Sunday</th>
        </tr>
       
    </thead>
    <tbody>
        @php
            use Carbon\Carbon;
            $weeks = [];

            foreach ($results as $result) {
                $date = $result->created_at ? Carbon::parse($result->created_at) : null;
                if ($date) {
                    $week = $date->weekOfYear;
                    $dayOfWeek = $date->dayOfWeekIso - 1; // ISO week starts on Monday

                    $resultpatta1 = $result->patta1 ? array_sum(str_split($result->patta1)) : null;
                    $digitSumPatta1 = $resultpatta1 !== null ? $resultpatta1 % 10 : '*';

                    $resultpatta2 = $result->patta2 ? array_sum(str_split($result->patta2)) : null;
                    $digitSumPatta2 = $resultpatta2 !== null ? $resultpatta2 % 10 : '*';

                    $weeks[$week][$dayOfWeek][] = [
                        'patta1' => $digitSumPatta1,
                        'patta2' => $digitSumPatta2,
                        'original_patta1' => $result->patta1,
                        'original_patta2' => $result->patta2,
                        'date' => $date,
                    ];
                }
            }
        @endphp

        @foreach ($weeks as $week => $weekData)
            @php
                $startOfWeek = Carbon::now()->setISODate(Carbon::now()->year, $week)->startOfWeek();
                $endOfWeek = $startOfWeek->copy()->endOfWeek();
                $weekRange = $startOfWeek->format('Y-m-d') . '<br>to<br>' . $endOfWeek->format('Y-m-d');
                $maxEntries = max(array_map('count', $weekData));
            @endphp

            @for ($entry = 0; $entry < $maxEntries; $entry++)
                <tr>
                    <td>{!! $weekRange !!}</td>
                    @for ($day = 0; $day < 7; $day++)
                        @php
                            $dayData = $weekData[$day][$entry] ?? [
                                'original_patta1' => '*',
                                'original_patta2' => '*',
                                'patta1' => '*',
                                'patta2' => '*',
                            ];
                            $original_patta1 = is_string($dayData['original_patta1']) ? str_split($dayData['original_patta1']) : ['*', '*', '*'];
                            $original_patta2 = is_string($dayData['original_patta2']) ? str_split($dayData['original_patta2']) : ['*', '*', '*'];
                        @endphp

                        <td>
                            {{ $original_patta1[0] ?? '*' }}<br>
                            {{ $original_patta1[1] ?? '*' }}<br>
                            {{ $original_patta1[2] ?? '*' }}
                        </td>
                       <td>
                            @php
                                $combinedValue = ($dayData['patta1'] ?? '*') . ($dayData['patta2'] ?? '*');
                                $highlightValues = ['00', '05', '11', '16', '22', '27', '33', '38', '44', '49', '50', '55', '61', '66', '72', '77', '83', '88', '94', '99', '**'];
                                $isHighlighted = in_array($combinedValue, $highlightValues);
                            @endphp
                            <span class="normal {{ $isHighlighted ? 'text-danger' : '' }}">
                                {{ $combinedValue }}
                            </span>
                        </td>
                        <td>
                            {{ $original_patta2[0] ?? '*' }}<br>
                            {{ $original_patta2[1] ?? '*' }}<br>
                            {{ $original_patta2[2] ?? '*' }}
                        </td>
                    @endfor
                </tr>
            @endfor
        @endforeach
    </tbody>
</table>

        </div>
    </div>

    <div class="nav-buttons">
        <a href="javascript:void(0);" onclick="topFunction()">Go To Top</a>
    </div>

    <footer class="footer-last">
        <h4>
            AD Boss Satta Matka<br>
            ALL RIGHTS RESERVED<br>
            (2024-2025)<br>
            CONTACT ADMIN<br>
            ***
        </h4>
         <div class="d-flex justify-content-center">
                <button class="btn btn-primary my-btnn-l ftr-btn" style="background:#0000;">
                    <a href="javascript:history.go(-1)" style="color:white;">BACK</a>
                </button>
                <button class="btn btn-primary btn-orange my-btnn-l ftr-btn" style="background:red;">
                    <a href="{{ url('/') }}" style="color:white;">HOME</a>
                </button>
            </div>
      
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>