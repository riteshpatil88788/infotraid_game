<?php

namespace App\Http\Controllers\SubAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\Playlist;

class PlayListController extends Controller
{
 
    public function index()
    {
        $data['matkaresults'] = DB::table('matka_results')->orderBy('id','desc')->groupBy('title')->get();
        $data['playlists'] = DB::table('play_lists')->orderBy('id','desc')->get();
        $data['title'] = "Play List";
        return view('subadmin.play-list.index',$data);
    }

    public function create(){
        $data['title'] = "Play List";
        $data['matkaresults'] = DB::table('matka_results')->orderBy('id','desc')->groupBy('title')->get();
        $data['plays'] = DB::table('plays')->orderBy('id','desc')->get();

        return view('subadmin.play-list.create',$data);
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|unique:play_lists,title',
            'play' => 'required|array',  // Validate that 'play' is an array
            'play.*' => 'string',         // Validate each item in the play array is a string
        ]);
    
        $PlayList = new PlayList;
    
        $PlayList->title = $request->title;
        $PlayList->play = implode(',', $request->play); // Convert the play array to a comma-separated string
        $PlayList->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $PlayList->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;
        $PlayList->save();
    
        session()->flash('success', 'Play List has been created !!');
        return redirect()->route('subadmin.playlist.index');
    }
    

    public function edit($id){
        $data['playlist'] = DB::table('play_lists')->where('id',$id)->first();
        $data['plays'] = DB::table('plays')->orderBy('id','desc')->get();
        $data['matkaresults'] = DB::table('matka_results')->orderBy('id','desc')->groupBy('title')->get();
        $data['title'] = "Play List";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('subadmin.play-list.edit',$data);
    }

    public function update(Request $request)
    {
        //  dd($request->all());
        $request->validate([
            'title' => 'required',
            'play' => 'required',
           
        ]);
        //  echo "<pre>";print_r($request->all());die;
        $PlayList = PlayList::find($request->id);
        $PlayList->title = $request->title;
        $PlayList->play = implode(',', $request->play);
        $PlayList->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $PlayList->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;
        $PlayList->save();
        // dd($user->toArray());
        session()->flash('success', 'Play List has been Update !!');
        return redirect()->route('subadmin.playlist.index');
    }

    public function destroy($id){
       
       
        $playlist = PlayList::find($id);
     
        $playlist->delete();
        session()->flash('success', 'Play Lists has been Deleted !!');
        return redirect()->route('subadmin.playlist.index');
    }

    
}
