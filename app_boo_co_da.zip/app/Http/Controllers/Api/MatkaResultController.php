<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\{MatkaResult,Result};
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class MatkaResultController extends Controller
{
 
    public function index()
    {
      
         $data['title'] = 'Matka Result';
         $matkaresults = DB::table('matka_results')->select('title','firsttime','lasttime')->groupBy('title')->orderBy('id','desc')->get()->toArray();
         $matkaresults = array_map(function ($mr) {
         $mr->firsttime = date('h:i:s', strtotime($mr->firsttime)); // Convert to 12-hour format
         $mr->lasttime = date('h:i:s', strtotime($mr->lasttime));   // Convert to 12-hour format
          return $mr;
         }, $matkaresults);
        $matkaresults = collect($matkaresults);
        $data['matkaresults'] = $matkaresults;
        if (!$data['matkaresults']) {
            return response()->json(['status' => false, 'data' => [] ,'message' => 'Record not found']);
        }
        return response()->json(['status' => true, 'data' => $data , 'message' => 'Record found']);
    }

    public function liveUpdate()
{
     
    
    $today = Carbon::today();
    $now = Carbon::now();
    $resultsData = []; // Initialize $resultsData to prevent errors if no data is found

    // Fetch unique titles and their records for today's date, grouped by title
    $matkaResults = MatkaResult::whereDate('created_at', $today)->get()->groupBy('title');
    
     if (empty($matkaresults)) {
         
            return response()->json(['status' => false, 'data' => [] ,'message' => 'Record not found']);
        }
    // Loop through each group of results by title
    foreach ($matkaResults as $title => $results) {

        // Fetch patta values and creation times for each title, sorted by created_at
        $matkaResultPatta = $results->pluck('patta_value', 'created_at');

        // Get the first and second patta values along with their creation timestamps
        $patta1 = $matkaResultPatta->first() ?? null;
        $patta1CreatedAt = $matkaResultPatta->keys()->first() ?? null;

        $patta2 = $matkaResultPatta->skip(1)->first() ?? null;
        $patta2CreatedAt = $matkaResultPatta->skip(1)->keys()->first() ?? null;

        $totalSum = $patta1 ? array_sum(str_split((string) $patta1)) : 0;
        $totalSum1 = $patta2 ? array_sum(str_split((string) $patta2)) : 0;

        // Calculate the last digits
        $lastDigit1 = $totalSum % 10;
        $lastDigit2 = $patta2 !== null ? ($totalSum1 % 10) : '';

        // Check visibility based on timing
        $showPatta1 = $patta1 && $now->diffInMinutes($patta1CreatedAt) <= 45;
        $showBoth = $patta2 && $now->diffInMinutes($patta2CreatedAt) <= 45;

        // Prepare data for each title
        $resultsData[] = [
            'title' => $title,
            'patta1' => $showPatta1 ? $patta1 : null,
            'digit1' => $showPatta1 ? $lastDigit1 : null,
            'patta2' => $showBoth ? $patta2 : null,
            'digit2' => $showBoth ? $lastDigit2 : null,
        ];
    }

    // Return the JSON response with structured data
    return response()->json(['status' => true, 'data' => $resultsData, 'message' => 'Record Successfully']);
}

public function homelist()
{
    $matkaresults = DB::table('matka_results')
        ->select('matka_results.*')
        ->whereIn('id', function ($query) {
            $query->select(DB::raw('MAX(id)'))
                  ->from('matka_results')
                  ->groupBy('title');
        })
        ->orderBy('created_at', 'asc')
        ->get();
        

    if ($matkaresults->isEmpty()) {
        return response()->json(['status' => false, 'data' => [], 'message' => 'Record not found']);
    }

    $resultsData = []; // Initialize an array to hold all results

    foreach ($matkaresults as $matkaresult) {
        $resultpatta = Result::where('matka_result_id', $matkaresult->id)
            ->orderBy('id', 'desc')
            ->select('patta1', 'patta2', 'matka_result_id')
            ->whereDate('created_at', date('Y-m-d'))->first();

        

        $digit1 = $resultpatta ? array_sum( str_split($resultpatta->patta1 ?? "0")) % 10 : "*";
        $digit2 = $resultpatta ? array_sum(str_split($resultpatta->patta2 ?? "0")) % 10 : "*";

        if(time() > strtotime($matkaresult->lasttime)){
            if(time() > strtotime($matkaresult->lasttime) && time() < strtotime("tomorrow midnight")){
               $gamebid = true;
            }else{
               $gamebid = false;  
            }
        }else{
              $gamebid = false;   
        }
        
        $digitstar = $resultpatta ? empty($resultpatta->patta2) ? "*" : $digit2 : "*";
        $resultsData[] = [
            'matka_result_id'=>$matkaresult->id,
            'title' => $matkaresult->title,
            'patta1' => $resultpatta ? $resultpatta->patta1 ?? "***" : "***",
            'digit1' => $digit1 ?? "*",
            'patta2' => $resultpatta ? $resultpatta->patta2 ?? "***" : "***",
            'digit2' => $digitstar ,
            'firsttime' => date('h:i:s', strtotime($matkaresult->firsttime)),
            'lasttime' => date('h:i:s', strtotime($matkaresult->lasttime)),
            'isclosed' => $gamebid,
            ];
    }

    return response()->json(['status' => true, 'data' => $resultsData, 'message' => 'Records fetched successfully']);
}



public function jodi(Request $request)
{
    
    $titlejodi = $request->title;
    $data = [];

    // Retrieve the date of the oldest record for the specified title
    $oldestDate = MatkaResult::where('title', $titlejodi)->oldest('created_at')->value('created_at');

    // If no data exists for the title, return a response with an empty data array
    if (!$oldestDate) {
        return response()->json(['status' => false, 'data' => [], 'message' => 'Record not found']);
    }

    // Start from the beginning of the week for the oldest date
    $startOfOldestWeek = Carbon::parse($oldestDate)->startOfWeek();
    $currentDate = Carbon::now();

    // Loop through each week from oldest date to current date
    while ($startOfOldestWeek->lte($currentDate)) {
        $weekData = []; // Stores daily data for the current week

        // Loop through each day (Monday to Sunday)
        for ($day = 0; $day < 7; $day++) {
            $date = $startOfOldestWeek->copy()->addDays($day)->format('Y-m-d');

            // Fetch all 'patta_value' entries for the specific title and date
            $matkaresultpatta = MatkaResult::whereDate('created_at', $date)
                ->where('title', $titlejodi)
                ->pluck('patta_value');

            $uniquePairs = []; // To store unique pairs for the current day

            // Iterate over 'patta_value' entries in pairs
            for ($i = 0; $i < count($matkaresultpatta); $i += 2) {
                $patta1 = $matkaresultpatta[$i] ?? null;
                $patta2 = $matkaresultpatta[$i + 1] ?? null;

                // Calculate the last digit of the sum for each 'patta' value
                $totalSum1 = $patta1 !== null ? array_sum(str_split((string) $patta1)) % 10 : null;
                $totalSum2 = $patta2 !== null ? array_sum(str_split((string) $patta2)) % 10 : null;

                // Generate the pair string
                $pair = trim($totalSum1 . ' ' . ($totalSum2 ?? ''));

                // Ensure the pair is unique for the day
                if ($pair && !in_array($pair, $uniquePairs)) {
                    $uniquePairs[] = $pair;
                }
            }

            // Store unique pairs for the specific day in the week's data
            $weekData[$date] = $uniquePairs;
        }

        // Add weekly data, using the week's start date as the key
        $data[$startOfOldestWeek->format('Y-m-d')] = $weekData;

        // Proceed to the next week
        $startOfOldestWeek->addWeek();
    }

    return response()->json(['status' => true, 'data' => $data,  'message' => 'Record Successfully']);
}

public function panel(Request $request)
{
    
    $titlejodi = $request->title;
    $data = [];

    // Get the oldest record's date for the given title
    $oldestDate = MatkaResult::where('title', $titlejodi)->oldest('created_at')->value('created_at');

    // If no data is found, return a JSON response with an empty data array
    if (!$oldestDate) {
        return response()->json(['status' => false, 'data' => [], 'message' => 'Record not found']);
    }

    // Start from the beginning of the oldest week's Monday
    $startOfOldestWeek = Carbon::parse($oldestDate)->startOfWeek();
    $currentDate = Carbon::now();

    // Loop through each week from oldest date to current date
    while ($startOfOldestWeek->lte($currentDate)) {
        $weekData = []; // To store data for each day of the current week

        // Loop through each day in the current week (Monday to Sunday)
        for ($day = 0; $day < 7; $day++) {
            $date = $startOfOldestWeek->copy()->addDays($day)->format('Y-m-d');

            // Fetch all 'patta_value' entries for the given title and date
            $matkaresultpatta = MatkaResult::whereDate('created_at', $date)
                ->where('title', $titlejodi)
                ->pluck('patta_value');

            $dayData = []; // To store data for each 'patta' entry

            // Iterate over 'patta_value' entries in pairs
            for ($i = 0; $i < count($matkaresultpatta); $i += 2) {
                $patta1 = $matkaresultpatta[$i] ?? null;
                $patta2 = $matkaresultpatta[$i + 1] ?? null;

                // Sum the digits for each 'patta' value and get the last digit
                $totalSum1 = $patta1 !== null ? array_sum(str_split((string) $patta1)) % 10 : null;
                $totalSum2 = $patta2 !== null ? array_sum(str_split((string) $patta2)) % 10 : null;

                // Generate the pair string and store `patta` values with unique pairs
                $pair = trim($totalSum1 . ' ' . ($totalSum2 ?? ''));
                $dayData[] = [
                    'patta1' => $patta1,
                    'lastDigit1' => $totalSum1,
                    'lastDigit2' => $totalSum2,
                    'patta2' => $patta2,
                    'pair' => $pair,
                ];
            }

            // Store all patta entries for the current day
            $weekData[$date] = $dayData;
        }

        // Add the current week's data to the main data array, with the start date as the key
        $data[$startOfOldestWeek->format('Y-m-d')] = $weekData;

        // Move to the next week
        $startOfOldestWeek->addWeek();
    }

    return response()->json(['status' => true, 'data' => $data, 'message' => 'Record Successfully']);
}

  public function timeTable()
  {
      $data =  MatkaResult::select('title','firsttime','lasttime')->groupBy('title')->get();
       if (!$data) {
        return response()->json(['status' => false, 'data' => [], 'message' => 'Record not found']);
    }
     return response()->json(['status' => true, 'data' => $data, 'message' => 'Record Successfully']);
    //   echo "<pre>";print_r($list->toArray());die;
    
  }

    
    
}
