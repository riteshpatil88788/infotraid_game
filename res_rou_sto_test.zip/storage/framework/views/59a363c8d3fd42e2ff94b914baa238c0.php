

<?php $__env->startSection('content'); ?>

<div class="login-wrapper">
<div class="container">
<div class="loginbox">
<div class="login-left">
<img class="img-fluid" src="<?php echo e(url('assets/img/realcloud_logo1.png')); ?>" alt="Logo">
</div>
<div class="login-right">
<div class="login-right-wrap">
<h1>Welcome to Admin</h1>

<h2>Sign in</h2>

 <?php if(session('error')): ?>
<div class="alert alert-danger">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<form action="<?php echo e(route('login.Adminlogin_functionality')); ?>" method="post">
    <?php echo csrf_field(); ?>
<div class="form-group">
<label>Email <span class="login-danger">*</span></label>
<input class="form-control" type="text" name="email">
<span class="profile-views"><i class="fas fa-user-circle"></i></span>

</div>
<div class="form-group">
<label>Password <span class="login-danger">*</span></label>
<input class="form-control pass-input" type="password" name="password">
<span class="profile-views feather-eye toggle-password"></span>

</div>

<div class="form-group">
<button class="btn btn-primary btn-block" type="submit">Login</button>
</div>
</form>


</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.loginapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>