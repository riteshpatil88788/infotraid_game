<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\HeaderDes;

class HeaderController extends Controller
{
 
    public function index(){
        
        $data['headers'] = DB::table('header_des')->where('id',1)->first();
        $data['title'] = "Header";
        if (!$data['headers']) {
            return response()->json(['status' => false,  'data' => [] ,'message' => 'Record not found']);
        }
        return response()->json(['status' => true, 'data' => $data, 'message' => 'Record Successfully']);
    }





    
}
