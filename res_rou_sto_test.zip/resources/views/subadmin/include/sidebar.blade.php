
<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="menu-title">
                    <span>Main Menu</span>
                </li>
                <li class="submenu">
                    <a href="#"><i class="feather-grid"></i> <span> Dashboard</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a href="{{route('subadmin.dashboard')}}" class="active"><i class="feather-grid"></i> <span>Dashboard</span></a></li>
                    </ul>
                </li>
                <li>
                <li class="">
                    <a href="{{route('subadmin.matkaresult.index')}}"><i class="fab fa-servicestack"></i> <span>Matka Result</span></a>
                </li>
                <li class="">
                    <a href="{{route('subadmin.GuessingForm.index')}}"><i class="fab fa-servicestack"></i> <span>Guessing Form</span></a>
                </li>
                <li class="">
                    <a href="{{route('subadmin.header.edit')}}"><i class="fab fa-servicestack"></i> <span>Header Details</span></a>
                </li>
                <li class="">
                    <a href="{{route('subadmin.notice.edit')}}"><i class="fab fa-servicestack"></i> <span>Notice</span></a>
                </li>
                <li class="">
                    <a href="{{route('subadmin.FastestLiveUpdate.edit')}}"><i class="fab fa-servicestack"></i> <span>Fastest Live Update</span></a>
                </li>
                <li class="">
                    <a href="{{route('subadmin.KnowDes.edit')}}"><i class="fab fa-servicestack"></i> <span>Know Details</span></a>
                </li>
                <li class="">
                    <a href="{{route('subadmin.SattaMatka.edit')}}"><i class="fab fa-servicestack"></i> <span>Satta Matka Details</span></a>
                </li>
                <li class="">
                    <a href="{{route('subadmin.KnowAbout.edit')}}"><i class="fab fa-servicestack"></i> <span>Know About Details</span></a>
                </li>
                <li class="">
                    <a href="{{route('subadmin.play.index')}}"><i class="fab fa-servicestack"></i> <span>Play</span></a>
                </li>
                <li class="">
                    <a href="{{route('subadmin.playlist.index')}}"><i class="fab fa-servicestack"></i> <span>Play Lists</span></a>
                </li>
                <li class="">
                    <a href="{{route('subadmin.gamerate.index')}}"><i class="fab fa-servicestack"></i> <span>Game Rate</span></a>
                </li>
             
            </ul>
        </div>
    </div>
</div>