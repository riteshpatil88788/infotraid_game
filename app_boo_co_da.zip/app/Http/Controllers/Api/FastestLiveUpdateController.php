<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\FastestLiveUpdate;
use Illuminate\Support\Facades\Auth;

class FastestLiveUpdateController extends Controller
{
 
    public function index(){
       
        $data['title'] = "Fastest Live Update";
        $data['FastestLiveUpdates'] = DB::table('fastest_live_updates')->where('id',1)->first();
        if (!$data['FastestLiveUpdates']) {
            return response()->json(['status' => false, 'data' => [], 'message' => 'Record not found']);
        }
       return response()->json(['status' => 'success', 'data' => $data, 'message' => 'Record Successfully!']);
       
    }





    
}
