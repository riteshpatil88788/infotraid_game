<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use DB;
use Illuminate\Support\Facades\Http;

class UserController extends Controller
{
    //todo: admin login form
  

    //todo: admin login functionality
//   public function login(Request $request)
// {
//     // Validate the incoming request data
//     $request->validate([
//         'email' => 'required|string|email',
//         'password' => 'required|string',
//     ]);

//     // Find the user by email
//     $user = User::where('email', $request->email)->first();

//     // Check if user exists and password matches
//     if (!$user || !Hash::check($request->password, $user->password)) {
//         return response()->json(['status' => false, 'data' => [], 'message' => 'Invalid email and password'],  );
//     }

//     // Check if an existing token is available
//     $token = $user->createToken('auth_token')->plainTextToken;
//     if ($existingToken) {
//         // Reuse the existing token
//         $data = [
//             'data' => $user,
//             'access_token' => $token->plainTextToken,
//         ];
//         return response()->json(['status' => true, 'data' => $data, 'message' => 'Logged in successfully']);
//     }

//     // Generate a new token if no existing token is found
//      $token = $user->createToken('auth_token')->plainTextToken;

//     // Return the token and user information in the response
//     $data = [
//         'data' => $user,
//         'access_token' => $token,
//     ];

//     return response()->json(['status' => true, 'data' => $data, 'message' => 'Logged in successfully']);
// }

    public function login(Request $request)
{
    // Validate the request
    $request->validate([
        'email' => 'required|email',
        'password' => 'required',
    ]);

    // Attempt to authenticate user
    if (Auth::attempt($request->only('email', 'password'))) {
        $user = Auth::user();
        $token = $user->createToken('auth_token',['*'])->plainTextToken;
        $user->access_token =  $token;
       
        return response()->json([
            'status' => true,
            'data' => $user,
            'message' => 'Login successful',
        ], 200);
    }

    // If authentication fails
    return response()->json([
        'status' => false,
        'data' => [],
        'message' => 'Invalid email and password',

    ]);
}
    

    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'phone'  => 'required',
            'password' => 'required|string|min:8',
            'confirm_password' => 'required|string|same:password',
        ]);
        if($request->password != $request->confirm_password){
         return response()->json(['status' => false, $data => [],'message' => 'password and confirm password do not match']);
        }
        
        $keyId = env('RAZORPAY_KEY_ID');
        $keySecret = env('RAZORPAY_SECRET');
          $contactResponse = Http::withHeaders([
        'Authorization' => 'Basic ' . base64_encode($keyId.':'.$keySecret),
            ])->post('https://api.razorpay.com/v1/contacts', [
                "name" => $request->name,
                "email" => $request->email,
                "contact" => $request->phone,
                "type" => "customer",
                "reference_id" => "user_" . uniqid(),
            ]);
             
            if (!$contactResponse->successful()) {
                return response()->json(['status' => false, $data => [],'message' => 'Failed to create contact']);
            }
          
            $contactId = $contactResponse->json()['id'];
           $user = User::create(['razorpay_contact_id'=> $contactId]);
           $user->name = $request->name;
           $user->email = $request->email;
           $user->phone = $request->phone;
           $user->password = Hash::make($request->password);
           $user->save();
        // $user = User::create([
        //     'name' => $request->name,
        //     'email' => $request->email,
        //     'phone' => $request->phone,
        //     'password' => Hash::make($request->password),
        // ]);
       
        $token = $user->createToken('auth_token')->plainTextToken;
         $userdata = $user->first();
        // Return the token and user information in the response
        $data = ['data' => $userdata,'access_token' => $token];
        return response()->json([
            'status' => true,
            'data' => $data,
            'message' => 'Registered successfully' ]);
    }


    public function user(Request $request)
    {
        return $request->user();
    }

    // Log out the authenticated user
    public function logout(Request $request)
    {   
        if(!$request->user()->tokens()){
         return response()->json(['status' => false,'data'=>[],'message' => 'Record not found'], );
        }
        
        $request->user()->tokens()->delete();
        return response()->json(['status' => true,'data'=>[],'message' => 'Logged out successfully']);
    }

    public function sendResetLinkEmail(Request $request)
    {
        try {
        $request->validate(['email' => 'required|email'],
        [
            'email.required' => 'Email is required.',
            'email.email' => 'Please provide a valid email address.',
        ]
        );

        // Send reset link
        $status = Password::sendResetLink($request->only('email'));
        
        
        // Check if link was sent successfully
        if ($status == Password::RESET_LINK_SENT) {
             return response()->json(['status' => true,'message' => 'Password reset link sent successfully.']);
        } else {
             return response()->json(['status' => false,'message' => 'Unable to send password reset link.']);
        }
        } catch (ValidationException $e) {
        // Handle validation exception and return custom response
        return response()->json([
            'status' => false,
            'message' => $e->validator->errors()->first(), // Get the first validation error
        ]);
    }
    }


    public function reset(Request $request)
    {
        $input = $request->only('email', 'token', 'password', 'password_confirmation');
    
        // Validation
        $validator = Validator::make($input, [
            'token' => 'required',
            'email' => 'required|email',
            'password' => 'required|confirmed|min:8',
        ]);
    
        if ($validator->fails()) {
            return response()->json(['status' => false,'message' => $validator->errors()->first()]);
        }
    
        // Retrieve the token from the database for comparison
        $resetEntry = DB::table('password_resets')->where('email', $input['email'])->first();
        
        if (!$resetEntry || !Hash::check($input['token'], $resetEntry->token)) {
            return response()->json(['status' => false,'message' => 'Token or email not found']);
        }
    
        // Password reset
        $response = Password::reset($input, function ($user, $password) {
            $user->password = Hash::make($password);
            $user->save();
        });
    
        if ($response == Password::PASSWORD_RESET) {
            return response()->json(['status' => true,'message' => 'Password reset successfully']);
        } else {
            return response()->json(['status' => false,'message' => 'Invalid token or email']);
        }
    }



     public function changePassword(Request $request)
     {
    // Validate the request input
    $request->validate([
        'old_password' => ['required'], // Validate the old password field
        'new_password' => ['required', 'string', 'min:8'], // Ensure new password is strong
        'confirm_password' => ['required', 'same:new_password'], // Ensure confirm_password matches new_password
    ], [
        'old_password.required' => 'The old password is required.',
        'new_password.required' => 'The new password is required.',
        'new_password.min' => 'The new password must be at least 8 characters.',
        'confirm_password.required' => 'The confirmation password is required.',
        'confirm_password.same' => 'The confirmation password must match the new password.',
    ]);

    // Retrieve the authenticated user
    $user = Auth::user();

    // Check if the provided old password matches the user's actual current password
    if (!Hash::check($request->old_password, $user->password)) {
        // Return a validation error if passwords do not match
        return response()->json([
            'status' => false, 
            'data' => [], 
            'message' => 'The provided old password does not match our records.'
        ]);
    }

    // Update the password and save the user
    $user->password = Hash::make($request->new_password);
    $user->save();

    // Return a success message in JSON format
    return response()->json([
        'status' => true, 
        'data' => $user, 
        'message' => 'Password changed successfully.'
    ]);
}

    
    
     public function wallet(Request $request)
     {
//   echo "<pre>";print_r($request->all());die;
    $request->validate([
        'user_id' => 'required|exists:users,id',
        'amount' => 'required|numeric|min:0',
    ]);

    $user = User::find($request->user_id);
    if (!$user) {
        return response()->json(['status' => false,'data' => [],'message' => 'Failed to update wallet']);
    }
     $wallet = DB::table('wallets')->insert([
    'user_id' => $user->id,
    'amount' => $request->amount,
    'payment_id' => $request->transaction_id ?? Null,
    'status' => $request->status ?? Null
    ]);
    $user->wallet += $request->amount;
    $user->save();
    $walletdata = DB::table('wallets')->where('user_id',$user->id)->latest()->first();
    

     
    $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => $request->amount,
    'debit' => '',
    'game_id' => '',
    'play_game_id' => $request->play_game_id,
    'remaining_balance' => $userdata->wallet,
    'status' => 'wallet',
    ]);
        return response()->json(['status' => true, 'data' => $user , 'message' => ' Record inserted Successfully']);
    return response()->json(['status' => true,'data' => $walletdata,'message' => 'Wallet updated successfully']);

}

    public function withdrawal(Request $request)
    {
        $request->validate([
        'user_id' => 'required|exists:users,id',
        'amount' => 'required|numeric|min:0',
        'name' => 'required',
        'account_number' => 'required',
        'ifsc' => 'required'
    ]);
    
    
    $user = User::find($request->user_id);
    $oldbalance = $user->wallet - $request->amount;
    if (!$user) {
        return response()->json(['status' => false,'data' => [],'message' => 'Record not found'], );
    }
     
        $keyId = env('RAZORPAY_KEY_ID');
        $keySecret = env('RAZORPAY_SECRET');
       $contactId = $user->razorpay_contact_id;
     
    if(!$user->razorpay_fundaccount_id){  
    $fundAccountResponse = Http::withHeaders([
        'Authorization' => 'Basic ' . base64_encode($keyId.':'.$keySecret),
    ])->post('https://api.razorpay.com/v1/fund_accounts', [
        "contact_id" => $contactId,
        "account_type" => "bank_account",
        "bank_account" => [
            "name" => $request->name,
            "ifsc" => $request->ifsc,
            "account_number" => $request->account_number,
        ],
    ]);

    // if (!$fundAccountResponse->successful()) {
    //     return response()->json(['status' => false, $data => [],'message' => 'Failed to create fund account']);
    // }
    // dd($fundAccountResponse->json());
    $fundaccoutnid = $fundAccountResponse->json()['id'];
    $user->razorpay_fundaccount_id = $fundaccoutnid;
    $user->save(); 
    }else{
     $fundaccoutnid = $user->razorpay_fundaccount_id;
    }
    $referenceTd = 'txn_' . uniqid();
    // BKID0008911
    
    $payoutResponse = Http::withHeaders([
        'Authorization' => 'Basic ' . base64_encode($keyId.':'.$keySecret),
    ])->post('https://api.razorpay.com/v1/payouts', [
        "account_number" => "891110110007091", // Replace with Razorpay's account number
        "fund_account_id" => $fundaccoutnid,
        "amount" => $request->amount * 100, // Convert to paise
        "currency" => "INR",
        "mode" => "IMPS", // Use IMPS for instant payments
        "purpose" => "payout",
        "queue_if_low_balance" => true,
        "narration" => "Payout for user",
        "reference_id" => $referenceTd,
    ]);
    // dd($payoutResponse->json());
    if (!$payoutResponse->successful()) {
        return response()->json(['status' => false, 'data' => [],'message' => 'Failed to initiate payout']);
    }

    //dd($payoutResponse->json()); // Return payout details
    
     $withdrawal = DB::table('withdrawal_requests')->insert([
    'user_id' => $user->id,
    'amount' => $request->amount,
    'status' => $request->status ?? Null,
    'withdrawal_status' => $request->withdrawal_status ?? Null,
    ]);
    
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $user->id,
    'credit' => $request->amount,
    'debit' => '',
    'game_id' => '',
    'play_game_id' => '',
    'remaining_balance' => $oldbalance,
    'status' => 'withdrawal',
    ]);
    $withdrawalRequests = DB::table('withdrawal_requests')->where('user_id',$user->id)->first();
    return response()->json(['status' => true,'data' => $withdrawalRequests ,'message' => 'Withdrawal Request successfully']);
    }
    
    public function withdraw_callback(Request $request){
      dd($request->all());           
    }
    
    public function withdrawalHistory()
    {
        $data = DB::table('withdrawal_payments')->where('user_id',auth()->user()->id)->get();
        if(count($data) == 0){
            return response()->json(['status' => false,'data' => [] ,'message' => 'Not found']);
        }
    return response()->json(['status' => true,'data' => $data ,'message' => 'Record Successfully']);
    }
    
    public function walletHistory(Request $request)
    {
        $query = DB::table('wallets')->where('user_id',auth()->user()->id);
        // Add pagination
    $perPage = $request->get('per_page', 20); // Default to 20 items per page
    $data = $query->orderBy('wallets.id', 'desc')->paginate($perPage);

    // Check if data is empty
    if ($data->isEmpty()) {
        return response()->json(['status' => false,'data' => [],'message' => 'Not found']);
    }

    // Response with paginated data and metadata
    return response()->json([
        'status' => true,
        'data' => $data->items(), // Paginated data
        'pagination' => [
            'total' => $data->total(),
            'current_page' => $data->currentPage(),
            'per_page' => $data->perPage(),
            'last_page' => $data->lastPage(),
        ],
        'message' => 'Record Successfully'
    ]);
}
    
    
    public function profile()
    {
        $data = DB::table('users')->select('name','phonepe','googlepe','paytm')->where('id',auth()->user()->id)->first();
        if(!$data){
            return response()->json(['status' => false,'data' => [] ,'message' => 'Not found']);
        }
        return response()->json(['status' => true,'data' => $data ,'message' => 'profile data Successfully']);
    }
    
    public function profileupdate(Request $request)
    {
   
    $user = DB::table('users')->where('id', $request->user_id)->first();
    if (!$user) {
        return response()->json(['status' => false,'data' => [],'message' => 'Record not found',]);
    }
    $data = DB::table('users')->where('id',$request->user_id)->update(['phonepe'=>$request->phonepe,'googlepe'=>$request->googlepe,'paytm'=>$request->paytm]);
    $updatedUser = DB::table('users')->where('id', $request->user_id)->first();

     return response()->json(['status' => true,'data' => $updatedUser ,'message' => 'profile data Updated Successfully']);
    }
    
    public function get_wallet()
    {
        $data = DB::table('users')->select("wallet")->where('id',auth()->user()->id)->first();
        if(!$data){
           return response()->json(['status' => false,'amount' => "" ,'message' => 'Not Found']); 
        }
        return response()->json(['status' => true,'amount' => $data->wallet ,'message' => 'wallet amount']);
    }
    
    public function winnerlist()
    {
          $data = DB::table('bid_history')
        ->join('matka_results', 'bid_history.game_id', '=', 'matka_results.id')
        ->join('play_lists', 'bid_history.play_game_id', '=', 'play_lists.id')
        ->where([['user_id', auth()->user()->id], ['status', 1]])
        ->select('user_id','amount','number','digit','play_lists.game_id','matka_results.title','game_type','status')
        ->get();
         if(count($data) == 0){
            return response()->json(['status' => false,'data' => [] ,'message' => 'Not found']);
        }
        return response()->json(['status' => true,'data' => $data ,'message' => 'Winning History data Successfully']);
    }
    
    // public function bidlist()
    // {
    //     // echo 12;die;
    //   $data = DB::table('bid_history')
    //     ->join('matka_results', 'bid_history.game_id', '=', 'matka_results.id')
    //     ->join('plays', 'bid_history.play_game_id', '=', 'plays.id')
    //     ->select('bid_history.user_id','bid_history.amount','bid_history.number','bid_history.digit','plays.title as play_game_id','matka_results.title as game_id','bid_history.game_type','bid_history.status', 'bid_history.created_at')
    //     ->where('bid_history.user_id', auth()->user()->id)
    //     ->orderBy('bid_history.id', 'desc')
    //     ->get();
    //     if(count($data) == 0){
    //         return response()->json(['status' => false,'data' => [] ,'message' => 'Not found']);
    //     } 
    // return response()->json(['status' => true,'data' => $data ,'message' => 'bid history data Successfully']);
    // }
    
        public function bidlist(Request $request)
        {
            $query = DB::table('bid_history')
                ->join('matka_results', 'bid_history.game_id', '=', 'matka_results.id')
                ->join('plays', 'bid_history.play_game_id', '=', 'plays.id')
                ->select(
                    'bid_history.*',
                    'bid_history.game_id as gameId',
                    'plays.title as play_game_id',
                    'matka_results.title as game_id'
                )
                ->where('bid_history.user_id', auth()->user()->id);
        
            // Filter for 'game_id' (from request parameter)
            if ($request->has('game_id') && !empty($request->game_id)) {
                $query->where('bid_history.game_id', $request->game_id);
            }
        
            // Filter for 'bid_history.status'
            if ($request->has('status') && in_array($request->status, [0, 1, 2])) {
                $query->where('bid_history.status', $request->status);
            }
        
            // Filter for 'bid_history.game_type'
            if ($request->has('game_type') && !empty($request->game_type)) {
                $query->where('bid_history.game_type', $request->game_type);
            }
        
            // Add Pagination
            $perPage = $request->get('per_page', 20); // Default to 20 items per page
            $data = $query->orderBy('bid_history.id', 'desc')->paginate($perPage);
        
            if ($data->isEmpty()) {
                return response()->json(['status' => false, 'data' => [], 'message' => 'Not found']);
            }
        
            return response()->json([
                'status' => true,
                'data' => $data->items(), // Paginated data
                'pagination' => [
                    'total' => $data->total(),
                    'current_page' => $data->currentPage(),
                    'per_page' => $data->perPage(),
                    'last_page' => $data->lastPage(),
                ],
                'message' => 'Bid history data fetched successfully'
            ]);
        }


//   public function passbook(Request $request)
// {
//     // dd(auth()->user()->id);
//     $query = DB::table('passbooks')
//         ->join('matka_results', 'passbooks.game_id', '=', 'matka_results.id')
//         ->join('plays', 'passbooks.play_game_id', '=', 'plays.id')
//         ->select(
//             'passbooks.*',
//             'passbooks.game_id as gameid',
//             'passbooks.play_game_id as playgameid',
//             'plays.title as play_game_id',
//             'matka_results.title as game_id'
//         )
//          ->where('passbooks.user_id', auth()->user()->id);

//     // Add pagination
//     $perPage = $request->get('per_page', 20); // Default to 20 items per page
//     $data = $query->orderBy('passbooks.id', 'desc')->paginate($perPage);

//     // Check if data is empty
//     if ($data->isEmpty()) {
//         return response()->json(['status' => false,'data' => [],'message' => 'Not found']);
//     }

//     // Response with paginated data and metadata
//     return response()->json([
//         'status' => true,
//         'data' => $data->items(), // Paginated data
//         'pagination' => [
//             'total' => $data->total(),
//             'current_page' => $data->currentPage(),
//             'per_page' => $data->perPage(),
//             'last_page' => $data->lastPage(),
//         ],
//         'message' => 'Passbook history data fetched successfully'
//     ]);
// }

public function passbook(Request $request)
{
    // Query to fetch passbook data with joins
    $query = DB::table('passbooks')
        ->join('matka_results', 'passbooks.game_id', '=', 'matka_results.id')
        ->join('plays', 'passbooks.play_game_id', '=', 'plays.id')
        ->select(
            'passbooks.*',
            'passbooks.game_id as gameid',
            'passbooks.play_game_id as playgameid',
            'plays.title as play_game_title',
            'matka_results.title as game_title'
        )
        ->where('passbooks.user_id', auth()->user()->id);

    // Fetch data from the query
    $data = $query->orderBy('passbooks.id', 'desc')->get();

    // Add bid_history number dynamically
    foreach ($data as $item) {
        $bid = DB::table('bid_history')
            ->where('play_game_id', $item->playgameid)
            ->first();

        // Add bid number to the item object
        $item->bid_number = $bid ? $bid->number : null;
    }

    // Add pagination
    $perPage = $request->get('per_page', 20); // Default 20 items per page
    $currentPage = $request->get('page', 1); // Current page
    $paginatedData = collect($data)->forPage($currentPage, $perPage);

    $pagination = [
        'total' => $data->count(),
        'current_page' => $currentPage,
        'per_page' => $perPage,
        'last_page' => ceil($data->count() / $perPage),
    ];

    // Check if data is empty
    if ($data->isEmpty()) {
        return response()->json(['status' => false, 'data' => [], 'message' => 'Not found']);
    }

    // Response with paginated data and metadata
    return response()->json([
        'status' => true,
        'data' => $paginatedData->values(), // Paginated data
        'pagination' => $pagination,
        'message' => 'Passbook history data fetched successfully',
    ]);
}


    
     public function bankDetail(Request $request)
    {
    //    dd($request->all());
        $request->validate([
        'user_id' => 'required',
        'account_holder_name' => 'required',
        'bank_name' => 'required',
        'bank_account_number' => 'required',
        'ifsc' => 'required',
    ]);
      
    $user = User::find($request->user_id);
    if (!$user) {
        return response()->json(['status' => false,'data' => [],'message' => 'Record not found']);
    }
    //   dd($request->all());
     $data = DB::table('bank_details')->insert([
    'user_id' => $request->user_id,
    'account_holder_name' => $request->account_holder_name,
    'bank_name' => $request->bank_name,
    'account_number' => $request->bank_account_number,
    'ifsc' => $request->ifsc,
    ]);
    return response()->json(['status' => true,'data' => $data ,'message' => 'Bank detail inserted successfully']);
    }

    public function bankDetailupdate(Request $request)
    {
    // Validate the incoming request
    $request->validate([
        'user_id' => 'required|exists:users,id',
        'account_holder_name' => 'required|string|max:255',
        'bank_name' => 'required|string|max:255',
        'bank_account_number' => 'required|numeric',
        'ifsc' => 'required|string|max:15',
    ]);

    // Check if the user exists
    $user = User::find($request->user_id);
    if (!$user) {
        return response()->json([
            'status' => false,
            'data' => [],
            'message' => 'User not found'
        ],  );
    }

    // Find and update the bank details
    $bankDetail = DB::table('bank_details')->where('user_id', $request->user_id)->first();
    if (!$bankDetail) {
        return response()->json([
            'status' => false,
            'data' => [],
            'message' => 'Bank details not found'
        ],  );
    }

    $updated = DB::table('bank_details')->where('user_id', $request->user_id)->update([
        'account_holder_name' => $request->account_holder_name,
        'bank_name' => $request->bank_name,
        'account_number' => $request->bank_account_number,
        'ifsc' => $request->ifsc,
        'updated_at' => now(),
    ]);
    $bankdata = DB::table('bank_details')->where('id', $updated)->first();
    // dd($bankdata);
    return response()->json([
        'status' => true,
        'data' => $bankdata,
        'message' => 'Bank details updated successfully'
    ], 200);
}


    
}
