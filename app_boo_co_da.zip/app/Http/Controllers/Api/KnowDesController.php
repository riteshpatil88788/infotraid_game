<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\KnowDes;
use Illuminate\Support\Facades\Auth;

class KnowDesController extends Controller
{
 
    public function index(){
        if (!Auth::check()) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }
        $data['title'] = "Know Description";
        $data['KnowDess'] = DB::table('know_des')->where('id',1)->first();
        // echo "<pre>";print_r($abouts->toArray());die;
        if (!$data['KnowDess']) {
            return response()->json(['status' => false,  'data' => [] ,'message' => 'Record not found']);
        }
       return response()->json(['status' => true, 'data' => $data, 'message' => 'Record Successfully']);
    }




    
}
