<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="{{url('front-assets/style1.css')}}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
   @media only screen and (max-width:480px) {
            .logo {
                background-size: 100% auto;
                width: 100%;
            }

            .b_msg {
                font-size: 9px;
            }

            .heros {
                width: 66.67%;
                float: left;
                background-color: #25a2b8;
                padding: 12px 0;
                font-size: 22px;
            }
        }
    </style>
</head>
<body>
    <div class="sattamatka">
        <header>
    <div class="head_div">
        <a href="javascript:void(0);">
            <div class="header">
                <div class="logo">
                    <img class="logo ptb-10 mb-0" src="{{url('front-assets/images/logo.jpg')}}" alt="SattaMatka" />
                </div>
            </div>
        </a>
    </div>
            {!! $HeaderDes->description !!}
        </header>
        
        <div class="live-update">
            !! LIVE UPDATE !!
        </div>
        
        <div class="results">
@foreach($resultpatta as $result)
    @php
     
            $matka = App\Models\MatkaResult::where('id',$result->matka_result_id)->latest()->first();
             $digit1 = array_sum(str_split($result->patta1 ?? "0")) % 10;
        $digit2 = array_sum(str_split($result->patta2 ?? "0")) % 10;
        $dig = empty($digit2) ? '' : $digit2;
    @endphp
    <div>
        <h4>{{ ucwords($matka->title) }}</h4>
        <span>
         {{ $result->patta1 ?? '' }} - {{ $digit1 ?? '' }}{{ $dig ?? '' }} - {{ $result->patta2 ?? '' }}
        </span>
    </div>
    <button onclick="refreshPage()">Refresh</button>
@endforeach



            
           
            
        </div>

        <div class="online-matka">
            <h5>AD BOSS SATTA MATKA</h5>
            <h5>AD BOSS SATTA MATKA</h5>
            <h5>AD BOSS SATTA MATKA GUESSING</h5>
            <h5>AD BOSS SATTA MATKA RESULT SITE</h5>
            <h5>!! PROFESSOR !!</h5>
            <h5>!! ADMIN SIR !!</h5>
            <h5>+91</h5>
            <h5>ADD MARKET DIRECT CONTACT AVONLINE ADMIN OFFER THIS MONTH- ADMIN+91 -ONLY ON WHATS APP-CONTACT AVONLINE ADMIN</h5>
            <button>Play Online Matka</button>
        </div>
        <div class="results results-main">
          
            @php
             $matkas = App\Models\MatkaResult::groupBy('title')->get();
               @endphp 
          @foreach($matkas as $matka)
             @php
            $result = App\Models\Result::where('matka_result_id',$matka->id)->latest()->first();
            
                $digit1 = array_sum(str_split($result->patta1 ?? "0")) % 10;
                $digit2 = array_sum(str_split($result->patta2 ?? "0")) % 10;
                $dig1 = empty($result->patta1) ? '*' : $digit1;
                $dig2 = empty($result->patta2) ? '*' : $digit2;
               
            @endphp
            <div>
                <h4>{{ ucwords($matka->title) }}</h4>
                <span>{{ $result->patta1 ?? '***' }} - {{ $dig1 ?? '*' }}{{ $dig2 ?? '*' }} - {{ $result->patta2 ?? '***' }}</span>
            </div>
            
            @endforeach
          
            <div>
                <h4>ADD MARKET FOR RESULT CONTACT TO ADMIN BEST OFFER</h4>
                <span>--</span>
            </div>
        </div>
        <div class="refresh">
            <button class="refresh-btn" onclick="refreshPage()">Refresh</button>
        </div>
    </div>
    <div class="container">
        <div class="time-table-header">
            TIME TABLE
        </div>
        <table class="time-table">
            <thead>
                <tr>
                    <th>MARKET</th>
                    <th>OPEN</th>
                    <th>CLOSE</th>
                </tr>
            </thead>
            <tbody>
                 @php
             $matkas = App\Models\MatkaResult::groupBy('title')->get();
               @endphp
            @foreach($matkas as $matka)
                <tr>
                    <td>{{ucwords($matka->title)}}</td>
                    <td>{{date('h:i A',strtotime($matka->firsttime))}}</td>
                    <td>{{date('h:i A',strtotime($matka->lasttime))}}</td>
                </tr>
            @endforeach   
            </tbody>
        </table>
       
    </div>
    <div class="sattamatka">
        <div class="user-login">
            <h3>!! USER LOGIN !!</h3>
            <div>
                <button class="login"><a href="{{route('home.login')}}">login</a></button>
                <button class="register"><a href="{{route('home.register')}}">registration</a></button>
            </div>
        </div>
        <div class="game-zone">
            <h3>!! DAILY GAME ZONE !!</h3>
            <h5><a href="{{route('home.ResultGuessing')}}">GUESSING FORUM</a></h5>
            <h5><a href="{{route('home.expertGuessing')}}">EXPERTS FORUM</a></h5>
           
            <h5>FREE OPEN TO CLOSE ON PUBLIC DEMAND</h5>
            <h5>ALL MARKET MATKA FAST RESULT</h5>
            <h5>WEEKLY JODI AND PANNA</h5>
            <h5>100% FIX FREE GAME OPEN TO CLOSE & LIFE TIME LOSS COVER GOLDEN CHART</h5>
        </div>
        <div class="special-zone">
            <h3>!! 143 SPECIAL ZONE !!</h3>
            <h5>ADMIN SIR EVERGREEN TRICK ZONE</h5>
            <h5>KALYAN AND MUMBAI OLD 1974 TO 2012 GOLDEN CHART</h5>
            <h5>KHATRI FAVOURITE PANNA CHART</h5>
        </div>
        <div class="chart-zone">
            <h3>!! CHART ZONE !!</h3>
             @php
             $matkas = App\Models\MatkaResult::groupBy('title')->get();
               @endphp
            @foreach($matkas as $matka)
            <a href="{{$matka->jodi ?? route('home.jodi',$matka->id) }}"><h5>{{ucwords($matka->title)}} CHART</h5></a>
           @endforeach
            <h5>ADD MARKET FOR RESULT CONTACT TO ADMIN BEST OFFER</h5>
        </div>
        <div class="penal-zone">
            <h3>!! ALL SATTA MATKA PENAL CHART !!</h3>
             @php
             $matkas = App\Models\MatkaResult::groupBy('title')->get();
               @endphp
            @foreach($matkas as $matka)
            <a href="{{$matka->panel ?? route('home.panel',$matka->id) }}"><h5>{{ucwords($matka->title)}} PANEL CHART</h5></a>
           @endforeach

            <h5>ADD MARKET FOR RESULT CONTACT TO ADMIN BEST OFFER PANEL CHART</h5>
        </div>
        <div class="sattamatka341">
            <p>दोस्तों धोखेबाजों से सावधान रहें! केवल भरोसेमंद लोगो के साथ ही सट्टा मटका गेम खेलें इतने लम्बे समय से हम यों ही टॉप
            सट्टा प्रोवाइडर नहीं हैं, कुछ तो बात होगी?? किसी और पर भरोसा करने से पहले एक बार जरूर सोच लें वाकी आपकी मर्जी</p>
        </div>
        <div class="disclaimer">
           {!! $KnowDes->description !!}
        </div>
        <div class="sattamatka341">
           {!! $FastestLiveUpdates->description !!}


        </div>

        <div class="top">
            <button class="top-btn" onclick="goToTop()">Go To Top</button>
        </div>

        <div class="reseved">
            <h6>AD BOSS SATTA MATKA</h6>
            <h6>ALL RIGHTS RESERVED</h6>
            <h6>(2024-2025)</h6>
            <button class="back">BACK</button>
            <button class="home">HOME</button>
        </div>

        <div class="tele-ref-btn">
            <div><button class="tele">telegram</button></div>
            <div><button onclick="refreshPage()" class="ref-btn">refresh</button></div>
        </div>
       
        
    </div>
    
    <script src="{{ url('front-assets/script1.js')}}">
            
    </script>
</body>
</html>