


<!DOCTYPE>

<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
      
    
    
    
    <link rel="stylesheet" type="text/css" href="https://storage.googleapis.com/sattamatka-cdn-bucket/index_files/iconochive.css">
    <!-- End Wayback Rewrite JS Include -->
    <title>AD BOSS Satta Matka EXPERT MATKA GUESSING FORUM KALYAN GUESSING - </title>
    <meta http-equiv="refresh" content="900">
    <meta name="description" content="The Best free forum for matka guessing kalyan guessing 341 guessing satta matka on line tips and tricks fix kalyan matka results daily guessing and fastest update.">
    <meta name="keywords" content="AD BOSS satta matka, matka guessing free, kalyan result, kalyan guessing, matka guessing, matka jodi fix, matka game, satta market, matka on line ">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google" value="notranslate">
    
    
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://kendo.cdn.telerik.com/2019.3.1023/styles/kendo.common.min.css" />
    

    
    <script src="https://kendo.cdn.telerik.com/2019.3.1023/js/kendo.ui.core.min.js"></script>

    <script async src="https://www.googletagmanager.com/gtag/js?id=G-TVDGB9FMGW"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'G-TVDGB9FMGW');
    </script>

    

    
    

    <script src="/Scripts/tinymce/tinymce.min.js"></script>

    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body style="background-color:#ffefcd;">

    <!--header start-->
    <style>
        h1 {
            text-align: center;
            font-size: 14px;
            background-color: #03c;
            color: #fff;
        }

        h2 {
            text-align: center;
            font-size: 13px;
            background-color: #03c;
            color: #fff;
        }

        @font-face {
            font-family: myfont1;
            /*src: url(/web/20200513041656im_/https://app.sattamatka.mobi/LatoLatin-BoldItalic.woff2);*/
        }

        .head_div {
            width: 100%;
            box-sizing: border-box;
            margin-top: 5px;
        }

        .logo {
            /*background-image: url('~/logosm.png');*/

            background-size: auto auto;
            background-position: center;
            height: 180px;
            background-repeat: no-repeat;
            background-size: auto auto;
            background-position: center;
            /*width: 75%;*/
            height: 100%;
            text-align: center;
            background-repeat: no-repeat;
            float: none;
            margin-left: auto;
            margin-right: auto;
        }

        .header {
            border-radius: 3px;
            border: 3px solid #13316c;
            box-sizing: border-box;
            background: radial-gradient(white, #e9f5fa);
            box-shadow: 0 0 10px #13316c;
            height: 75px;
        }

        .b_msg {
            font-family: myfont1;
            font-size: 12px;
            box-sizing: border-box;
            color: #fff;
            margin: 6px 0 0 0;
            padding: 5px 0;
            text-align: center;
            width: 100%;
            background-color: #0033cc;
            margin: 8px 0 0 0;
        }

        .heros {
            width: 66.67%;
            float: left;
            background-color: #25a2b8;
            padding: 7px 0;
            font-size: 30px;
        }

        @media only screen and (max-width:480px) {
            .logo {
                background-size: 100% auto;
            }

            .b_msg {
                font-size: 9px;
            }

            .heros {
                width: 66.67%;
                float: left;
                background-color: #25a2b8;
                padding: 12px 0;
                font-size: 22px;
            }
        }

        .i_btn1 {
            padding: 7px 10px;
            color: #fff;
            font-weight: 700;
            font-family: myfont1;
            margin-top: 7px;
            cursor: pointer;
            border-radius: 3px;
        }

        .blinking {
            animation: blinkingText 0.8s infinite;
            font-size: 25px;
            color: red;
        }
    </style>

    <style>
        .switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 20px;
            top: 5px;
        }

            .switch input {
                display: none;
            }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ca2222;
            -webkit-transition: .4s;
            transition: .4s;
            border-radius: 34px;
        }

            .slider:before {
                position: absolute;
                content: "";
                height: 18px;
                width: 18px;
                left: 4px;
                bottom: 1px;
                background-color: white;
                -webkit-transition: .4s;
                transition: .4s;
                border-radius: 50%;
            }

        input:checked + .slider {
            background-color: #2ab934;
        }

        input:focus + .slider {
            box-shadow: 0 0 1px #2196F3;
        }

        input:checked + .slider:before {
            -webkit-transform: translateX(26px);
            -ms-transform: translateX(26px);
            transform: translateX(25px);
        }
        /*------ ADDED CSS ---------*/

        .slider:after {
            content: 'OFF';
            color: white;
            display: block;
            position: absolute;
            transform: translate(-50%, -50%);
            top: 50%;
            left: 50%;
            font-size: 10px;
            font-family: Verdana, sans-serif;
        }

        input:checked + .slider:after {
            content: 'ON';
        }
        /*--------- END --------*/
    </style>

	

    <!--header start-->
    <div class="head_div">
        <a href="javascript:void(0);">
            <div class="header">
                <div class="logo">
                   <img class="logo ptb-10 mb-0" src="{{url('front-assets/images/logo.jpg')}}" alt="SattaMatka" />
                </div>
                
            </div>
        </a>
    </div>
    <div class="b_msg">
        Use Google Chrome or Mozilla Firefox, Safari Browser to use and see this Website. Do not use UC Browser UC Mini and opera Mini.
        <div>इस वेबसाइट का उपयोग करने और देखने के लिए Google क्रोम या मोज़िला फ़ायरफ़ॉक्स, सफ़ारी ब्राउज़र का उपयोग करें। यूसी ब्राउज़र यूसी मिनी और ओपेरा मिनी का उपयोग न करें।.</div>
    </div>
    <!--header end-->
    <!--posting rules start-->
    <!--
        <div class="chart_title2">

    <div style="width:33.33%;float:left;background-color: #25a2b8;"><img src="images/hero-min.png" style="width: 102px;"></div>
    <div class="heros"><span>KALYAN HERO's<br>FORUM </span></div>
    <br>
    <div style="text-align:center;background-color: #25a2b8;"><a style="background-color:#e62e00;border:1px solid #e62e00;" class="i_btn1" href="heros-forum.php" >Click Here</a></div>
    </div>
    -->
    <div class="b_msg">
        <h1>Satta matka guessing forum</h1>
        <h2>Welcome to the best satta matka guessing forum, enjoy tips and tricks from our best guessers.</h2>
    </div>
    <div class="postrule">
        <p class="postrule_head1">Posting Rules:-</p>
        <p class="postrule_head2">
            2 OPEN YA CLOSE
            <br> 6 JODI
            <br> AUR 8 PANNA
            <br> AUR RESULT TIME SE 20 MIN PHELE GAME POST KARNA HOGA....!!!!
            <br> Dont Mention Date Or Time In Your Post.
        </p>
        <a href="" style="text-decoration:none;">
            <div class="read_forum">Click Here To Read Full Experts Forum Rules</div>
        </a>
    </div>
    <!--posting rule end-->

    <style>
        .postrule_head1,
        .postrule_head2,
        .read_forum {
            text-align: center;
            font-weight: 700;
        }

        .profile_head,
        .read_forum {
            color: #fff;
            font-family: myfont1;
        }

        .postrule_head1,
        .postrule_head2,
        .profile_head,
        .read_forum {
            font-family: myfont1;
        }

        .comment_box,
        .profile {
            box-shadow: 0 0 10px #b3b3b3;
        }

        .postrule {
            border: 2px solid #039686;
            background-color: #e5fffc;
            margin: 8px 0 0 0;
            float: left;
            width: 100%;
            box-sizing: border-box;
        }

        .postrule_head1 {
            padding: 0px 0 0 0;
        }

        .postrule_head2 {
            font-size: 15px;
        }

        .read_forum {
            font-size: 18px;
            background-color: #039686;
            margin: 0;
            padding: 4px 0 0;
        }

        .profile {
            background-color: #133e8c;
            border: 2px solid #001945;
            text-align: center;
            float: left;
            width: 100%;
            box-sizing: border-box;
        }

        .profile_user {
            font-size: 20px;
            font-family: myfont1;
            color: #fff;
        }

        .comment_box {
            border: 2px solid #a15001;
            border-radius: 5px;
            float: left;
            margin: 10px 0 0 0;
            width: 100%;
            box-sizing: border-box;
        }

        .quote {
            background-color: #6ff;
            color: red;
            border-width: 1px;
            border-color: #6ff;
            font-weight: 700;
            font-style: italic;
            margin: 1px;
            /*padding: 10px;*/
        }

        .profile_head {
            width: 33%;
            margin: 5px 0;
            float: left;
        }

        .profile_head_img {
            float: left;
            margin: 0 0 0 30%;
        }

        .profile_head_menu {
            float: left;
            padding: 8px 0 8px 5px;
            font-size: 20px;
            font-family: myfont1;
            color: #fff;
        }

        @media only screen and (max-width:480px) {
            .postrule_head1,
            .postrule_head2 {
                font-size: 10px;
            }

            .read_forum {
                font-size: 15px;
                padding: 2px 0;
            }

            .profile_head {
                /*width:33.33%;*/
                float: left;
                margin: 4px 0;
            }

            .profile_head_img {
                float: left;
                margin: 0 0 0 0;
            }

            .profile_head_menu {
                float: left;
                padding: 8px 0 8px 5px;
                font-size: 15px;
                font-family: myfont1;
                color: #fff;
            }

            .profile_head_profile {
                width: 25%;
            }

            .profile_head_post {
                width: 30%;
            }

            .profile_head_ach {
                width: 45%;
            }

            .profile_user {
                font-size: 15px;
                font-family: myfont1;
                color: #fff;
                margin-top: 5px;
            }
        }

        .profile_head.profile_head_ach.a span.profile_head_menu {
            width: auto;
            text-align: center;
        }

        .profile_head.profile_head_ach.a {
            width: 100%;
            text-align: center;
            float: none;
            clear: both;
            MARGIN-TOP: 30PX;
        }

        .mains {
            width: 100%;
            text-align: center;
            display: inline-block;
            clear: both;
        }

        .profile_head_menu {
            float: none !important;
        }

        .mains .profile_head {
            width: 33%;
            text-align: center;
            float: none;
            display: inline-block;
        }

        .profile_head_menu.butto {
            background: #440e62;
            padding: 9px 10px;
            border-radius: 10px;
            display: inline-block;
            width: auto;
            vertical-align: middle;
        }

        @media only screen and (max-width:767px) {
            .mains .profile_head {
                width: auto;
                text-align: center;
                float: none;
                display: inline-block;
            }
        }
    </style>

    <!--header start-->
    <!--header end-->
    <style>
        body {
            padding: 0;
            margin: 0;
        }

        .quote {
            background-color: #66FFFF;
            color: red;
            border-width: 1px;
            border-color: #66FFFF;
            margin-top: -20px;
            margin-bottom: -25px;
            margin-left: 1px;
            margin-right: 1px;
            padding-top: 1px;
            padding-bottom: 1px;
            padding-left: 1px;
            padding-right: 1px;
            font-weight: bold;
            font-style: italic;
            font-size: 13px;
        }

        pre {
            white-space: pre-wrap;
            display: block;
            padding-bottom: 0px;
            margin: 0px;
            font-size: 15px;
            background-color: #ffffff;
            overflow: hidden;
        }

        .panel {
            padding: 0 18px;
            display: none;
            background-color: #d4f2fb;
            overflow: hidden;
            font-weight: 800;
            margin-top: 10px;
            border: 2px solid #ea0707;
            border-radius: 7px;
        }

            .panel p {
                font-style: italic;
                font-family: myfont1;
                margin: 5px;
            }

        .chart_title2 {
            background-color: #25a2b8;
            border-radius: 5px 5px 0 0;
            text-align: center;
            color: #fff;
            padding: 12px 0;
            font-family: myfont1;
            font-weight: 700;
            font-size: 12px;
            margin: 11px 0 0 0;
            height: auto;
        }

        .chart_head2 {
            background-color: #b6e7ef;
            text-align: center;
            font-family: myfont1;
            font-weight: 700;
            font-size: 18px;
            padding: 5px 0 4px 0;
            color: #000;
        }

        .specialofr {
            color: #fff;
            background-color: #dc3545;
            border-color: #dc3545;
            border-radius: 25px;
            padding: 1px 27px !important;
            font-weight: 600;
            font-style: italic;
        }
    </style>
    <!--
         <hr><div class="chart_title2">
          Are You A Guesser..?<br/>
          Do You Want To Be A Guesser..?<br/></div>
          <div class="chart_head2">
    <a href="http://bit.ly/2XA5rb2">Click Here</a></div></div>
    -->
    <div style="text-align:center">
        <!-- -->
        <!--   -->
    </div>
    <div class="profile" style="margin:10px 0 10px 0;">
        <div class="profile_head" style="width:100%; text-align:center;"> EXPERTS FORUM </div>
    </div>
    <!--
           <div class="postrule">

          <div class="read_forum">Play Matka Online<br/>
    101% Trusted<br/>
    <a href="https://avonline.in">sattamatka</a></div></div>
    -->
    <div class="postrule" style="margin-bottom:10px;">
			   
        <div class="read_forum">
            Play Matka Online,
            <br> 101% Trusted
            <br> 
            <a href="/Home/Download" style="color:red;">Download Now</a>
            
        
		 <br>  <br>  
		<button class="a15"><a href="" target="_blank"><i class="fa fa-whatsapp" style="font-size:40px;color:green"></i></a></button> 
		<br> <br>
<br><a style="position:; bottom:10px;left:5px; padding:6px 5px; font-size:17px; border:1px solid #ffff; text-decoration:none; background-webkit-linear-gradient(to right, green, blue);background: linear-gradient(to right, gold, #e70042); color: #003399 ; color: black; border-radius:10px;"<a href=" https://dpboss.website/ " rel="Dofollow"><img src="https://www.animatedimages.org/data/media/111/animated-arrow-image-0133.gif" width="15px">
<b>satta matka</b></a>
</p><span style="color:#ffff"><b></b></p></div></div></div></span>
</div></div></div>		
		<br>
        </div>
    </div>
    <div style="text-align: center;">
        <a href="/Home/Reports">
            <input type="button" value="Top 10" />
        </a>
        <input type="button" value="Refresh" onclick="parent.location=&quot;javascript:location.reload()&quot;"> --
        <input type="button" onclick="" value="GoTo Home">
        <input type="button" onclick="toggle();" value="Emojis">
        <p id="emojitoggle" hidden>:dance: &nbsp; :fire1: &nbsp; :fire2: &nbsp; :gunfire: &nbsp; :lol: &nbsp; :congrats: </p>
    </div>

    <div style="text-align:center;margin-top:10px;">

    </div>



    <div style="float:left;">
    </div>

    <style>
        td.t_img > img {
            width: 2%;
            margin: 2px 0 0 0;
        }

        td.t_date {
            color: #FFFF00;
            font-weight: bold;
            font-size: 18px;
        }

        @media only screen and (max-width:480px) {
            td.t_img > img {
                width: 10%;
            }

            td.t_date {
                font-size: 14px;
            }
        }

        td.menu {
            color: #000000;
            width: auto;
            font-style: italic;
            text-align: center;
            word-wrap: break-word;
            overflow-wrap: break-word;
            font-family: Verdana, Geneva, sans-serif;
            font-size: 15px;
        }

        td {
            padding: 3px 0 0 0;
        }
    </style>

    <div style="float:left; width:100%;">

            <br>
        @foreach($experts as $expert)
        @php 
        $user = DB::table('users')->where('id', $expert->user_id)->first();
        @endphp
            <table id="listitem_1623734" border="3" style=" width:100%; table-layout:fixed;background-color:rgb(255, 165, 0); margin:0 0 0 0;">
                <tbody>
                    <tr>
                        <td class="t_date" style="width:52%; background-color:#009900;padding: 8px;">{{ \Carbon\Carbon::parse($expert->created_at)->format('Y-m-d h:i A') }} </td>
                        <td class="t_img" style="width:48%;  background-color:#fff;text-align:center;padding: 8px;">
                                <span style="color:#aa2a2a;font-weight:bold;text-align:center;font-size: 12pt;word-wrap: break-word;font-family: Tahoma;">
                                    {{$user->name}} 
                                </span>

                            
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" class="menu" style="background-color:#fff;">
                            
							 
                            <b>
                                <pre style="margin-top: 0PX">

                                <div style="margin-top:-30px;margin-bottom:-20px;">
                                     {{ $expert->description}}
                                    </div>
                            </pre>
                            </b>
                        </td>
                    </tr>
                    <tr>
                        <td style="color:yellow;background-color: #00008b; padding:7px 0;">
                            <b>
                                <a style="color: #fff;font-size: 11pt;" href="{{ route('home.index')}}">
                                    Google Chrome
                                </a>

                            </b>
                        </td>
                        <td style="background-color:#009900;">

                            <div align="left">
                                <b>
                                    <a style="color: #fff;font-size: 11pt;" href="{{ route('home.index')}}">
                                        <color ="black">[ HOME ]</color>
                                    </a>
                                        <a id="btnForumPost" style="color: #fff;font-size: 11pt;" href="javascript:void(0);" onclick="ShowAlert(); return false;">
                                            [ QUOTE ]
                                        </a>
                                    
                                    <br>
                                </b>
                            </div>

                        </td>

                    </tr>
                    <tr align="left" id="forumComment_1623734" hidden style="background-color:#d1caa0;margin-top:5px;margin-left:10px;">
                        <td colspan="2">
                            <textarea id="txtForumComment1623734" name="txtForumComment1623734" rows="2" cols="50" style="width:100%;height:30px;padding-bottom:0px;"></textarea>
                            <script>
                                    tinymce.init({
                                        selector: '#txtForumComment1623734',
                                        license_key: 'gpl',
                                        height: 200,
                                        setup: function (editor) {
                                            editor.on('change', function (e) {
                                                if (1==1) {
                                                    console.log('chagne event key pressed');
                                                    var content = editor.getContent();

                                                    console.log('content replaced');

                                                    if (content.search(":congrats:") != -1 || content.search(":gunfire:") != -1
                                                        || content.search(":lol:") != -1 || content.search(":fire1:") != -1
                                                        || content.search(":dance:") != -1 || content.search(":fire2:") != -1

                                                    ) {
                                                        var res = content.replace(":congrats:", "<img src='../../emojis/congrats.gif'/>")
                                                            .replace(":lol:", "<img src='../../emojis/lol.gif' />")
                                                            .replace(":dance:", "<img src='../../emojis/dance.gif' />")
                                                            .replace(":gunfire:", "<img src='../../emojis/gunfire.gif' />")
                                                            .replace(":fire1:", "<img src='../../emojis/firecracker1.gif' />")
                                                            .replace(":fire2:", "<img src='../../emojis/firecracker2.gif' />")
                                                            ;

                                                        editor.setContent(res);
                                                        //place cursor at end after replacing
                                                        editor.selection.select(editor.getBody(), true);
                                                        editor.selection.collapse(false);
                                                    }
                                                }

                                            });
                                        },
                                        placeholder: "Enter text here...",
                                        force_br_newlines: true,
                                        //force_p_newlines: false,
                                        forced_root_block: 'p',
                                        menubar: false,
                                        plugins: [],
                                        toolbar: '',
                                        image_list: [
                                            { title: 'Congratulations 1', value: 'https://www.funimada.com/assets/images/cards/big/congrats-1.gif' },
                                            { title: 'Congratulations 2', value: 'https://i.pinimg.com/originals/e5/27/9f/e5279f5b58c4d921d8439c253bb15362.gif' }
                                        ],
                                        content_style: 'body { font-style: italic; font-weight:700; font-size:16px;}',
                                        image_description: false
                                    });
                            </script>

                            <input style="margin-top:10px;" type="button" class="" value="Post Quote" id="btnForumPost_1623734" onclick="PostForumComment(14363,1623734)" />
                        </td>
                    </tr>

                    <tr>
                        <td bgcolor="009900">
                            <a style="color: #ffffff;" href="{{ route('home.profile',$user->id)}}">My Profile</a>
                        </td>
                        <td bgcolor="darkblue">
                            <a style="float:left;padding-left: 2px;" href="#" onclick="document.body.scrollTop = document.documentElement.scrollTop = 0; return;">
                                <font color="yellow">
                                    <b>GoTop</b>
                                </font>
                            </a>&nbsp;<a style="float:right;padding-right: 2px;" href="javascript:void(0);" onclick="gotobottum();">
                                <font color="yellow"><b> Bottom</b></font>
                            </a>
                        </td>
                    </tr>
                </tbody>
            </table>
            <br>
            @endforeach
          

    </div>

    <style>
        .current,
        .disabled {
            color: #7a0238;
            background: #ffe3b3
        }

        .current,
        .disabled,
        .n_btn,
        .pg_num {
            font-weight: 700;
            padding: 3px;
            font-family: myfont1;
            border: 1px solid #7a0238;
            margin: 0 0 0 5px;
            display: inline-block;
            float: left
        }

        a,
        a:hover {
            text-decoration: none
        }

        .pagination {
            color: #7a0238;
            display: inline-block
        }

        .pg_num {
            color: #252525
        }

        .n_btn {
            color: #7a0238
        }
    </style>


    <div style="float:left; width:100%;">
        <br>
        <div class="pagination">
     {{ $experts->links() }}
</div>

    </div>

    <style>
        .refresh {
            background-color: #440e62;
            border: 1px solid #14001f;
            text-align: center;
            color: #fff;
            padding: 8px;
            font-family: myfont1;
            box-sizing: border-box;
            margin: 10px 0 0 0;
            font-size: 20px;
            font-weight: 700;
            box-shadow: 0 0 10px #461300;
            width: 10%;
            text-align: center;
            text-decoration: none;
        }
    </style>

    <div align="center" style=" width: 100%;text-align: center;margin-top: 17px;float: left;">
        <a href="#" class="refresh" onclick="gototop();">
            Go To Top
        </a>
           <a href="{{ route('home.logout') }}" class="refresh" style="margin-left:5px;" onclick="event.preventDefault(); document.getElementById('logout').submit();">
            Log Out
        </a>

    <form id="logout" action="{{ route('home.logout') }}" method="get" style="display: none;">
        @csrf
    </form>
    </div>

    <style>
        .footer {
            width: 100%;
            box-sizing: border-box;
            float: left;
            text-align: center;
            color: #fff;
            font-size: 20px;
            font-weight: 700;
            font-family: myfont1;
            height: 170px
        }

        .back,
        .home {
            color: #000;
            padding: 5px 0;
            width: 50%
        }

        .home {
            background-color: #ffb12a;
            border: 1px solid #bc4200;
            border-radius: 20px 0 0 20px;
            float: right
        }

        .back {
            background-color: #fdf243;
            border: 1px solid #bc4200;
            border-radius: 0 20px 20px 0;
            float: left
        }

        .footer_title {
            font-size: 18px;
            padding: 10px 0
        }

        .bg8 {
            background-color: #dc0340;
            border: 1px solid #84003b
        }

        @media only screen and (max-width:480px) {
            .footer {
                height: 140px
            }

            .back,
            .home {
                width: 70%;
                font-size: 16px
            }

            .footer_title {
                font-size: 14px;
                padding: 10px 0
            }
        }
    </style>

    <!--FOOTER START-->
    <style>
        .f_block {
            width: 100%;
            height: 50px;
        }

        .ff1 {
            float: left;
            width: 50%;
        }

        .footer {
            width: 100%;
            box-sizing: border-box;
            /* float: left; */
            text-align: center;
            color: #fff;
            font-size: 20px;
            font-weight: 700;
            font-family: myfont1;
            height: 100% !important;
            clear: both;
        }
              .fixed_menubar {
            display: block;
            width: 100%;
            background-color: #f2f2f2;
            border-top: 1px solid #d9d9d9;
            height: 68px;
            z-index: 10;
            position: fixed;
            bottom: 0;
        }

        .bottom_menus {
            width: 25%;
            float: left;
            cursor: pointer;
            text-align: center;
        }

            .bottom_menus > i {
                color: #bfbfbf;
                font-size: 28px;
                padding: 6px 0;
            }

                .bottom_menus > i:hover {
                    color: #ff4d4d
                }

        .bottom_menus_title {
            color: #a6a6a6;
            font-weight: 700;
            margin: 0px 0 0 0;
            font-size: 15px;
            font-family: myfont1;
            /* line-height:18px; */
        }

        .bb1 {
            color: #133E8C;
        }

        @media only screen and (max-width:480px) {
            .fixed_menubar {
                display: block;
                width: 100%;
                background-color: #f2f2f2;
                border-top: 1px solid #d9d9d9;
                height: 58px;
                z-index: 10;
                position: fixed;
                bottom: 0;
            }

            .bottom_menus {
                width: 20%;
                float: left;
                cursor: pointer;
                text-align: center;
            }

                .bottom_menus > img {
                }

            .bottom_menus_title {
                color: #a6a6a6;
                font-size: 11px;
                font-family: myfont1;
                line-height: 12px;
            }

            .bb1 {
                color: #133E8C;
            }
        }
            .b14 {
            position: fixed;
            bottom: 75px;
            left: 15px;
            border: 1px solid #141313;
            background: #2c2841 !important;
            color: #fff;
            padding: 5px;
            font-style: italic;
            font-weight: bold;
            border-radius: 5px;
            text-align: center;
            background-color: #2481cc !important;
        }
          .k-content {
        height: 100px !important;
    }
     table.k-editor {
        width: 100% !important;
        height: 100px !important;
        font-size: 100%;
        vertical-align: top;
        position: relative;
        border: 0px !important;
        background-color: lightgray !important;
    }

    /* pre {
        white-space: inherit;
        display: block;
        padding: 9.5px;
        margin: 0 0 10px;
        font-size: 13px;
        line-height: 1.42857143;
        color: #333333;
        word-break: break-all;
        word-wrap: break-word;
        background-color: none !important;
        border: 0px solid #ccc !important;
        border-radius: 0px;
    }*/

    pre {
        white-space: pre-line;
        display: block;
        padding-bottom: 0px;
        margin: 0px;
        font-size: 15px;
        background-color: #ffffff;
        overflow: hidden;
    }

    .pre {
        white-space: pre-wrap;
        display: block;
        padding-bottom: 0px;
        margin: 0px;
        font-size: 15px;
        background-color: #ffffff;
        overflow: hidden;
    }

    .name-field {
        width: 60% !important;
        color: #00a !important;
        background-color: #ffd1d1 !important;
        background-repeat: repeat-x !important;
        background-position: 50% bottom !important;
        margin-right: 1px !important;
        padding: 1px 4px !important;
        border: 0px solid #d3cabd !important;
    }

    /*input {
        color: #00a !important;
        background-color: #ffd1d1 !important;
        background-repeat: repeat-x !important;
        background-position: 50% bottom !important;
        margin-right: 1px !important;
        padding: 1px 4px !important;
        border: 0px solid #d3cabd !important;
    }*/

    .k-editor .k-editable-area .k-content {
        box-sizing: border-box;
        border-width: 0px !important;
        border-style: solid;
        /*background-color: #fde7e7 !important;*/
    }

    .k-editor .k-editable-area {
        width: 100%;
        height: 100%;
        outline: 0;
        border: 0px;
        /*  background-color: #fde7e7 !important;*/
    }

    table.k-editor {
        width: 100%;
        height: 250px;
        table-layout: fixed;
        border-style: none;
        border-collapse: separate;
        border-spacing: 0px !important;
        font-size: 100%;
        vertical-align: top;
        position: relative;
        border-width: 0px !important;
        border-color: none !important;
        border-radius: 0px !important;
        background-color: #FFD9D9 !important;
    }

    .k-gantt-toolbar .k-state-default, .k-grid .k-grouping-header, .k-grid-header, .k-grid-header-wrap, .k-grouping-header .k-group-indicator, .k-header, .k-pager-wrap, .k-pager-wrap .k-link, .k-pager-wrap .k-textbox {
        border-width: 0px !important;
        border-color: none !important;
        border-radius: 0px !important;
    }
      .o2 a.currentpage {
        border: 1px solid red;
        padding: 3px;
    }

    .o2 a:hover {
        border: 1px solid red;
    }
     .tox .tox-statusbar {
        display: none !important;
    }
        input[type=checkbox] {
        height: 0;
        width: 0;
        visibility: hidden;
    }

    label {
        cursor: pointer;
        text-indent: -9999px;
        width: 50px;
        height: 20px;
        background: grey;
        display: flex;
        border-radius: 40px;
        position: relative;
    }

        label:after {
            content: '';
            position: absolute;
            top: 3px;
            left: 2px;
            width: 15px;
            height: 15px;
            background: #fff;
            border-radius: 15px;
            transition: 0.3s;
        }

    input:checked + label {
        background: #DC143C;
    }

        input:checked + label:after {
            left: calc(100% - 5px);
            transform: translateX(-100%);
        }

    label:active:after {
        width: 130px;
    }
    </style>
	
    <div class="footer bg8" style="margin:15px 0 75px 0;">
	



</p>
	<br/>
        <p class="footer_title">
            SERVER: AD BOSSMATKA GUESSING
            
            <br> ALL RIGHTS RESERVED (2024-2025)
            <br> CONTACT ADMIN
        </p>
        <div class="f_block">
            <a href="{{ route('home.index')}}">
                <div class="ff1">
                    <div class="home">HOME</div>
                </div>
            </a>
            <a href="">
                <div class="ff1">
                    <div class="back">BACK</div>
                </div>
            </a>
        </div>
    </div>
    <!--FOOTER end-->
    <!-- jQuery library -->
    <script>
        function gotobottum() {
            $("html, body").animate({
                scrollTop: $(document).height()
            }, 1000);
        }

        function gototop() {
            $('html,body').animate({ scrollTop: 0 }, "slow");
        }
    </script>
    <!--------------------------fixed navigation start-------------------------->
  
    <div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog">
    <!-- Modal Content -->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Form</h4>
      </div>
      <div class="modal-body">
        <form id="dynamicForm">
            @csrf
            
          <div class="form-group">
           <textarea type="text" class="form-control" id="addTextarea" name="exparts"></textarea>
        </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" id="submitForm">Submit</button>
      </div>
    </div>
  </div>
</div>
    <div class="fixed_menubar">
               <a style="text-decoration:none;color:#003f6b !important" href="{{ route('home.index')}}">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/home-grey.png" width="25" alt="satta-matka" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title ">Home</p>
            </div>
        </a>
        <a style="text-decoration:none;color:#003f6b !important" href="{{route('home.ResultGuessing')}}">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/guessing-forum.png" width="25" alt="guessing-forum" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title bb1">
                    Guessing
                    <br />Forum
                </p>
            </div>
        </a>
        <a style="text-decoration:none;color:#003f6b !important" href="">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/guessing-forum.png" width="25" alt="chatting -forum" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title">
                    Chatting
                    <br />Forum
                </p>
            </div>
        </a>
        <a style="text-decoration:none;color:#003f6b !important" href="{{route('home.expertGuessing')}}">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/experts-forum-grey.png" width="25" alt="experts-forum" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title  ">
                    Experts
                    <br />Forum
                </p>
            </div>
        </a>
        <!--a style="text-decoration:none;color:#003f6b !important" href="tricks-forum.php" >
         <div class="bottom_menus">
            <img src="icon_g/trick-forum.png" width="25" alt="tricks-forum" style="margin:4px 0 0 0;" />
            <p class="bottom_menus_title  ">Tricks<br/>Forum</p>
         </div>
         </a-->
        <a style="text-decoration:none;color:#003f6b !important" href="javascript:void(0);" onclick="window.location.reload();">
            <div class="bottom_menus">
                <img src="../../index_files/refresh2.png" width="25" alt="Refresh" style="margin:4px 0 0 0;">
                <p class="bottom_menus_title ">
                    Refresh
                    <br>Page
                </p>
            </div>
        </a>
    </div>
    
    
    <style>
        .a14 {
            position: fixed;
            bottom: 60px;
            right: 5px;
            cursor: pointer;
            padding: 5px;
        }
    </style>
    <!--------------------------fixed navigation end-------------------------->
    <!--------------------------fixed navigation start-------------------------->
    <!--------------------------fixed navigation end-------------------------->
    <div id="btm"></div>
    
    <script>
        $(document).ready(function () {
            $('.only_quoted_exp').click(function () {
                if ($('.only_quoted_exp').prop("checked") == true) {
                    var val = 1;
                    $.ajax({
                        type: "POST",
                        url: "expsetting.php",
                        data: {
                            id: val
                        },
                        success: function (response) {
                            window.location.reload();
                        }
                    });
                } else {
                    var val = 0;
                    $.ajax({
                        type: "POST",
                        url: "expsetting.php",
                        data: {
                            id: val
                        },
                        success: function (response) {
                            window.location.reload();
                        }
                    });
                }
            });
        });

        $('.accordion').click(function () {
            $(".panel").toggle("active");
        });

        function gotobottum() {
            $("html, body").animate({
                scrollTop: $(document).height()
            }, 1000);
        }

        //function gototop() {
        //    $("html, body").animate({
        //        scrollTop: 0
        //    });
        //}
    </script>
    <!--
         FILE ARCHIVED ON 04:16:56 May 13, 2020 AND RETRIEVED FROM THE
         INTERNET ARCHIVE ON 14:50:11 Mar 14, 2021.
         JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

         ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
         SECTION 108(a)(3)).
    -->
    <!--
    playback timings (ms):
      captures_list: 2436.707
      PetaboxLoader3.datanode: 84.153 (4)
      LoadShardBlock: 2401.752 (3)
      RedisCDXSource: 0.774
      PetaboxLoader3.resolve: 59.725
      CDXLines.iter: 29.946 (3)
      exclusion.robots: 0.421
      exclusion.robots.policy: 0.404
      load_resource: 301.138
      esindex: 0.017
    -->


	



<script>
     
     

    function ShowAlert() {
    $.ajax({
        url: "{{route('home.ShowAlert')}}", // Laravel route ka URL
        type: 'POST', // Request type (POST, GET, etc.)
        data: {
            _token: $('meta[name="csrf-token"]').attr('content'), // CSRF token
            customData: 'Some data here' // Agar aapko additional data bhejna ho
        },
         success: function(response) {
             
            if (response.success == true) {
            $('#myModal').modal('show');
            } else {
                alert(response.message); // Show the response message
            }
        },
        
    });
}


    function PostForumTopic(){

        var isUserLoggedIn = '';

        var data =
        {
            //pageNo:0,
            ForumType:3,
            //Subject: tinymce.get("Comm").getContent()
            Subject: $("#Comm").val()
            //Subject: $("#txtforumPost").val()
        };
        console.log(data);

        //var myContent = tinymce.get("Comm").getContent();
        //console.log(myContent);


         $.ajax({
             url: '/Home/PostForumTopic',
             type: 'POST',
             data: JSON.stringify({ forumModel: data}),
             dataType: "json",
             cache: false,
             contentType: "application/json; charset=utf-8",
             success: function(response) {
                 //var json = JSON.parse(response);
                 var base_url = window.location.origin;
                 debugger;
                 if (response.code == 1) { // User not Logged in
                     console.log('User not Logged in')
                     window.location.replace(base_url + '/Home/Login');
                 }
                 else {
                     window.location.replace(window.location.href.split('?')[0]);
                 }
             },
             error: function(response) {
                 var json = JSON.parse(response);
                 alert(json["message"]);
             }
         });

    }

    function ShowHideForumComment(touserid) {
        console.log("#forumComment_" + touserid);
        $("#forumComment_" + touserid).show();
        return false;
    }

    $(document).ready(function () {
    // Add a new textarea dynamically
   

    // Handle form submission via AJAX
    $('#submitForm').on('click', function (e) {
        e.preventDefault();

        var formData = new FormData($('#dynamicForm')[0]);

        $.ajax({
            url: "{{ route('home.exportsstore')}}", // Define your Laravel route here
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                // Handle success (e.g., show success message)
                alert('Form submitted successfully!');
                $('#myModal').modal('hide');
                window.location.reload();
            },
            error: function (xhr, status, error) {
                // Handle error (e.g., show error message)
                alert('Something went wrong!');
            }
        });
    });
});

    function PostForumComment(touserid, forumid){

        var btnQuote = $("#btnForumPost_" + forumid);

        var data =
        {
            UserId: touserid,
            Subject: tinymce.get("txtForumComment" + forumid).getContent(),
            //Subject: $("#txtForumComment" + forumid).val(),
            ForumId: forumid,
            ForumType: 3,
        };


         $.ajax({
         url: '/Home/PostForumComment',
             type: 'POST',
             data: JSON.stringify({ forumModel: data}),
             dataType: "json",
             cache: false,
             contentType: "application/json; charset=utf-8",
             success: function (response) {
                 console.log(response);
                 if (response.code == 1) { // User not Logged in
                     window.location.replace('/Home/Login');
                 }
                 console.log(window.location.href.split('?')[0]);
                 window.location.replace(window.location.href.split('?')[0]);
             },
             error: function (response) {
                 var json = JSON.parse(response);
                 alert(json["message"]);
             },
             beforeSend: function () {
                 console.log('beforeSend event');
                 $("#btnForumPost_" + forumid).prop('disabled', true);
             },
             complete: function () {
                 console.log('complete event');
                 $("#btnForumPost_" + forumid).prop('disabled', false);
             }
        });
    }

    function DeleteForumPost(forumid){

        var data =
        {
            ForumId: forumid,
            ForumType: 3,
        };

         $.ajax({
             url: '/Home/DeleteForumPost',
             type: 'POST',
             data: JSON.stringify({ forumModel: data}),
             dataType: "json",
             cache: false,
             contentType: "application/json; charset=utf-8",
             success: function (response) {
                 if (response.success == true) {
                     alert('Forum Post Deleted successfully');
                     //Remove html tag from DOM
                     $("#listitem_" + forumid).remove();
                 }
             },
             error: function (response) {
                 //var json = JSON.parse(response);
                 console.log(response);
                 //alert(json["message"]);
             },
        });
}

 function BlockUser(id){

        $.ajax({
            url: '/Home/BlockUser'+ "/"+ id,
            type: 'POST',
            //dataType: "json",
            data: id,
            cache: false,
            //contentType: "application/json; charset=utf-8",
            success: function (result) {
                alert(result);
                },
                error: function (result) {
                   alert(result);
                }
            });
    }

</script>



<script>

    function gototop() {
        $('html,body').animate({ scrollTop: 0 }, "slow");
    }

</script>

<script>
    $(document).ready(function () {

        $("#txtAutoSearch").on("keyup", function () {
            var value = $(this).val().toLowerCase();
            $("#forumrows div.eachforumrow").filter(function () {
                //console.log($(this).find("div:nth-child(2) > font:nth-child(2) > b"));
                //console.log($(this).find("div:nth-child(2) > font:nth-child(2) > b").text().toLowerCase().indexOf(value));
                //$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                //$(this).toggle($(this).find("div:nth-child(2) > font:nth-child(2) > b").text().toLowerCase().indexOf(value) > -1)
            });
        });
    });

    function FilterPosts() {
        var value = $("#txtAutoSearch").val().toLowerCase();

        $("#forumrows div.eachforumrow").filter(function () {
            $(this).toggle($(this).find("div:nth-child(2) > font:nth-child(2) > b").text().toLowerCase().indexOf(value) > -1)
        });
    }

</script>




</body>

</html>