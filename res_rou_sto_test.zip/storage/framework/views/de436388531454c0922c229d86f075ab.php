<div class="header">
<div class="header-left">
 <img src="<?php echo e(url('front-assets/images/logo.jpg')); ?>" width="200px">
</div>
    
<div class="top-nav-search">

</div>
<a class="mobile_btn" id="mobile_btn">
<i class="fas fa-bars"></i>
 <img src="<?php echo e(url('front-assets/images/logo.jpg')); ?>" width="200px">
</a>

    <ul class="nav user-menu">

        <li class="nav-item dropdown has-arrow new-user-menus">

            <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">

                <span class="user-img">

<img class="rounded-circle" src="<?php echo e(url('assets/img/icons/dash-icon-01.svg')); ?>" width="31" alt="Ryan Taylor">

<div class="user-text">

<h6><?php echo e(ucfirst(Auth::guard('admin')->name)); ?></h6>

</div>

</span>

    </a>

      <div class="dropdown-menu">

          <a class="dropdown-item" href="<?php echo e(route('admin.Adminlogout')); ?>" onclick="event.preventDefault(); document.getElementById('logout').submit();">Log Out</a>

        <form id="logout" action="<?php echo e(route('admin.Adminlogout')); ?>" method="get" style="display: none;">



        <?php echo csrf_field(); ?>



    </form>



</div>



        </li>



    </ul>



</div><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/admin/include/header.blade.php ENDPATH**/ ?>