<!DOCTYPE html>
<html lang="en-US">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Indore Bazar</title>
    <meta name="description" content="madhur bazar a site for madhur satta matka pune madhur day result and madhur matka night morning open close.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="cache-control" content="max-age=0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">
    <meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT">
    <meta http-equiv="pragma" content="no-cache">
    <meta property="og:title" content="Madhur Bazar | Satta Matka | Madhur Day | Madhur Matka">
    <meta property="og:description" content="madhur bazar a site for madhur satta matka pune madhur day result and madhur matka night morning open close.">
    <meta property="og:image" content="https://Indorematka.com/madhur-bazar-card.png">
    <link rel="stylesheet" href="{{url('front-assets/main-page.css')}}">
    <link rel="canonical" href="{{url('/')}}">
    <link rel="shortcut icon" href="favicon.ico">
    <style>
        .downarrowgif
        {
            width: 3%;
        }
        
        .clickhere_img
        {
            width: 10%;
        }
        
        @media  only screen and (max-width: 600px) {
          .clickhere_img {width: 35%;}
          .downarrowgif {width: 7%;}
        }
    </style>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-125083267-3" type="e3ffce39f66564dac901f926-text/javascript"></script>
    <script type="e3ffce39f66564dac901f926-text/javascript">
        window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
        
          gtag('config', 'UA-125083267-3');
    </script>
</head>

<body>
    <div class="matka_live bg3">
        <h1>Madhur Bazar Day Madhur Satta Matka</h1></div>
    <div class="game_zone gz3">
        {!! $HeaderDes->description !!}
    </div>
    <div class="live_update">
        <div class="live_head">Live Update</div>
        @foreach($matkaresults as $matkaresult)
    @php
        $today = \Carbon\Carbon::today();
        $now = \Carbon\Carbon::now(); // Current time
        
        // Fetch the 'patta_value' for the current 'matkaresult' from today's entries
        $matkaresultpatta = App\Models\MatkaResult::whereDate('created_at', $today)
            ->where('title', $matkaresult->title)
            ->pluck('patta_value', 'created_at');

        // Get the first and second patta values and their creation times
        $patta1 = $matkaresultpatta->first() ?? null;
        $patta1CreatedAt = $matkaresultpatta->keys()->first() ?? null;
        
        $patta2 = $matkaresultpatta->skip(1)->first() ?? null;
        $patta2CreatedAt = $matkaresultpatta->skip(1)->keys()->first() ?? null;

        $totalSum = 0;
        $totalSum1 = 0;

        if ($patta1) {
            $digits = str_split((string)$patta1);
            foreach ($digits as $digit) {
                $totalSum += (int)$digit;
            }
        }

        if ($patta2) {
            $digits1 = str_split((string)$patta2);
            foreach ($digits1 as $digit1) {
                $totalSum1 += (int)$digit1;
            }
        }
        $lastDigit1 = $totalSum % 10;
        $lastDigit2 = $patta2 !== null ? ($totalSum1 % 10) : '';
        $showPatta1 = $patta1 && $now->diffInMinutes($patta1CreatedAt) <= 45;

        $showBoth = $patta2 && $now->diffInMinutes($patta2CreatedAt) <= 45;
    @endphp

    @if($showPatta1 || $showBoth) <!-- Show if patta1 is within 45 mins or both should be shown -->
        <div class="matka_result_box">
            <p class="matka_title">{{ ucwords($matkaresult->title) }}</p>
            <p class="matka_num">
                @if($showBoth) <!-- Show both patta1 and patta2 if $patta2 exists and is within 45 minutes -->
                    {{ $patta1 }} - {{ $lastDigit1 }}{{ $lastDigit2  }} - {{ $patta2 }}
                @elseif($showPatta1) <!-- Otherwise, show only patta1 -->
                    {{ $patta1 }} - {{ $lastDigit1 }}
                @endif
            </p>
        </div>
    @endif
@endforeach


    </div>
    <div>
        <button class="refresh_btn" onClick="if (!window.__cfRLUnblockHandlers) return false; window.location.reload()" data-cf-modified-e3ffce39f66564dac901f926->Refresh</button>
    </div>
    <div class="game_zone gz3">
        <p>अब खेलिए ऑनलाइन सट्टा मटका सबसे भरोसेमंद वेबसाइट के साथ।</p>
        <p>विश्वास का धंदा विश्वास के साथ</p>
        <img src="front-assets/images/downarrowgif1.gif" alt="Facebook" class="downarrowgif">
        <br>
        <a href="https://samaybazar.com/superstar.apk" rel="nofollow"><img src="front-assets/images/google_playstore2.png" alt="Facebook" class="clickhere_img"></a>
    </div>
    <div class="game_zone gz3">
        <div class="matka_result_box" style="text-align:center;">
            <p style="font-size:xx-large">:#: NOTICE :#:</p>
           {!! $Notices->description!!}
        </div>
    </div>
    <div class="game_zone gz3">
        <p style="text-align:center;font-size:22px;font-weight:700;color:blue;">
            &#2309;&#2327;&#2352; &#2310;&#2346; &#2326;&#2369;&#2342; &#2325;&#2366; &#2350;&#2335;&#2325;&#2366; &#2330;&#2354;&#2366;&#2340;&#2375; &#2361;&#2376;&#2306; &#2324;&#2352; &#2313;&#2360;&#2325;&#2366; &#2352;&#2367;&#2332;&#2354;&#2381;&#2335; &#2361;&#2350;&#2366;&#2352;&#2368;
            &#2360;&#2366;&#2311;&#2335; &#2346;&#2352; &#2354;&#2327;&#2357;&#2366;&#2344;&#2366; &#2330;&#2366;&#2361;&#2340;&#2375; &#2361;&#2376;&#2306;, &#2340;&#2379; &#2332;&#2354;&#2381;&#2342; &#2361;&#2368; &#2360;&#2350;&#2381;&#2346;&#2352;&#2381;&#2325;
            &#2325;&#2352;&#2375;&#2306;
        </p>
        <p style="text-align:center;font-size:28px;font-weight:700;color:red;"></p>
    </div>
    <div class="m_live">
        <div class="matka_live bg3"><h2>All Satta Matka Result</h2></div>
    </div>
    <div class="matka_result">
    @foreach($matkaresults as $matkaresult)
    @php
        // Fetch the latest 'patta_value' entries for the current 'matkaresult' title and get the last two entries
        $matkaresultpatta = App\Models\MatkaResult::where('title', $matkaresult->title)
            ->latest()
            ->select('patta_value', 'lasttime', 'firsttime')
            ->get()
            ->take(-4) // Get the latest -4 entries and work backwards to avoid any data gaps
            ->slice(-2) // Get the last two entries from this selection
            ->values(); // Get the last two 'patta_value' entries
        // echo "<pre>";print_r($matkaresultpatta);
        // Assign the last two entries to variables with null fallback
         $patta1 = $matkaresultpatta->get(0)->patta_value ?? null;
        $patta2 = $matkaresultpatta->get(1)->patta_value ?? null;

        // Initialize sum variables for digits
        $totalSum1 = 0;
        $totalSum2 = 0;

        // Calculate the sum of digits for $patta1 if it exists
        if ($patta1) {
            $digits1 = str_split((string)$patta1);
            foreach ($digits1 as $digit) {
                $totalSum1 += (int)$digit;
            }
        }

        // Calculate the sum of digits for $patta2 if it exists
        if ($patta2) {
            $digits2 = str_split((string)$patta2);
            foreach ($digits2 as $digit) {
                $totalSum2 += (int)$digit;
            }
        }

        // Calculate the last digit (mod 10) of the sums
        $lastDigit1 = $totalSum1 % 10;
        $lastDigit2 = $patta2 !== null ? ($totalSum2 % 10) : '';
        
         $patta1 = $matkaresultpatta->get(0)->patta_value ?? null;
        $patta2 = $matkaresultpatta->get(1)->patta_value ?? null;

        // Calculate the sum of digits for $patta1 and $patta2
        $totalSum1 = $patta1 ? array_sum(str_split((string)$patta1)) : 0;
        $totalSum2 = $patta2 ? array_sum(str_split((string)$patta2)) : 0;

        // Calculate the last digit (mod 10) of the sums
        $lastDigit1 = $totalSum1 % 10;
        $lastDigit2 = $patta2 !== null ? ($totalSum2 % 10) : '';
    @endphp

    <div class="matka_result_box" style="position: relative;">
        @if(isset( $matkaresult->jodi_url ))
        <a href="{{ $matkaresult->jodi_url}}" 
           style="position: absolute; left: 20px; bottom: 67px; border: 2px solid #333; background-color: #d70aee; color: #fff !important; padding: 5px 23px; border-radius: 8px 0; box-shadow: 0px 0px 1px #000000d6; font-size: 15px; margin: 2px 0 -1px; display: block; transition: all .3s; text-shadow: 1px 1px 2px #222; margin-top: 5px; font-weight: 800;">
           Jodi
        </a>
        @else
            <a href="{{ route('home.jodi',str_replace(' ', '_', $matkaresult->title) ) }}" 
           style="position: absolute; left: 20px; bottom: 67px; border: 2px solid #333; background-color: #d70aee; color: #fff !important; padding: 5px 23px; border-radius: 8px 0; box-shadow: 0px 0px 1px #000000d6; font-size: 15px; margin: 2px 0 -1px; display: block; transition: all .3s; text-shadow: 1px 1px 2px #222; margin-top: 5px; font-weight: 800;">
           Jodi
        </a> 
        @endif
        <p class="matka_title">{{ ucwords($matkaresult->title) }}</p>
        <p class="matka_num">
        {{ $patta1 }} - {{ $lastDigit1 }}{{ $lastDigit2  }} - {{ $patta2 }}
        </p>
        <div class="mediumblue size3">
            ({{ \Carbon\Carbon::createFromFormat('H:i:s', $matkaresult->firsttime)->format('h:i A') }} - {{ \Carbon\Carbon::createFromFormat('H:i:s', $matkaresult->lasttime)->format('h:i A') }})
        </div>
        <br>
        @if(isset( $matkaresult->panel_url ))
        <a href="{{ $matkaresult->panel_url }}" 
           style="position: absolute; right: 20px; bottom: 67px; border: 2px solid #333; background-color: #d70aee; color: #fff !important; padding: 5px 23px; border-radius: 8px 0; box-shadow: 0px 0px 1px #000000d6; font-size: 15px; margin: 2px 0 -1px; display: block; transition: all .3s; text-shadow: 1px 1px 2px #222; margin-top: 5px; font-weight: 800;">
           Panel
        </a>
        @else
        <a href="{{ route('home.panel',str_replace(' ', '_', $matkaresult->title) ) }}" 
           style="position: absolute; right: 20px; bottom: 67px; border: 2px solid #333; background-color: #d70aee; color: #fff !important; padding: 5px 23px; border-radius: 8px 0; box-shadow: 0px 0px 1px #000000d6; font-size: 15px; margin: 2px 0 -1px; display: block; transition: all .3s; text-shadow: 1px 1px 2px #222; margin-top: 5px; font-weight: 800;">
           Panel
        </a>
        @endif
    </div>
@endforeach


 
    
        <p style="font-size:18px;color:blue;padding:0px 1px;">&#2309;&#2327;&#2352; &#2310;&#2346; &#2326;&#2369;&#2342; &#2325;&#2366; &#2350;&#2366;&#2352;&#2381;&#2325;&#2375;&#2335; &#2352;&#2367;&#2332;&#2354;&#2381;&#2335; &#2354;&#2327;&#2357;&#2366;&#2344;&#2366; &#2330;&#2366;&#2361;&#2340;&#2375;
            &#2361;&#2376; &#2340;&#2379; &#2360;&#2306;&#2346;&#2352;&#2381;&#2325; &#2325;&#2352;&#2375;
            <br> (agar aap khud ka game chalate hain aur uska result humari site par lagwana chahte hain, to jaldi sampark kare official site. Agar aap daily paisa kamana chahte hain to jald hi sampark kare )</p>
    </div>
    <div class="matka_live bg3">
        <h2>Fastest Madhur Day Result site live update</h2></div>
    <div class="game_zone gz3">
    {!! $FastestLiveUpdates->description!!}
    </div>
    <div class="matka_live bg3">
        <button onclick="if (!window.__cfRLUnblockHandlers) return false; window.location.href='{{route('home.login')}}'" class="i_btn1" data-cf-modified-e3ffce39f66564dac901f926->LOGIN</button>
        <button onclick="if (!window.__cfRLUnblockHandlers) return false; window.location.href='{{route('home.register')}}'" class="i_btn1" data-cf-modified-e3ffce39f66564dac901f926->REGISTER</button>
    </div>
    <div class="game_zone gz3">
        <p class="game_title"><a href="{{route('home.ResultGuessing')}}">GUESSING FORUM</a></p>
    </div>
    <div class="matka_live bg3" style="margin:15px 0 0 0;">
        <h2>Know Madhur Matka</h2></div>
    <div class="game_zone gz3">
    {!! $KnowDes->description!!}
    </div>
 <!--   <div class="matka_live bg3">PANEL CHART WITH PATTI</div>
     <div class="game_zone gz3">
        <p class="game_title4"><a href="time-bazar-panel-chart.php" title="Time Bazar Chart">TIME</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="madhur-day-panel-chart.php" title="Madhur Day Chart">MADHUR DAY</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="madhur-night-panel-chart.php" title="Madhur Night Chart">MADHUR NIGHT</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="sridevi-panel-chart.php" title="Sridevi Chart">SRIDEVI</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="sridevi-night-panel-chart.php" title="Sridevi Night Chart">SRIDEVI NIGHT</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="supreme-day-panel-chart.php" title="Supreme Day Chart">SUPREME DAY</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="supreme-night-panel-chart.php" title="Supreme Night Chart">SUPREME NIGHT</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="rajdhani-day-panel-chart.php" title="Rajdhani Day Chart">RAJDHANI DAY</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="rajdhani-night-panel-chart.php" title="Rajdhani Night Chart">RAJDHANI NIGHT</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="milan-day-panel-chart.php" title="Milan Day Chart">MILAN DAY</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="milan-night-panel-chart.php" title="Milan Night Chart">MILAN NIGHT</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="kalyan-panel-chart.php" title="Kalyan Panel Chart">KALYAN PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="kalyan-sunday-panel-chart.php" title="Kalyan Sunday Panel Chart">KALYAN SUNDAY PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="kalyan-night-panel-chart.php" title="Kalyan Night Panel Chart">KALYAN NIGHT PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="main-bazar-panel-chart.php" title="Main Bazar Panel Chart">MAIN BAZAR PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="super-star-day-panel-chart.php" title="Superstar Day Panel Chart">SUPERSTAR DAY PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="super-star-night-panel-chart.php" title="Superstar Night Panel Chart">SUPERSTAR NIGHT PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="agra-morning-panel-chart.php" title="Agra Morning Panel Chart">AGRA MORNING PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="agra-day-panel-chart.php" title="Agra Day Panel Chart">AGRA DAY PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="agra-night-panel-chart.php" title="Agra Night Panel Chart">AGRA NIGHT PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="marshal-day-panel-chart.php" title="Marshal Day Panel Chart">MARSHAL DAY PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="marshal-night-panel-chart.php" title="Marshal Night Panel Chart">MARSHAL NIGHT PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="http://rsmatka.net/penal.php?id=95" title="Samay Day Panel Chart">SAMAY DAY PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="http://rsmatka.net/penal.php?id=96" title="Samay Night Panel Chart">SAMAY NIGHT PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="kohinoor-day-panel-chart.php" title="Kohinoor Day Panel Chart">KOHINOOR DAY PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="kohinoor-night-panel-chart.php" title="Kohinoor Night Panel Chart">KOHINOOR NIGHT PANEL CHART</a></p>
    </div>

    <div class="game_zone gz3">
        <p class="game_title4"><a href="city-day-panel-chart.php" title="City Day Panel Chart">CITY DAY PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="city-night-panel-chart.php" title="City Night Panel Chart">CITY NIGHT PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="https://dpbossx.net/padmavati-panel-chart.php" title="Padmavati Panel Chart">PADMAVATI PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="https://dpbossx.net/padmavati-night-penal-chart-record.php" title="Padmavati Panel Chart">PADMAVATI NIGHT PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="https://my.satta143.in/indian-day-panel-chart.php" title="Indian Day Panel Chart">INDIAN DAY PANEL CHART</a></p>
    </div>
    <div class="game_zone gz3">
        <p class="game_title4"><a href="https://my.satta143.in/indian-night-panel-chart.php" title="Indian Night Panel Chart">INDIAN NIGHT PANEL CHART</a></p>
    </div> -->

    <div class="matka_live bg3">
        <h3>Know about Madhur Satta Bazar</h3>
    </div>
    <div class="game_zone gz3">
    {!! $KnowAbouts->description!!}
    </div>
    <div class="matka_live bg3">
        <h3>What is Satta Matka ?</h3>
    </div>
    <div class="game_zone gz3">
    {!! $SattaMatkas->description!!}
    </div>
    <div class="footer bg3" style="margin:10px 0 10px 0;">
        <p class="footer_title">IndoreMatka.com
            <br> ALL RIGHTS RESERVED (2012-2024)</p>
    </div>
    <input style="position:fixed;bottom:20px;right:20px;border:#141313 1px solid;background:#d9534f;color:white;height:auto;padding:5px;" class="btn btn-md btn-danger" value="Refresh" type="button" onClick="if (!window.__cfRLUnblockHandlers) return false; window.location.reload()"
    data-cf-modified-e3ffce39f66564dac901f926->
    <script type="application/ld+json">
        { "@context": "https://schema.org/", "@type": "Product", "name": "madhur bazar", "image": "https://Indorematka.com/madhur-bazar-card.png", "description": "madhur bazar a site for madhur satta matka indore madhur day result and madhur matka night morning open
        close.", "brand": { "@type": "Thing", "name": "madhur day" }, "mpn": "95812", "offers": { "@type": "AggregateOffer", "priceCurrency": "INR", "highPrice": "12000", "lowPrice": "6000", "offerCount": "9999" }, "aggregateRating": { "@type": "AggregateRating",
        "ratingValue": "5", "bestRating": "5", "worstRating": "1", "ratingCount": "125678", "reviewCount": "9890" }, "sku": "20356", "review": { "@type": "Review", "author": "madhur matka", "datePublished": "2018-04-01", "description": "The official madhur
        bazar site for madhur day matka result and madhur satta game.", "name": "Very Happy and Satisfy Customer", "reviewRating": { "@type": "Rating", "bestRating": "5", "ratingValue": "5", "worstRating": "1" } } }
    </script>
    <script src="{{url('front-assets/rocket-loader.min.js')}}" data-cf-settings="e3ffce39f66564dac901f926-|49" defer></script>
    <script>
        (function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'8d1452552b88426c',t:'MTcyODcwNzA4MC4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();
    </script>
    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"8d1452552b88426c","version":"2024.10.1","r":1,"serverTiming":{"name":{"cfExtPri":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"token":"41cfb4a3a50b49079919ccd461b75608","b":1}'
    crossorigin="anonymous"></script>
</body>

</html>