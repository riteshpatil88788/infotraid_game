<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\PlayList;

class PlayListController extends Controller
{
 
    public function index()
    {
        $data['matkaresults'] = DB::table('matka_results')->orderBy('id','desc')->groupBy('title')->get();
        $data['playlists'] = DB::table('play_lists')->orderBy('id','desc')->get();
        $data['title'] = "Play List";
        return view('admin.play-list.index',$data);
    }

    public function create(){
        $data['title'] = "Play List";
        $data['matkaresults'] = DB::table('matka_results')->orderBy('id','desc')->groupBy('title')->get();
        $data['plays'] = DB::table('plays')->orderBy('id','desc')->get();

        return view('admin.play-list.create',$data);
    }

    public function store(Request $request)
    {
     //   echo "<pre>";print_r($request->all());die;
        $request->validate([
            'title' => 'required',
            'play' => 'required|array',  // Validate that 'play' is an array
            'play.*' => 'string',         // Validate each item in the play array is a string
        ]);
    
        $PlayList = new PlayList;
    
        $PlayList->game_id = $request->title;
        $PlayList->play = implode(',', $request->play); // Convert the play array to a comma-separated string
        $PlayList->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $PlayList->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;
        $PlayList->save();
    
        session()->flash('success', 'Play List has been created !!');
        return redirect()->route('admin.playlist.index');
    }
    

    public function edit($id){
        $data['playlist'] = DB::table('play_lists')->where('id',$id)->first();
        $data['plays'] = DB::table('plays')->orderBy('id','desc')->get();
        $data['matkaresults'] = DB::table('matka_results')->orderBy('id','desc')->groupBy('title')->get();
        $data['title'] = "Play List";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('admin.play-list.edit',$data);
    }

    public function update(Request $request)
    {
        //  dd($request->all());
        $request->validate([
            'title' => 'required',
            'play' => 'required',
           
        ]);
        //  echo "<pre>";print_r($request->all());die;
        $PlayList = PlayList::find($request->id);
        $PlayList->game_id = $request->title;
        $PlayList->play = implode(',', $request->play);
        $PlayList->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $PlayList->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;
        $PlayList->save();
        // dd($user->toArray());
        session()->flash('success', 'Play List has been Update !!');
        return redirect()->route('admin.playlist.index');
    }

    public function destroy($id){
       
       
        $playlist = PlayList::find($id);
     
        $playlist->delete();
        session()->flash('success', 'Play Lists has been Deleted !!');
        return redirect()->route('admin.playlist.index');
    }
    
    public function resultlist()
    {
       $data['matkaresults'] = DB::table('matka_results')
    ->join('bid_history', 'matka_results.id', '=', 'bid_history.game_id')
    ->select(
        'matka_results.title',
        DB::raw('SUM(bid_history.amount) as total_bid_amount')
    )
    ->where('bid_history.status',0)
    ->groupBy('matka_results.title')

    ->get();
        // dd($data['matkaresults']);
        $data['title'] = "Total Market Bid List";
        return view('admin.marketbig-list',$data);
    }
    
public function bidList(Request $request)
{
   $query = DB::table('bid_history')
    ->join('matka_results', 'bid_history.game_id', '=', 'matka_results.id')
    ->join('users', 'bid_history.user_id', '=', 'users.id')
    ->join('plays', 'bid_history.play_game_id', '=', 'plays.id')
    ->select(
        'bid_history.*', 
        'matka_results.title as m_title', 
        'users.name', 
        'plays.title as p_title',
        DB::raw('SUM(bid_history.amount) as total_bid_amount')
    )
    ->groupBy('matka_results.title', 'users.name', 'plays.title');

if ($request->filled('name')) {
    $query->where('users.name', 'LIKE', '%' . $request->name . '%');
}

if ($request->filled('title')) {
    $query->where('matka_results.title', 'LIKE', '%' . $request->title . '%');
}

if ($request->filled('play')) {
    $query->where('plays.title', 'LIKE', '%' . $request->play . '%');
}

$bid_history = $query->get();

    //  dd($bid_history);
    return view('admin.bid-list', [
        'title' => 'Bid History',
        'bid_history' => $bid_history,
    ]);
}



public function filterBidHistory(Request $request)
{
    $query = DB::table('bid_history')
        ->join('matka_results', 'bid_history.game_id', '=', 'matka_results.id')
        ->join('users', 'bid_history.user_id', '=', 'users.id')
        ->join('plays', 'bid_history.play_game_id', '=', 'plays.id')
        ->select(
            'bid_history.*',
            'matka_results.title as m_title',
            'users.name',
            'plays.title as p_title'
        )
        ->where('bid_history.status', 0);

    // Apply filters dynamically
    if ($request->filled('name')) {
        $query->where('users.name', 'LIKE', '%' . $request->name . '%');
    }

    if ($request->filled('title')) {
        $query->where('matka_results.title', 'LIKE', '%' . $request->title . '%');
    }

    if ($request->filled('play')) {
        $query->whereDate('play.title', 'LIKE', '%' . $request->play . '%');
    }

    $data['bid_history'] = $query->get();
    // dd($data);
    return view('admin.big-list',$data);
}

    
}
