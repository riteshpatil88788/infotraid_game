@extends('admin.layout.app') @section('content')
<style>
    /* Default color for unchecked */
    .form-check-input {
        --checkbox-inactive-color: red; /* Color for inactive state */
        --checkbox-active-color: green; /* Color for active state */
    }

    /* Styling for checkbox */
    .form-check-input[type="checkbox"] {
        width: 2em;
        
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        border: 2px solid #555; /* Border color */
        border-radius: 5px; /* Border radius */
        outline: none;
        transition: background-color 0.3s ease, border-color 0.3s ease; /* Transition for smooth change */
    }

    /* Inactive state */
    .form-check-input:not(:checked)[type="checkbox"] {
        background-color: var(--checkbox-inactive-color);
        border-color: #555; /* Border color */
    }

    /* Active state */
    .form-check-input:checked[type="checkbox"] {
        background-color: var(--checkbox-active-color);
        border-color: #555; /* Border color */
    }

    /* Focus state */
    .form-check-input:focus {
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.3); /* Box shadow when focused */
    }
</style>
<div class="page-wrapper">
    <div class="content container-fluid">



        <div class="row">
            <div class="col-sm-12">
                <div class="card card-table">
                    <div class="card-body">

                        <div class="page-header">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="page-title">{{$title}}</h3>
                                </div>
                                <div class="col-auto text-end float-end ms-auto download-grp">
                                    <a href="{{ route('service.create') }}" class="btn btn-primary"><i class="fas fa-plus"></i></a>
                                </div>
                            </div>
                        </div>
                        @if (session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                @endif
                        <div class="table-responsive">
                            <table class="table border-0 star-student table-hover table-center mb-0 datatable table-striped">
                                <thead class="student-thread">
                                    <tr>
                                        <th>S.No</th>
                                      
                                        <th>Category</th>
                                        <th>Sub Category</th>
                                        <th>Status</th>
                                        <th class="text-end">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1;?>
                                    @foreach($services as $service)
                                    <tr>
                                        <td>{{$i}}</td>
                                      
                                        <td>
                                           {{ $service->c_title }}
                                        </td>
                                        <td>
                                           {{ $service->sc_title }}
                                        </td>
                                        <td>
                                            
                                            <div class="form-check form-switch">
                                              <input class="form-check-input statusCheck" type="checkbox"  id="statusCheck" data-id="{{ $service->id }}" {{ $service->status ? 'checked' : '' }}>
                                            </div>
                                        </td>
                                        <td class="text-end">
                                            <div class="actions">
                                                <a href="{{ route('service.edit', $service->id) }}" class="btn btn-sm bg-danger-light">
                                                    <i class="feather-edit"></i>
                                                </a>
                                                <a href="{{ route('service.destroy', $service->id) }}" class="btn btn-sm bg-success-light me-2" onclick="return confirmDelete()">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php $i++;?>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection
@section('script')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(document).ready(function() {
      
        $('.statusCheck').change(function() {
            
            var id = $(this).data('id');
            var status = $(this).prop('checked') ? 1 : 0;
            var confirmationMessage = status == 1 ? 'Are you sure you want to active?' : 'Are you sure you want to inactive?';
            if (confirm(confirmationMessage)) {
                $.ajax({
                    url: '{{ route("service.status") }}',
                    method: 'POST',
                    data: {
                        id: id,
                        status: status,
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        console.log('Status updated successfully.');
                       
                    },
                    error: function(xhr) {
                        console.error('Error updating status.');
                    }
                });
            } else {
                $(this).prop('checked', !status);
            }
        });
    });
</script>

</script>
@endsection
