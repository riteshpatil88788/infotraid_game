<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
    config(['app.timezone' => 'Asia/Kolkata']);
    date_default_timezone_set(config('app.timezone'));

    // डिफॉल्ट फॉर्मेटिंग (डायनामिक)
      \Carbon\Carbon::macro('formattedTime', function ($time) {
        return \Carbon\Carbon::parse($time)->format(config('app.time_format'));
    });
    }
}
