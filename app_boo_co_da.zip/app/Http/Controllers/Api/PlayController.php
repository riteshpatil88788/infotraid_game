<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\{Play,PlayList,GameData,GamePointAmuntBid};
use Carbon\Carbon;
 
class PlayController extends Controller
{
 
    public function index(Request $request)
    {
        $id = $request->query('game_id');
        $matka_results = DB::table('matka_results')->where('id',$id)->first();
        //  dd($matka_results);
        $playtitle = "";
        $playlists = DB::table('play_lists')->where('game_id',$matka_results->title)->first();
        //  dd($playlists);
        if($playlists){
        $playtitle = explode(',',$playlists->play);
        }
        $data = [];
     //  dd($playtitle);
        if($playtitle){
        foreach(array_reverse($playtitle) as $key => $value){
            $game =  DB::table('plays')->select('id', 'title', 'image', 'type')->where('title',trim($value))->first();
            // echo "<pre>";print_r($game);
            $imageUrl = url('images/' . $game->image);
            // echo "<pre>";print_r($imageUrl);
            $game->image = $imageUrl;
            $game->type = explode(",",$game->type);
            
            if($game){
            $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
      
            $ltime =  \Carbon\Carbon::formattedTime($matka_results->lasttime);
            ////$ftime = strtotime(date("Y-m-d") . " " . $ftime);
            //$ltime = strtotime(date("Y-m-d") . " " . $ltime);
            $etime = strtotime(date("Y-m-d") . " " . "12:00");
            if(implode(",",$game->type) == "open"){
             
             if(strtotime($ftime) > time()){    
                 $data[] = $game;
             }
            //  elseif(time() > $etime){
            //      dd(time() > $etime);
            //       $data[] = $game;
            //  }sd
            }elseif(implode(",",$game->type) == "open,close"){
               if(strtotime($ftime) < time()){    
                 $game->type = array_values(array_diff($game->type, ['open']));
               }
               
               if(strtotime($ltime) > time()){    
                 $data[] = $game;
               }
               
              
            //   elseif(time() > $etime){
            //       $data[] = $game;
            //   }    
                
            }
            }
        }
        // die;
        }
        
        
        if (count($data) < 1) {
            return response()->json(['status' => false,  'data' => [],'message' => 'Record not found']);
        }
       return response()->json(['status' => true, 'data' => $data, 'message' => 'Record found']);
    }
   

  public function singleAnk(Request $request)
{
    //  echo "<pre>";print_r($request->all());die;
    // Validate input
    $request->validate([
        'user_id' => 'required',
        'game_id' => 'required',
        'game_type' => 'required',
        'play_game_id' => 'required',
        'numbers' => 'required|array',
        'numbers.*.number' => 'required',
        'numbers.*.amount' => 'required|numeric|min:1',
    ]);
    // echo 12;die;
    // Check if wallet exists
    $wallet = DB::table('wallets')->where('user_id', $request->user_id)->first();
    $users = DB::table('users')->where('id', $request->user_id)->first();
    $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
   if(!$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }

    $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
    // Insert into tables and calculate total amount
    foreach ($request->numbers as $numberData) {
        // Insert into single_anks table
    //   $single_anks = DB::table('single_anks')->insert([
    //         'user_id' => $request->user_id,
    //         'game_id' => $request->game_id,
    //         'play_game_id'=>$request->play_game_id,
    //         'game_type' => $request->game_type,
    //         'play_type' => $request->play_type,
    //         'number' => $numberData['number'],
    //         'amount' => $numberData['amount'],
    //     ]);
 

        // Insert into bid_history table
        DB::table('bid_history')->insert([
            'user_id' => $request->user_id,
            'game_id' => $request->game_id,
            'play_game_id' => $request->play_game_id,
            'game_type' => $request->game_type,
            'number' => $numberData['number'],
            'amount' => $numberData['amount']
        ]);

        
    }

    // Check if wallet has sufficient balance
    



  

   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);
    $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
    'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
    return response()->json(['status' => true,'data' => $user , 'message' => 'Record successfully inserted']);
}

public function red_jodi(Request $request)
{
     $request->validate([
        'user_id' => 'required',
        'game_id' => 'required',
        'game_type' => 'required',
        'play_game_id' => 'required',
        'numbers' => 'required|array',
        'numbers.*.number' => 'required',
        'numbers.*.amount' => 'required|numeric|min:1',
    ]);
    // echo 12;die;
    // Check if wallet exists
    $wallet = DB::table('wallets')->where('user_id', $request->user_id)->first();
    $users = DB::table('users')->where('id', $request->user_id)->first();
    $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
   if(!$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }

    $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
    // Insert into tables and calculate total amount
    foreach ($request->numbers as $numberData) {
        // Insert into single_anks table
    //   $single_anks = DB::table('single_anks')->insert([
    //         'user_id' => $request->user_id,
    //         'game_id' => $request->game_id,
    //         'play_game_id'=>$request->play_game_id,
    //         'game_type' => $request->game_type,
    //         'play_type' => $request->play_type,
    //         'number' => $numberData['number'],
    //         'amount' => $numberData['amount'],
    //     ]);
 

        // Insert into bid_history table
        DB::table('bid_history')->insert([
            'user_id' => $request->user_id,
            'game_id' => $request->game_id,
            'play_game_id' => $request->play_game_id,
            'game_type' => $request->game_type,
            'number' => $numberData['number'],
            'amount' => $numberData['amount']
        ]);

        
    }

    // Check if wallet has sufficient balance
    






   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);
       $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
    return response()->json(['status' => true,'data' => $user , 'message' => 'Record successfully inserted']);
}

//   public function singlepana(Request $request)
// {
//     // echo 12;die;
//     // Validate input
//     $request->validate([
//         'user_id' => 'required',
//         'game_id' => 'required',
//         'game_type' => 'required',
//         'play_type' => 'required',
//         'numbers' => 'required|array',
//         'numbers.*.number' => 'required',
//         'numbers.*.amount' => 'required|numeric|min:1',
//     ]);
//     // echo 12;die;
//     // Check if wallet exists
//     $wallet = DB::table('wallets')->where('user_id', $request->user_id)->first();
//     $users = DB::table('users')->where('id', $request->user_id)->first();
//   if (!$users || !$users->wallet > 0) {
//         return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance'], 404);
//     }

//     $totalAmount = 0;

//     // Insert into tables and calculate total amount
//     foreach ($request->numbers as $numberData) {
//         // Insert into single_anks table
//       $single_anks = DB::table('single_panas')->insert([
//             'user_id' => $request->user_id,
//             'game_id' => $request->game_id,
//             'game_type' => $request->game_type,
//             'play_type' => $request->play_type,
//             'number' => $numberData['number'],
//             'amount' => $numberData['amount'],
//         ]);

//         // Insert into bid_history table
//         DB::table('bid_history')->insert([
//             'user_id' => $request->user_id,
//             'game_id' => $request->game_id,
//             'play_type' => $request->play_type,
//             'game_type' => $request->game_type,
//             'number' => $numberData['number'],
//             'amount' => $numberData['amount'],
//             'status' => $request->status ?? 0,
//             'response' => $request->response ?? null,
//         ]);

//         $totalAmount += $numberData['amount'];
//     }

//     // Check if wallet has sufficient balance
//     if ($wallet->amount < $totalAmount && $users->wallet < $totalAmount) {
//         return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance'], 404);
//     }


//     $wallet = DB::table('wallets')->where('user_id', $request->user_id)->update([
//         'amount' => $wallet->amount - $totalAmount,
//     ]);


//   $user =  DB::table('users')->where('id', $request->user_id)->update([
//      'wallet' => $users->wallet - $totalAmount,
//     ]);

//     return response()->json(['status' => true,'data' => $user , 'message' => 'Record successfully inserted']);
// }

    public function singlepana(Request $request){
     $request->validate([
        'user_id' => 'required',
        'game_id' => 'required',
        'game_type' => 'required',
        'play_game_id' => 'required',
        'numbers' => 'required|array',
        'numbers.*.number' => 'required',
        'numbers.*.amount' => 'required|numeric|min:1',
    ]);
    // echo 12;die;
    // Check if wallet exists
    $wallet = DB::table('wallets')->where('user_id', $request->user_id)->first();
    $users = DB::table('users')->where('id', $request->user_id)->first();
    $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
   if(!$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }

    $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
    // Insert into tables and calculate total amount
    foreach ($request->numbers as $numberData) {
        // Insert into single_anks table
    //   $single_anks = DB::table('single_anks')->insert([
    //         'user_id' => $request->user_id,
    //         'game_id' => $request->game_id,
    //         'play_game_id'=>$request->play_game_id,
    //         'game_type' => $request->game_type,
    //         'play_type' => $request->play_type,
    //         'number' => $numberData['number'],
    //         'amount' => $numberData['amount'],
    //     ]);
 

        // Insert into bid_history table
        DB::table('bid_history')->insert([
            'user_id' => $request->user_id,
            'game_id' => $request->game_id,
            'play_game_id' => $request->play_game_id,
            'game_type' => $request->game_type,
            'number' => $numberData['number'],
            'amount' => $numberData['amount']
        ]);

        
    }

    // Check if wallet has sufficient balance
    


 


   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);
       $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
    return response()->json(['status' => true,'data' => $user , 'message' => 'Record successfully inserted']);
}
//   public function doublepana(Request $request)
// {
//     // echo 12;die;
//     // Validate input
//     $request->validate([
//         'user_id' => 'required',
//         'game_id' => 'required',
//         'game_type' => 'required',
//         'play_type' => 'required',
//         'numbers' => 'required|array',
//         'numbers.*.number' => 'required',
//         'numbers.*.amount' => 'required|numeric|min:1',
//     ]);
//     // echo 12;die;
//     // Check if wallet exists
//     $wallet = DB::table('wallets')->where('user_id', $request->user_id)->first();
//     $users = DB::table('users')->where('id', $request->user_id)->first();
//   if (!$users || !$users->wallet > 0) {
//         return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance'], 404);
//     }

//     $totalAmount = 0;

//     // Insert into tables and calculate total amount
//     foreach ($request->numbers as $numberData) {
//         // Insert into single_anks table
//       $single_anks = DB::table('double_panas')->insert([
//             'user_id' => $request->user_id,
//             'game_id' => $request->game_id,
//             'game_type' => $request->game_type,
//             'play_type' => $request->play_type,
//             'number' => $numberData['number'],
//             'amount' => $numberData['amount'],
//         ]);

//         // Insert into bid_history table
//         DB::table('bid_history')->insert([
//             'user_id' => $request->user_id,
//             'game_id' => $request->game_id,
//             'play_type' => $request->play_type,
//             'game_type' => $request->game_type,
//             'number' => $numberData['number'],
//             'amount' => $numberData['amount'],
//             'status' => $request->status ?? 0,
//             'response' => $request->response ?? null,
//         ]);

//         $totalAmount += $numberData['amount'];
//     }

//     // Check if wallet has sufficient balance
//     if ($wallet->amount < $totalAmount && $users->wallet < $totalAmount) {
//         return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance'], 404);
//     }


//     $wallet = DB::table('wallets')->where('user_id', $request->user_id)->update([
//         'amount' => $wallet->amount - $totalAmount,
//     ]);


//   $user =  DB::table('users')->where('id', $request->user_id)->update([
//      'wallet' => $users->wallet - $totalAmount,
//     ]);

//     return response()->json(['status' => true,'data' => $user , 'message' => 'Record successfully inserted']);
// }

public function doublepana(Request $request){
     $request->validate([
        'user_id' => 'required',
        'game_id' => 'required',
        'game_type' => 'required',
        'play_game_id' => 'required',
        'numbers' => 'required|array',
        'numbers.*.number' => 'required',
        'numbers.*.amount' => 'required|numeric|min:1',
    ]);
    // echo 12;die;
    // Check if wallet exists
    $wallet = DB::table('wallets')->where('user_id', $request->user_id)->first();
    $users = DB::table('users')->where('id', $request->user_id)->first();
    $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
   if(!$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }

    $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
    // Insert into tables and calculate total amount
    foreach ($request->numbers as $numberData) {
        // Insert into single_anks table
    //   $single_anks = DB::table('single_anks')->insert([
    //         'user_id' => $request->user_id,
    //         'game_id' => $request->game_id,
    //         'play_game_id'=>$request->play_game_id,
    //         'game_type' => $request->game_type,
    //         'play_type' => $request->play_type,
    //         'number' => $numberData['number'],
    //         'amount' => $numberData['amount'],
    //     ]);
 

        // Insert into bid_history table
        DB::table('bid_history')->insert([
            'user_id' => $request->user_id,
            'game_id' => $request->game_id,
            'play_game_id' => $request->play_game_id,
            'game_type' => $request->game_type,
            'number' => $numberData['number'],
            'amount' => $numberData['amount']
        ]);

        
    }

    // Check if wallet has sufficient balance
    


   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' =>(int)$users->wallet - (int)$totalAmount,
    ]);
    
    $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);

    return response()->json(['status' => true,'data' => $user , 'message' => 'Record successfully inserted']);
}
  public function triplepana(Request $request)
{
    
    $request->validate([
        'user_id' => 'required',
        'game_id' => 'required',
        'game_type' => 'required',
        'play_game_id' => 'required',
        'numbers' => 'required|array',
        'numbers.*.number' => 'required',
        'numbers.*.amount' => 'required|numeric|min:1',
    ]);
    // echo 12;die;
    // Check if wallet exists
    $wallet = DB::table('wallets')->where('user_id', $request->user_id)->first();
    $users = DB::table('users')->where('id', $request->user_id)->first();
    $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
   if(!$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    } 

    $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
    // Insert into tables and calculate total amount
    foreach ($request->numbers as $numberData) {
        // Insert into single_anks table
    //   $single_anks = DB::table('single_anks')->insert([
    //         'user_id' => $request->user_id,
    //         'game_id' => $request->game_id,
    //         'play_game_id'=>$request->play_game_id,
    //         'game_type' => $request->game_type,
    //         'play_type' => $request->play_type,
    //         'number' => $numberData['number'],
    //         'amount' => $numberData['amount'],
    //     ]);
 

        // Insert into bid_history table
        DB::table('bid_history')->insert([
            'user_id' => $request->user_id,
            'game_id' => $request->game_id,
            'play_game_id' => $request->play_game_id,
            'game_type' => $request->game_type,
            'number' => $numberData['number'],
            'amount' => $numberData['amount']
        ]);

        
    }

    // Check if wallet has sufficient balance
    



   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);

       $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
    
    return response()->json(['status' => true,'data' => $user , 'message' => 'Record successfully inserted']);
//     // echo 12;die;
//     // Validate input
//     $request->validate([
//         'user_id' => 'required',
//         'game_id' => 'required',
//         'game_type' => 'required',
//         'play_type' => 'required',
//         'numbers' => 'required|array',
//         'numbers.*.number' => 'required',
//         'numbers.*.amount' => 'required|numeric|min:1',
//     ]);
//     // echo 12;die;
//     // Check if wallet exists
//     $wallet = DB::table('wallets')->where('user_id', $request->user_id)->first();
//     $users = DB::table('users')->where('id', $request->user_id)->first();
//      if (!$users || !$users->wallet > 0) {
//         return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance'], 404);
//     }

//     $totalAmount = 0;

//     // Insert into tables and calculate total amount
//     foreach ($request->numbers as $numberData) {
//         // Insert into single_anks table
//       $single_anks = DB::table('triple_panas')->insert([
//             'user_id' => $request->user_id,
//             'game_id' => $request->game_id,
//             'game_type' => $request->game_type,
//             'play_type' => $request->play_type,
//             'number' => $numberData['number'],
//             'amount' => $numberData['amount'],
//         ]);

//         // Insert into bid_history table
//         DB::table('bid_history')->insert([
//             'user_id' => $request->user_id,
//             'game_id' => $request->game_id,
//             'play_type' => $request->play_type,
//             'game_type' => $request->game_type,
//             'number' => $numberData['number'],
//             'amount' => $numberData['amount'],
//             'status' => $request->status ?? 0,
//             'response' => $request->response ?? null,
//         ]);

//         $totalAmount += $numberData['amount'];
//     }

//     // Check if wallet has sufficient balance
//     if ($wallet->amount < $totalAmount && $users->wallet < $totalAmount) {
//         return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance'], 404);
//     }


//     $wallet = DB::table('wallets')->where('user_id', $request->user_id)->update([
//         'amount' => $wallet->amount - $totalAmount,
//     ]);


//   $user =  DB::table('users')->where('id', $request->user_id)->update([
//      'wallet' => $users->wallet - $totalAmount,
//     ]);

//     return response()->json(['status' => true,'data' => $user , 'message' => 'Record inserted successfully']);
// }
}

  public function jodi(Request $request)
{
    
    $request->validate([
        'user_id' => 'required',
        'game_id' => 'required',
        'game_type' => 'required',
        'play_game_id' => 'required',
        'numbers' => 'required|array',
        'numbers.*.number' => 'required',
        'numbers.*.amount' => 'required|numeric|min:1',
    ]);
    // echo 12;die;
    // Check if wallet exists
    $wallet = DB::table('wallets')->where('user_id', $request->user_id)->first();
    $users = DB::table('users')->where('id', $request->user_id)->first();
    $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
    
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
   if(!$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    } 

    $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
    // Insert into tables and calculate total amount
    foreach ($request->numbers as $numberData) {
        // Insert into single_anks table
    //   $single_anks = DB::table('single_anks')->insert([
    //         'user_id' => $request->user_id,
    //         'game_id' => $request->game_id,
    //         'play_game_id'=>$request->play_game_id,
    //         'game_type' => $request->game_type,
    //         'play_type' => $request->play_type,
    //         'number' => $numberData['number'],
    //         'amount' => $numberData['amount'],
    //     ]);
 

        // Insert into bid_history table
        DB::table('bid_history')->insert([
            'user_id' => $request->user_id,
            'game_id' => $request->game_id,
            'play_game_id' => $request->play_game_id,
            'game_type' => $request->game_type,
            'number' => $numberData['number'],
            'amount' => $numberData['amount']
        ]);

        
    }

    // Check if wallet has sufficient balance
    




   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);


       $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
    return response()->json(['status' => true,'data' => $user , 'message' => 'Record successfully inserted']);
    
    
    
//     // echo 12;die;
//     // Validate input
//     $request->validate([
//         'user_id' => 'required',
//         'game_id' => 'required',
//         'game_type' => 'required',
//         'numbers' => 'required|array',
//         'numbers.*.number' => 'required',
//         'numbers.*.amount' => 'required|numeric|min:1',
//     ]);
//     // echo 12;die;
//     // Check if wallet exists
//     $wallet = DB::table('wallets')->where('user_id', $request->user_id)->first();
//     $users = DB::table('users')->where('id', $request->user_id)->first();
//      if (!$users || !$users->wallet > 0) {
//         return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance'], 404);
//     }

//     $totalAmount = 0;

//     // Insert into tables and calculate total amount
//     foreach ($request->numbers as $numberData) {
//         // Insert into single_anks table
//       $single_anks = DB::table('jodi')->insert([
//             'user_id' => $request->user_id,
//             'game_id' => $request->game_id,
//             'game_type' => $request->game_type,
//             'play_type' => $request->play_type,
//             'number' => $numberData['number'],
//             'amount' => $numberData['amount'],
//         ]);

//         // Insert into bid_history table
//         DB::table('bid_history')->insert([
//             'user_id' => $request->user_id,
//             'game_id' => $request->game_id,
//             'play_type' => $request->play_type,
//             'game_type' => $request->game_type,
//             'number' => $numberData['number'],
//             'amount' => $numberData['amount'],
//             'status' => $request->status ?? 0,
//             'response' => $request->response ?? null,
//         ]);

//         $totalAmount += $numberData['amount'];
//     }

//     // Check if wallet has sufficient balance
//     if ($wallet->amount < $totalAmount && $users->wallet < $totalAmount) {
//         return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance'], 404);
//     }


//     $wallet = DB::table('wallets')->where('user_id', $request->user_id)->update([
//         'amount' => $wallet->amount - $totalAmount,
//     ]);


//   $user =  DB::table('users')->where('id', $request->user_id)->update([
//      'wallet' => $users->wallet - $totalAmount,
//     ]);

//     return response()->json(['status' => true,'data' => $user , 'message' => 'Record inserted successfully']);
}



    
    
    public function panafamily(Request $request)
    {
       // dd($request->all());
        // $request->validate([
        //     'digit' => 'required|numeric',
        //     'points' => 'required|numeric',
        // ]);
    
    $users = DB::table('users')->where('id', $request->user_id)->first();
    $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
    // echo "<pre>";print_r($users);die;
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
     if (!$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    

        //  if(!$request->digit && !$request->points){
        //      return response()->json(['status' => false,  'data' => [],'message' => 'Record not found']);
        //  }
        //  if((int)$users->wallet < (int)$request->total_points) {
        //     return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        // }
        // $data = DB::table('pana_familys')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'digit' => $request->digit,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
        
            // Insert into bid_history table
        // DB::table('bid_history')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_game_id' => $request->play_game_id,
        //     'game_type' => $request->game_type,
        //     'number' => $request->digit,
        //     'amount' => $request->points,
        //     'status' => $request->status ?? 0,
        //     'response' => $request->response ?? null,
        // ]);
        
 $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('two_digit_panas')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'digit' => $request->digit,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
            foreach ($request->numbers as $numberData) {
                DB::table('bid_history')->insert([
                    'user_id' => $request->user_id,
                    'game_id' => $request->game_id,
                    'play_game_id' => $request->play_game_id,
                    'game_type' => $request->game_type,
                    'number' => $numberData['number'],
                    'amount' => $numberData['amount']
                ]);
            }


   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);


       $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
        return response()->json(['status' => true, 'data' => $user , 'message' => ' Record inserted Successfully']);
    }
    
    
    
    public function SpDpTp(Request $request)
    {
       // dd($request->all());
        // $request->validate([
        //     'digit' => 'required|numeric',
        //     'points' => 'required|numeric',
        // ]);
    
     $users = DB::table('users')->where('id', $request->user_id)->first();
     $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
     $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
     $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
    // echo "<pre>";print_r($users);die;
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
     if (!$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
//  echo "<pre>";print_r($users);die;
 
        //  if(!$request->digit && !$request->points){
        //      return response()->json(['status' => false,  'data' => [],'message' => 'Record not found']);
        //  }
         // Check if wallet has sufficient balance
    // if($users->wallet < $request->total_points) {
    //     return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    // }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('sp_dp_tps')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'game_type' => $request->game_type,
        //     'digit' => $request->digit,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
        // DB::table('bid_history')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_game_id' => $request->play_game_id,
        //     'game_type' => $request->game_type,
        //     'number' => $request->digit,
        //     'amount' => $request->points,
        //     'sp_dp_tp'=>$request->sp_dp_tp
        // ]);
 $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('two_digit_panas')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'digit' => $request->digit,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
            foreach ($request->numbers as $numberData) {
                DB::table('bid_history')->insert([
                    'user_id' => $request->user_id,
                    'game_id' => $request->game_id,
                    'play_game_id' => $request->play_game_id,
                    'game_type' => $request->game_type,
                    'number' => $numberData['number'],
                    'amount' => $numberData['amount'],
                   // 'sp_dp_tp'=>$request->sp_dp_tp
                ]);
            }
    
    $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);
    
        $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);

        return response()->json(['status' => true, 'data' => $user , 'message' => ' Record inserted Successfully']);
    }
    
public function twoDigitPana(Request $request)
    {
       // dd($request->all());
        $request->validate([
        'user_id' => 'required',
        'game_id' => 'required',
        'game_type' => 'required',
        'play_game_id' => 'required',
        'numbers' => 'required|array',
        'numbers.*.number' => 'required',
        'numbers.*.amount' => 'required|numeric|min:1',
    ]);
    
     $users = DB::table('users')->where('id', $request->user_id)->first();
     $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
    // echo "<pre>";print_r($users);die;
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
     if (!$users || !$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
//  echo "<pre>";print_r($users);die;
 
        //  if(!$request->digit && !$request->points){
        //      return response()->json(['status' => false,  'data' => [],'message' => 'Record not found']);
        //  }
         
         $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('two_digit_panas')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'digit' => $request->digit,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
            foreach ($request->numbers as $numberData) {
                DB::table('bid_history')->insert([
                    'user_id' => $request->user_id,
                    'game_id' => $request->game_id,
                    'play_game_id' => $request->play_game_id,
                    'game_type' => $request->game_type,
                    'number' => $numberData['number'],
                    'digit' => $numberData['digit'], 
                    'amount' => $numberData['amount']
                ]);
            }
        // DB::table('bid_history')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_game_id' => $request->play_game_id,
        //     'game_type' => $request->game_type,
        //     'number' => $request->digit,
        //     'amount' => $request->points,
        // ]);

    

    // Check if wallet has sufficient balance
    



   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);
     $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
        return response()->json(['status' => true, 'data' => $user , 'message' => ' Record inserted Successfully']);
    }
    
    public function SpMotor(Request $request)
    {
       // dd($request->all());
        // $request->validate([
        //     'digit' => 'required|numeric',
        //     'points' => 'required|numeric',
            
        // ]);
    
     $users = DB::table('users')->where('id', $request->user_id)->first();
     $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
    // echo "<pre>";print_r($users);die;
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
     if (!$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    // if($users->wallet < $request->total_points) {
    //     return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    // }
//  echo "<pre>";print_r($users);die;

        //  if(!$request->digit && !$request->points){
        //      return response()->json(['status' => false,  'data' => [],'message' => 'Record not found']);
        //  }
        $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('two_digit_panas')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'digit' => $request->digit,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
            foreach ($request->numbers as $numberData) {
                DB::table('bid_history')->insert([
                    'user_id' => $request->user_id,
                    'game_id' => $request->game_id,
                    'play_game_id' => $request->play_game_id,
                    'game_type' => $request->game_type,
                    'number' => $numberData['number'],
                    'amount' => $numberData['amount']
                ]);
            }
    

    // Check if wallet has sufficient balance
    


   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);
    
        $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);

        return response()->json(['status' => true, 'data' => $user , 'message' => ' Record inserted Successfully']);
    }
    
    
    public function DpMotor(Request $request)
    {
       // dd($request->all());
        // $request->validate([
        //     'digit' => 'required|numeric',
        //     'points' => 'required|numeric',
        // ]);
    
     $users = DB::table('users')->where('id', $request->user_id)->first();
     $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
    // echo "<pre>";print_r($users);die;
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
     if (!$users || !$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
//  echo "<pre>";print_r($users);die;
    // 
        //  if(!$request->digit && !$request->points){
        //      return response()->json(['status' => false,  'data' => [],'message' => 'Record not found']);
        //  }
         
        $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('two_digit_panas')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'digit' => $request->digit,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
            foreach ($request->numbers as $numberData) {
                DB::table('bid_history')->insert([
                    'user_id' => $request->user_id,
                    'game_id' => $request->game_id,
                    'play_game_id' => $request->play_game_id,
                    'game_type' => $request->game_type,
                    'number' => $numberData['number'],
                    'amount' => $numberData['amount']
                ]);
            }
    

    // Check if wallet has sufficient balance
    


   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);

         $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
        return response()->json(['status' => true, 'data' => $user , 'message' => ' Record inserted Successfully']);
    }
    
    
    public function jodi_family(Request $request)
    {
       // dd($request->all());
        // $request->validate([
        //     'digit' => 'required|numeric',
        //     'points' => 'required|numeric',
        // ]);
    
     $users = DB::table('users')->where('id', $request->user_id)->first();
     $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
    // echo "<pre>";print_r($users);die;
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
     if (!$users || !$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
//  echo "<pre>";print_r($users);die;
      $totalAmount = 0;
        //  if(!$request->digit && !$request->points){
        //      return response()->json(['status' => false,  'data' => [],'message' => 'Record not found']);
        //  }
         
         $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('two_digit_panas')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'digit' => $request->digit,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
            foreach ($request->numbers as $numberData) {
                DB::table('bid_history')->insert([
                    'user_id' => $request->user_id,
                    'game_id' => $request->game_id,
                    'play_game_id' => $request->play_game_id,
                    'game_type' => $request->game_type,
                    'number' => $numberData['number'],
                    'amount' => $numberData['amount']
                ]);
            }
    

    // Check if wallet has sufficient balance
    


   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);
      
     $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
        return response()->json(['status' => true, 'data' => $user , 'message' => ' Record inserted Successfully']);
    }
    
    
    public function OddEven(Request $request)
    {
       // dd($request->all());
        // $request->validate([
        //     'points' => 'required|numeric',
            
        // ]);
    
     $users = DB::table('users')->where('id', $request->user_id)->first();
     $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
    // echo "<pre>";print_r($users);die;
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
     if (!$users || !$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    // if($users->wallet < $request->total_points) {
    //     return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    // }
//  echo "<pre>";print_r($users);die;
    //   $totalAmount = 0;
        //  if(!$request->digit && !$request->points){
        //      return response()->json(['status' => false,  'data' => [],'message' => 'Record not found']);
        //  }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('odd_evens')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
        // DB::table('bid_history')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_game_id' => $request->play_game_id,
        //     'game_type' => $request->game_type,
        //     'number' => $request->digit,
        //     'amount' => $request->points,
        //     'amount' => $request->odd_even,
        // ]);


    // Check if wallet has sufficient balance
     $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('two_digit_panas')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'digit' => $request->digit,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
            foreach ($request->numbers as $numberData) {
                DB::table('bid_history')->insert([
                    'user_id' => $request->user_id,
                    'game_id' => $request->game_id,
                    'play_game_id' => $request->play_game_id,
                    'game_type' => $request->game_type,
                    'number' => $numberData['number'],
                    'amount' => $numberData['amount'],
                    'odd_even' => $request->odd_even,
                ]);
            }



   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);
     
         $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
    
        return response()->json(['status' => true, 'data' => $user , 'message' => ' Record inserted Successfully']);
    }
    
    public function digitbasejodi(Request $request)
{
     // dd($request->all());
        // $request->validate([
        //     'points' => 'required|numeric',
            
        // ]);
    
     $users = DB::table('users')->where('id', $request->user_id)->first();
     $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
    // echo "<pre>";print_r($users);die;
     if (!$users || !$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    if($users->wallet < $request->points) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
//  echo "<pre>";print_r($users);die;
    //   $totalAmount = 0;
        //  if(!$request->digit && !$request->points){
        //      return response()->json(['status' => false,  'data' => [],'message' => 'Record not found']);
        //  }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('odd_evens')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
        DB::table('bid_history')->insert([
            'user_id' => $request->user_id,
            'game_id' => $request->game_id,
            'play_game_id' => $request->play_game_id,
            'game_type' => $request->game_type,
            'number' => $request->digit,
            'amount' => $request->points,
        ]);


    // Check if wallet has sufficient balance
    



   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$request->total_points,
    ]);
     
         $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
        return response()->json(['status' => true, 'data' => $user , 'message' => ' Record inserted Successfully']);
}

public function halfsangam1(Request $request)
{
     //dd($request->all());
        $request->validate([
        'user_id' => 'required',
        'game_id' => 'required',
        'game_type' => 'required',
        'play_game_id' => 'required',
        'numbers' => 'required|array',
        'numbers.*.number' => 'required',
        'numbers.*.amount' => 'required|numeric|min:1',
    ]);
    
     $users = DB::table('users')->where('id', $request->user_id)->first();
     $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
    // echo "<pre>";print_r($users);die;
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
     if (!$users || !$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    //dd($ltime,time());
    
    // dd(strtotime($ltime) <= time());
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
//  echo "<pre>";print_r($users);die;
  
        //  if(!$request->digit && !$request->points){
        //      return response()->json(['status' => false,  'data' => [],'message' => 'Record not found']);
        //  }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('odd_evens')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
        // DB::table('bid_history')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_game_id' => $request->play_game_id,
        //     'game_type' => $request->game_type,
        //     'number' => json_encode($request->digit),
        //     'amount' => $request->points,
        // ]);
        foreach ($request->numbers as $numberData) {
                DB::table('bid_history')->insert([
                    'user_id' => $request->user_id,
                    'game_id' => $request->game_id,
                    'play_game_id' => $request->play_game_id,
                    'game_type' => $request->game_type,
                    'number' => $numberData['number'],
                    'amount' => $numberData['amount']
                ]);
            }


      
   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);
     
         $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
        return response()->json(['status' => true, 'data' => $user , 'message' => ' Record inserted Successfully']);

 
   }
public function halfsangam2(Request $request)
{
     //dd($request->all());
        $request->validate([
        'user_id' => 'required',
        'game_id' => 'required',
        'game_type' => 'required',
        'play_game_id' => 'required',
        'numbers' => 'required|array',
        'numbers.*.number' => 'required',
        'numbers.*.amount' => 'required|numeric|min:1',
    ]);
    
     $users = DB::table('users')->where('id', $request->user_id)->first();
     $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
    // echo "<pre>";print_r($users);die;
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
     if (!$users || !$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    //dd($ltime,time());
    
    // dd(strtotime($ltime) <= time());
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
//  echo "<pre>";print_r($users);die;
  
        //  if(!$request->digit && !$request->points){
        //      return response()->json(['status' => false,  'data' => [],'message' => 'Record not found']);
        //  }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('odd_evens')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
        // DB::table('bid_history')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_game_id' => $request->play_game_id,
        //     'game_type' => $request->game_type,
        //     'number' => json_encode($request->digit),
        //     'amount' => $request->points,
        // ]);
        foreach ($request->numbers as $numberData) {
                DB::table('bid_history')->insert([
                    'user_id' => $request->user_id,
                    'game_id' => $request->game_id,
                    'play_game_id' => $request->play_game_id,
                    'game_type' => $request->game_type,
                    'number' => $numberData['number'],
                    'amount' => $numberData['amount']
                ]);
            }


      
   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);
     
         $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
        return response()->json(['status' => true, 'data' => $user , 'message' => ' Record inserted Successfully']);

 
   }
public function fullsangam(Request $request)
{
     //dd($request->all());
        $request->validate([
        'user_id' => 'required',
        'game_id' => 'required',
        'game_type' => 'required',
        'play_game_id' => 'required',
        'numbers' => 'required|array',
        'numbers.*.number' => 'required',
        'numbers.*.amount' => 'required|numeric|min:1',
    ]);
    
     $users = DB::table('users')->where('id', $request->user_id)->first();
     $matka_results = DB::table('matka_results')->where('id',$request->game_id)->first();
    $ftime = \Carbon\Carbon::formattedTime($matka_results->firsttime);
    $ltime = \Carbon\Carbon::formattedTime($matka_results->lasttime);
    // echo "<pre>";print_r($users);die;
  //  $ftime = strtotime(date("Y-m-d") . " " . $ftime);
  //  $ltime = strtotime(date("Y-m-d") . " " . $ltime);
     if (!$users || !$users->wallet > 0) {
        return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
    }
    if($request->game_type == "open"){
         if(strtotime($ftime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    //dd($ltime,time());
    
    // dd(strtotime($ltime) <= time());
    if($request->game_type == "close"){
         if(strtotime($ltime) <= time()){
             return response()->json(['status' => false,'data' => [], 'message' => 'bid closed']);
         }
    }
    $totalAmount = 0;
 foreach ($request->numbers as $numberData) {
     $totalAmount += $numberData['amount'];
 }
     if((int)$users->wallet < (int)$totalAmount) {
            return response()->json(['status' => false,'data' => [], 'message' => 'Insufficient wallet balance']);
        }
//  echo "<pre>";print_r($users);die;
    
        //  if(!$request->digit && !$request->points){
        //      return response()->json(['status' => false,  'data' => [],'message' => 'Record not found']);
        //  }
       // echo "<pre>";print_r($users);die;
        // $data = DB::table('odd_evens')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_type' => $request->play_type,
        //     'game_type' => $request->game_type,
        //     'points' => $request->points,
        //     'total_bid' => $request->total_bid,
        //     'total_points' => $request->total_points,
        // ]);
       //  echo "<pre>";print_r($users);die;
            // Insert into bid_history table
        // DB::table('bid_history')->insert([
        //     'user_id' => $request->user_id,
        //     'game_id' => $request->game_id,
        //     'play_game_id' => $request->play_game_id,
        //     'game_type' => $request->game_type,
        //     'number' => json_encode($request->digit),
        //     'amount' => $request->points,
        // ]);
        foreach ($request->numbers as $numberData) {
                DB::table('bid_history')->insert([
                    'user_id' => $request->user_id,
                    'game_id' => $request->game_id,
                    'play_game_id' => $request->play_game_id,
                    'game_type' => $request->game_type,
                    'number' => $numberData['number'],
                    'amount' => $numberData['amount']
                ]);
            }


      
   $user =  DB::table('users')->where('id', $request->user_id)->update([
     'wallet' => (int)$users->wallet - (int)$totalAmount,
    ]);
     
         $userdata = DB::table('users')->where('id',$request->user_id)->first();
     $passbook = DB::table('passbooks')->insert([
    'user_id' => $userdata->id,
    'credit' => '',
    'debit' => $totalAmount,
    'game_id' => $request->game_id,
    'play_game_id' => $request->play_game_id,
     'game_type' => $request->game_type,
    'remaining_balance' => $userdata->wallet,
    'status' => 'bid',
    ]);
        return response()->json(['status' => true, 'data' => $user , 'message' => ' Record inserted Successfully']);

 
   }
    
}