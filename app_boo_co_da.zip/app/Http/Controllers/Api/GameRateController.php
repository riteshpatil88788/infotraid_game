<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\FastestLiveUpdate;
use Illuminate\Support\Facades\Auth;

class GameRateController extends Controller
{
 
    public function index(){
        
        $data['title'] = "Game Rate";
        $data['GameRate'] = DB::table('game_rates')->get();
        if (!$data['GameRate']) {
            return response()->json(['status' => false, 'data' => [], 'message' => 'Record not found']);
        }
       return response()->json(['status' => true, 'data' => $data , 'message' => 'Record Successfully' ]);
       
    }





    
}
