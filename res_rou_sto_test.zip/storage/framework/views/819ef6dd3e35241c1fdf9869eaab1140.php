


<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    
    
    

    <link rel="stylesheet" type="text/css" href="https://storage.googleapis.com/sattamatka-cdn-bucket/styles/banner-styles.css">
    <link rel="stylesheet" type="text/css" href="https://storage.googleapis.com/sattamatka-cdn-bucket/styles/iconochive.css">

    <title>RUTBA143 User Profile 341 Guesser Guessing Contact Number Facebook id phone number kalyan mumbai game matka</title>
    <meta http-equiv="refresh" content="900">
    <meta name="description" content="RUTBA143 matka guessing profile 341 Guesser Guessing Contact Number Facebook id phone number kalyan mumbai game matka Full Name Date Of Birth Member Since Last Login Achievements Total Post">
    <meta name="keywords" content="RUTBA143 matka guessing profile 341 Guesser Guessing Contact Number Facebook id phone number kalyan mumbai game matka Full Name Date Of Birth Member Since Last Login Achievements Total Post">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
	
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-TVDGB9FMGW"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'G-TVDGB9FMGW');
	</script>

</head>
<body>
    <style>

        @font-face {
            font-family: myfont1;
            /* src:url(/web/20200815053238im_/https://app.sattamatka.mobi/LatoLatin-BoldItalic.woff2);*/
        }

        .head_div {
            width: 100%;
            box-sizing: border-box;
        }

        .logo {
            /*background-image:url('/web/20200815053238im_/https://app.sattamatka.mobi/img/newlogo.png');
        background-size:auto auto;
        background-position:center;
        height:120px;
        background-repeat:no-repeat;*/
            /*background-image: url(/web/20200815053238im_/https://app.sattamatka.mobi/img/newlogo.png);*/
            background-size: auto auto;
            background-position: center;
            /*width: 75%;*/
            height: 100%;
            text-align: center;
            background-repeat: no-repeat;
            float: none;
            margin-left: auto;
            margin-right: auto;
        }

        .header {
            border-radius: 3px;
            border: 3px solid #13316c;
            box-sizing: border-box;
            background: radial-gradient(white, #e9f5fa);
            box-shadow: 0 0 10px #13316c;
            height: 75px;
        }

        .b_msg {
            font-family: myfont1;
            font-size: 12px;
            box-sizing: border-box;
            color: #fff;
            margin: 6px 0 0 0;
            padding: 5px 0;
            text-align: center;
            width: 100%;
            background-color: #0033cc;
            margin: 8px 0 0 0;
        }

        @media only screen and (max-width:480px) {
            .logo {
                background-size: 100% auto;
            }

            .b_msg {
                font-size: 9px;
            }
        }
    </style>

    <div class="head_div">
        <a href="javascript:void(0);">
            <div class="header">
                <div class="logo">
                    <img class="logo ptb-10 mb-0" src="<?php echo e(url('front-assets/images/logo.jpg')); ?>" alt="SattaMatka" />
                </div>
            </div>
        </a>
    </div>
    <div class="b_msg">
        Use Google Chrome or Mozilla Firefox, Safari Browser to use and see this Website. Do not use UC Browser UC Mini and opera Mini.
        <div>इस वेबसाइट का उपयोग करने और देखने के लिए Google क्रोम या मोज़िला फ़ायरफ़ॉक्स, सफ़ारी ब्राउज़र का उपयोग करें। यूसी ब्राउज़र यूसी मिनी और ओपेरा मिनी का उपयोग न करें।.</div>
    </div>

    <style>
        .matka_live {
            border-radius: 3px;
            padding: 10px 0;
            text-align: center;
            color: #fff;
            font-size: 20px;
            font-weight: 700;
            font-family: myfont1;
        }

        @media only screen and (max-width: 480px) {

            .matka_live {
                font-size: 20px;
            }

            .live_update {
                margin: 25px 0 0 0;
            }
        }
    </style>

    <style>
        .game_title {
            text-align: center;
            font-family: myfont1;
            font-weight: 700;
            font-size: 20px;
            color: #e70042;
            padding: 0 0 0 0;
        }

        @media only screen and (max-width: 480px) {

            .game_title {
                font-size: 12px;
                font-weight: 700;
            }
        }
    </style>

    <div style="margin:0px 0 0px 0;border: 1px solid #ccc;background-color:#fff1f1;">
        <br><br>
        <center>
            <center>
                <img style="border: 1px solid #ccc;border-radius:40px;height: 250px;" src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/PersonImage.png">
                <h2 class="game_title" style="font-size: 30px;">User Info</h2>
            </center>
        </center>
    </div>
    <div class="matka_live" style="margin:0px 0 0px 0;background-color: #e70042;">
        Name : <?php echo e($user->name); ?> <hr>
       
        Member Since : <?php echo e(date('d M Y', strtotime($user->created_at))); ?>

        <hr>
        Last Login : <?php echo e(date('d M Y', strtotime($user->created_at))); ?> <hr>
        Total Posts : <?php echo e($guessing); ?>

    </div>
    <br>
    <br>
    <div class="matka_live" style="margin:0px 0 0px 0;background-color: #133e8c;">
        <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/a1.png" style="margin: -10px;">
        <span style="padding: 15px;">Achievements</span>
        <img style="margin: -10px;" src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/a1.png">
    </div>
    <div style="margin:0px 0 0px 0;border: 1px solid #ccc;background-color:#eef1f6;">
        <br>
        <p class="game_title" style="color:#1f252b;">Expert Member ==&gt; <?php echo e(date('d M Y', strtotime($user->created_at))); ?></p>
        <p class="game_title" style="color:#1f252b;">New Member ==&gt; <?php echo e(date('d M Y', strtotime($user->created_at))); ?></p>
    </div>
    <style>
        .refresh {
            background-color: #440e62;
            border: 1px solid #14001f;
            text-align: center;
            color: #fff;
            padding: 8px;
            font-family: myfont1;
            box-sizing: border-box;
            margin: 10px 0 0 0;
            font-size: 20px;
            font-weight: 700;
            box-shadow: 0 0 10px #461300;
            width: 10%;
            text-align: center;
            text-decoration: none;
        }
    </style>
    <div align="center" style="
    width: 100%;
    text-align: center;
    margin-top: 17px;
    float: left;">

        <a href="#top" class="refresh">
            Go To Top
        </a>


    </div>
    <style>
        .footer {
            width: 100%;
            box-sizing: border-box;
            float: left;
            text-align: center;
            color: #fff;
            font-size: 20px;
            font-weight: 700;
            font-family: myfont1;
            height: 170px
        }

        .back, .home {
            color: #000;
            padding: 5px 0;
            width: 50%
        }

        .home {
            background-color: #ffb12a;
            border: 1px solid #bc4200;
            border-radius: 20px 0 0 20px;
            float: right
        }

        .back {
            background-color: #fdf243;
            border: 1px solid #bc4200;
            border-radius: 0 20px 20px 0;
            float: left
        }

        .footer_title {
            font-size: 18px;
            padding: 10px 0
        }

        .bg8 {
            background-color: #dc0340;
            border: 1px solid #84003b
        }

        @media only screen and (max-width:480px) {
            .footer {
                height: 140px
            }

            .back, .home {
                width: 70%;
                font-size: 16px
            }

            .footer_title {
                font-size: 14px;
                padding: 10px 0
            }
        }
    </style>

    <style>
        .f_block {
            width: 100%;
            height: 50px;
        }

        .ff1 {
            float: left;
            width: 50%;
        }

        .footer {
            width: 100%;
            box-sizing: border-box;
            /* float: left; */
            text-align: center;
            color: #fff;
            font-size: 20px;
            font-weight: 700;
            font-family: myfont1;
            height: 100% !important;
            clear: both;
        }
    </style>
    <div class="footer bg8" style="margin:15px 0 75px 0;">
        <p class="footer_title">
            SERVER: AD BOSS MATKA GUESSING<br>
            AD BOSS SATTA MATKA<br>
            ALL RIGHTS RESERVED (2012-2021)<br>
            CONTACT ADMIN
        </p>
        <div class="f_block">
            <a href="<?php echo e(route('home.index')); ?>">
                <div class="ff1">
                    <div class="home">HOME</div>
                </div>
            </a>
            <a href="#">
                <div class="ff1">
                    <div class="back">BACK</div>
                </div>
            </a>
        </div>
    </div>


    <script>
        function gotobottum() {
            $("html, body").animate({ scrollTop: $(document).height() }, 1000);
        }
        function gototop() {
            $("html, body").animate({ scrollTop: 0 });
        }</script>

    <style>
        .fixed_menubar {
            display: block;
            width: 100%;
            background-color: #f2f2f2;
            border-top: 1px solid #d9d9d9;
            height: 68px;
            z-index: 10;
            position: fixed;
            bottom: 0;
        }

        .bottom_menus {
            width: 25%;
            float: left;
            cursor: pointer;
            text-align: center;
        }

            .bottom_menus > i {
                color: #bfbfbf;
                font-size: 28px;
                padding: 6px 0;
            }

                .bottom_menus > i:hover {
                    color: #ff4d4d
                }

        .bottom_menus_title {
            color: #a6a6a6;
            font-weight: 700;
            margin: 0px 0 0 0;
            font-size: 15px;
            font-family: myfont1;
            /* line-height:18px; */
        }

        .bb1 {
            color: #133E8C;
        }

        @media only screen and (max-width:480px) {
            .fixed_menubar {
                display: block;
                width: 100%;
                background-color: #f2f2f2;
                border-top: 1px solid #d9d9d9;
                height: 58px;
                z-index: 10;
                position: fixed;
                bottom: 0;
            }

            .bottom_menus {
                width: 20%;
                float: left;
                cursor: pointer;
                text-align: center;
            }

                .bottom_menus > img {
                }

            .bottom_menus_title {
                color: #a6a6a6;
                font-size: 11px;
                font-family: myfont1;
                line-height: 12px;
            }

            .bb1 {
                color: #133E8C;
            }
        }
    </style>

     <div class="fixed_menubar">
               <a style="text-decoration:none;color:#003f6b !important" href="<?php echo e(route('home.index')); ?>">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/home-grey.png" width="25" alt="satta-matka" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title ">Home</p>
            </div>
        </a>
        <a style="text-decoration:none;color:#003f6b !important" href="<?php echo e(route('home.ResultGuessing')); ?>">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/guessing-forum.png" width="25" alt="guessing-forum" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title bb1">
                    Guessing
                    <br />Forum
                </p>
            </div>
        </a>
        <a style="text-decoration:none;color:#003f6b !important" href="">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/guessing-forum.png" width="25" alt="chatting -forum" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title">
                    Chatting
                    <br />Forum
                </p>
            </div>
        </a>
        <a style="text-decoration:none;color:#003f6b !important" href="<?php echo e(route('home.expertGuessing')); ?>">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/experts-forum-grey.png" width="25" alt="experts-forum" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title  ">
                    Experts
                    <br />Forum
                </p>
            </div>
        </a>

        <a style="text-decoration:none;color:#003f6b !important" href="javascript:void(0);" onclick="window.location.reload();">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/refresh2.png" width="25" alt="Refresh" style="margin:4px 0 0 0;">
                <p class="bottom_menus_title ">Refresh<br>Page</p>
            </div>
        </a>
    </div>
    <style>
        .a14 {
            position: fixed;
            bottom: 60px;
            right: 5px;
            cursor: pointer;
            padding: 5px;
        }
    </style>
    <div class="a14" onclick="window.location.reload()">
        <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/refresh.png" alt="refresh-button">
    </div>


    <script src="https://storage.googleapis.com/sattamatka-cdn-bucket/scripts/jquery-3.3.1.min.js"></script>

    <script src="../../user_profile_files/bootstrap.min.js"></script>

</body>
</html><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/profile.blade.php ENDPATH**/ ?>