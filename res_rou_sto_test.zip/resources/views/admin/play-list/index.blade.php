@extends('admin.layout.app') @section('content')
<div class="page-wrapper">
    <div class="content container-fluid">



        <div class="row">
            <div class="col-sm-12">
                <div class="card card-table">
                    <div class="card-body">

                        <div class="page-header">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="page-title">{{$title}}</h3>
                                </div>
                                <div class="col-auto text-end float-end ms-auto download-grp">
                                    <a href="{{ route('admin.playlist.create') }}" class="btn btn-primary"><i class="fas fa-plus"></i></a>
                                </div>
                            </div>
                        </div>
                        @if (session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                @endif
                        <div class="table-responsive">
                            <table class="table border-0 star-student table-hover table-center mb-0 datatable table-striped">
                                <thead class="student-thread">
                                    <tr>
                                        <th>S.No</th>
                                        <th>Game Name</th>
                                        <th>Play List</th>
                                        <th class="text-end">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1;?>
                                    @foreach($playlists as $playlist)
                                    <tr>
                                        <td>{{$i}}</td>
                                      
                                        <td>{{ $playlist->game_id }}</td>
                                        <td>{{ $playlist->play }}</td>
                                       
                                        <td class="text-end">
                                            <div class="actions">
                                                <a href="{{ route('admin.playlist.edit', $playlist->id) }}" class="btn btn-sm bg-danger-light">
                                                    <i class="feather-edit"></i>
                                                </a>
                                                <a href="{{ route('admin.playlist.destroy', $playlist->id) }}" class="btn btn-sm bg-success-light me-2" onclick="return confirm('Do you really want to Delete?')">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            
                                            </div>
                                        </td>
                                    </tr>
                                    <?php $i++;?>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection