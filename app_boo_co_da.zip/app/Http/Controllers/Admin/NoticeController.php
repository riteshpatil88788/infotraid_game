<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\Notice;

class NoticeController extends Controller
{
 
    public function edit(){
        $data['notices'] = DB::table('notices')->where('id',1)->first();
        $data['title'] = "notices";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('admin.notice.edit',$data);
    }

    public function update(Request $request)
    {
    //  dd($request->all());
        $request->validate([
        //    'title' => 'required',
            'description' => 'required',
        ]);
        //  echo "<pre>";print_r($request->all());die;
        $abouts = Notice::find($request->id);
        $abouts->description = strip_tags($request->description);
        $abouts->save();
        // dd($user->toArray());
        session()->flash('success', 'Notice has been Update !!');
        return redirect()->route('admin.notice.edit');
    }



    
}
