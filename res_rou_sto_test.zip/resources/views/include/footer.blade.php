<!-- Footer -->
<footer class="footer-wrap bg-stratos" style="background: #191919;">
  <div class="container">
    @php 
    $contact = App\Models\Contact::first();
    @endphp
    <div class="row pt-100 pb-20">
      <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
        <div class="footer-widget">
          <a href="{{route('home.index')}}" class="footer-logo">
          <img src="{{url('front-assets/img/new/logo-newdream21.png')}}" alt="Image">
          </a>
          <p class="mt-5"><i class="fa-solid fa-location-dot"></i> <b style="padding-left:10px;">Office Address </b> : {{$contact->address}}</p>
          <p> <i class="fa-regular fa-phone-volume"></i> <b style="padding-left:10px;">Contact Details </b> : +91{{$contact->phone}}</p>
          <p> <i class="fa-sharp fa-solid fa-envelope"></i> <b style="padding-left:10px;"> Email id </b> :{{$contact->email}}</p>
          <div class="social-link">
            <ul class="social-profile list-style style1">
              <li>
                <a target="_blank" href="{{$contact->facebook}}">
                <img src="{{url('front-assets/img/new/facebook.png')}}">
                </a>
              </li>
              <li>
                <a target="_blank" href="{{$contact->twitter}}">
                <img src="{{url('front-assets/img/new/twitter.png')}}">
                </a>
              </li>
              <li>
                <a target="_blank" href="{{$contact->linkedin}}">
                <img src="{{url('front-assets/img/new/linkedin.png')}}">
                </a>
              </li>
              <li>
                <a target="_blank" href="{{$contact->instagram}}">
                <img src="{{url('front-assets/img/new/you1.png')}}">
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
        <div class="footer-widget">
          <h3 class="footer-widget-title">Quick Links</h3>
          <ul class="footer-menu list-style">
            <li><a href="{{route('home.investor')}}"><i class="flaticon-next"></i>Investor Charter</a></li>
            <li><a href="{{route('home.kyc')}}"><i class="flaticon-next"></i>KYC & Services Agreement</a></li>
            <li><a href="{{route('home.grievance')}}"><i class="flaticon-next"></i>Grievance Redressal Process</a></li>
            <li><a href="{{route('home.complaint')}}"><i class="flaticon-next"></i>Complaint Data</a></li>
            <li><a href="{{route('home.disclaimer')}}"><i class="flaticon-next"></i>Disclaimer</a></li>
            <li><a href="{{route('home.disclosure')}}"><i class="flaticon-next"></i>Disclosure</a></li>
            <li><a href="{{route('home.faq')}}"><i class="flaticon-next"></i>FAQ</a></li>
            <li><a href="{{route('home.contact')}}"><i class="flaticon-next"></i>Contact Us</a></li>
          </ul>
        </div>
      </div>
      <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
        <div class="footer-widget">
          <h3 class="footer-widget-title">Our Products</h3>
          <ul class="footer-menu list-style">
            <?php 
              $services = DB::table('services')
              
              ->join('categories', 'services.category', '=', 'categories.id')
              
              ->select('services.*', 'categories.title as category_title')
              ->where('status',1)
              ->groupBy('categories.title')
              ->orderBy('services.id','asc')
              ->get();
              
              ?>   
            <?php foreach($services as $service): ?>
            <?php if($service->category_title): 
              $currentUrl = url()->current();
              $serviceUrl = route('home.category', ['segment' => str_replace(' ', '-', $service->category_title)]);
              ?>
            <li>
              <a href="{{$serviceUrl}}" ><i class="flaticon-next"></i>{{ $service->category_title }}</a>
            </li>
            <?php endif; ?>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="texting">
      <h4>Operations:</h4>
      <p>1. Fees paid by subscribers to the RA is only for research analyst services and is not for any investment, FD or Demat purpose.</p>
      <p>2. The RA or its executives don't execute any trade on the customer's behalf</p>
      <p>3. For Refunds, you can read the Refund Policy in the terms of services.</p>
      <p>4. Investment in the Stock Market is subject to market risk and your capital may be at risk. The RA or any of its executives doesn't guarantee any pre-specified profits.</p>
      <p>The RA or her employees would never call you until you ask/request for any services and contact the RA to call you. So, beware of any unsolicited calls in the name of the RA, if you have not requested for the callback. You should report such calls to us at.</p>
      <p>The RA would never send you any small-cap/penny stocks tip. So if you receive any SMS, Call or Mail regarding any such stock tips, kindly report at. <br></p>
    </div>
  </div>
  <div class="container">
    <div class="row copyright-text">
      <div class="col-md-6">
        <div>
          <p> <i class="ri-copyright-line"></i><a href="{{route('home.index')}}">Dream Wealth Research</a> . All Rights Reserved By </p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="">
          <ul>
            <li><a href="{{route('home.terms')}}">Term & Conditions</a> </li>
            <li><a href="{{route('home.privacy')}}">Privacy Policy</a> </li>
            <li><a href="{{route('home.refund')}}">Refund Policy</a> </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- /Footer -->
<!-- Go top -->
<div class="whatsapp">
  <a href="https://wa.me/+91{{$contact->phone }}" target="_blank">
    <svg class="svg-inline--fa fa-whatsapp" aria-hidden="true" focusable="false" data-prefix="fab" data-icon="whatsapp" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
      <path fill="currentColor" d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path>
    </svg>
    <!-- <i class="fa-brands fa-whatsapp"></i> Font Awesome fontawesome.com -->
  </a>
</div>