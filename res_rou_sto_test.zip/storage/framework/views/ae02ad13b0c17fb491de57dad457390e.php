<div class="header">
<div class="header-left">

</div>
    <div class="menu-toggle">

        <a href="javascript:void(0);" id="toggle_btn">

            <i class="fas fa-bars"></i>

        </a>

    </div>

<div class="top-nav-search">
<form>
<input type="text" class="form-control" placeholder="Search here">
<button class="btn" type="submit"><i class="fas fa-search"></i></button>
</form>
</div>
<a class="mobile_btn" id="mobile_btn">
<i class="fas fa-bars"></i>
</a>

    <ul class="nav user-menu">

        <li class="nav-item dropdown has-arrow new-user-menus">

            <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">

                <span class="user-img">

<img class="rounded-circle" src="<?php echo e(url('assets/img/icons/dash-icon-01.svg')); ?>" width="31" alt="Ryan Taylor">

<div class="user-text">

<h6><?php echo e(ucfirst(Auth::guard('subadmin')->name)); ?></h6>

</div>

</span>

    </a>

      <div class="dropdown-menu">

          <a class="dropdown-item" href="<?php echo e(route('subadmin.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout').submit();">Log Out</a>

        <form id="logout" action="<?php echo e(route('subadmin.logout')); ?>" method="get" style="display: none;">



        <?php echo csrf_field(); ?>



    </form>



</div>



        </li>



    </ul>



</div><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/subadmin/include/header.blade.php ENDPATH**/ ?>