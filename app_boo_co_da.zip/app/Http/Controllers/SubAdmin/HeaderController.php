<?php

namespace App\Http\Controllers\SubAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\HeaderDes;

class HeaderController extends Controller
{
 
    public function edit(){
        $data['headers'] = DB::table('header_des')->where('id',1)->first();
        $data['title'] = "Header";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('subadmin.header-des.edit',$data);
    }

    public function update(Request $request)
    {
    //  dd($request->all());
        $request->validate([
        //    'title' => 'required',
            'description' => 'required',
        ]);
        //  echo "<pre>";print_r($request->all());die;
        $abouts = HeaderDes::find($request->id);
        $abouts->description = $request->description;
        $abouts->save();
        // dd($user->toArray());
        session()->flash('success', 'Header Description has been Update !!');
        return redirect()->route('subadmin.header.edit');
    }



    
}
