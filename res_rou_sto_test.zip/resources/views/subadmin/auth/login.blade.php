@extends('subadmin.layout.loginapp')

@section('content')

<div class="login-wrapper">
<div class="container">
<div class="loginbox">
<div class="login-left">
<img class="img-fluid" src="{{url('assets/img/realcloud_logo1.png')}}" alt="Logo">
</div>
<div class="login-right">
<div class="login-right-wrap">
<h1>Welcome to Sub Admin</h1>

<h2>Sign in</h2>

 @if (session('error'))
<div class="alert alert-danger">
    {{ session('error') }}
</div>
@endif

<form action="{{ route('login.functionality') }}" method="post">
    @csrf
<div class="form-group">
<label>Email <span class="login-danger">*</span></label>
<input class="form-control" type="text" name="email">
<span class="profile-views"><i class="fas fa-user-circle"></i></span>

</div>
<div class="form-group">
<label>Password <span class="login-danger">*</span></label>
<input class="form-control pass-input" type="password" name="password">
<span class="profile-views feather-eye toggle-password"></span>

</div>

<div class="form-group">
<button class="btn btn-primary btn-block" type="submit">Login</button>
</div>
</form>


</div>
</div>
</div>
</div>
</div>
@endsection