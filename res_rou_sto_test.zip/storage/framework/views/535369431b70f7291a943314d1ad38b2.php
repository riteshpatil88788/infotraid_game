<!DOCTYPE html>
<html lang="en">


<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>Indore Makta - Dashboard</title>

<link rel="shortcut icon" href="<?php echo e(url('assets/img/real_favii1.png')); ?>">

<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,400;0,500;0,700;0,900;1,400;1,500;1,700&amp;display=swap" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(url('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(url('assets/plugins/feather/feather.css')); ?>">

<link rel="stylesheet" href="<?php echo e(url('assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/plugins/fontawesome/css/all.min.css')); ?>">



<link rel="stylesheet" href="<?php echo e(url('assets/plugins/datatables/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/css/ckeditor.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">


<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<style type="text/css">
         
         .CodeMirror {
             height: 400px;
         }
 
         .editor-preview-active,
         .editor-preview-active-side {
             /*display:block;*/
         }
         .editor-preview-side>p,
         .editor-preview>p {
             margin:inherit;
         }
         .editor-preview pre,
         .editor-preview-side pre {
              background:inherit;
              margin:inherit;
         }
         .editor-preview table td,
         .editor-preview table th,
         .editor-preview-side table td,
         .editor-preview-side table th {
          border:inherit;
          padding:inherit;
         }
         .view_data_param {
             cursor: pointer;
         }
 
      </style>


</head>
<body>

<div class="main-wrapper">
<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<script src="<?php echo e(url('assets/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/5.0.0/tinymce.min.js"></script>
<script src="<?php echo e(url('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(url('assets/js/feather.min.js')); ?>"></script>

<script src="<?php echo e(url('assets/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

<script src="<?php echo e(url('assets/plugins/datatables/datatables.min.js')); ?>"></script>


<script src="<?php echo e(url('assets/js/script.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
<script type="text/javascript">

$(document).ready(function(){

tinymce.init({
            selector: 'textarea.tinymce',
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table paste code help wordcount'
            ],
           toolbar: "insertfile undo redo | styleselect | bold italic backcolor | removeformat | help  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image fullpage | forecolor backcolor emoticons | preview | code ",
        });
});

function confirmDelete() {
        return confirm('Are you sure you want to delete?');
    }
</script>
</body>


</html><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/admin/layout/app.blade.php ENDPATH**/ ?>