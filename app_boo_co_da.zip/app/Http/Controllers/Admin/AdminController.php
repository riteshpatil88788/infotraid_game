<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\Withdrawal;

class AdminController extends Controller
{
    //todo: admin login form
    public function login()
    {
//echo "12";die;
        return view('admin.auth.login');
    }

    //todo: admin login functionality
    public function Adminlogin_functionality(Request $request){
    //    echo "<pre>";print_r($request->all());die;
        $request->validate([
            'email'=>'required',
            'password'=>'required',
        ]);
        // echo "as";die;
        if (Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request->password], $request->remember)) {
           
            session()->flash('success', 'Successfully logged in!');
            return redirect()->route('admin.dashboard');
        } else {
            // echo "as";die;
            // Authentication failed, redirect back with error message
            session()->flash('error', 'Invalid email or password');
            return back()->withInput($request->only('email'));
        }
    }

    public function dashboard()
    {
     
        return view('admin.dashboard');
    }


    //todo: admin logout functionality
    public function Adminlogout(){
        Auth::guard('admin')->logout();
        return redirect()->route('login.Adminform');
    }
    
    public function withdrawal(){
        
        $data['withdrawal'] = DB::table('withdrawal_requests')->get();
        $data['title'] = "Withdrawal Requests";
        return view('admin.withdrawal.index',$data);
    }
    
   public function updateStatus(Request $request)
{
    
    // Validate the incoming request
    $request->validate([
        'id' => 'required',
        'status' => 'required',
    ]);
//   dd($request->all());
    try {
        // Find the withdrawal record
        $withdrawal = Withdrawal::find($request->id);
        
        // Update the status
        $withdrawal->withdrawal_status = $request->status;
        $withdrawal->save();

       if($withdrawal){
           $status = ($request->status == '1') ? '1' : '0';
            $withdrawal_payment = DB::table('withdrawal_payments')->insert([
                'user_id' => $withdrawal->user_id,
                'amount' => $withdrawal->amount,
                'payment_id' => $request->payment_id,
                'status' => $status,
                'withdrawal_status' => $withdrawal->withdrawal_status,
                'admin_id' => auth()->guard('admin')->user()->id ?? null,
                'subadmin_id' => auth()->guard('subadmin')->user()->id ?? null,
              
            ]);
       }
       
        return response()->json([
            'success' => true,
            'message' => 'Withdrawal status updated successfully.',
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Failed to update withdrawal status. ' . $e->getMessage(),
        ]);
    }
}

    
    public function Withdrawaldestroy($id){
       
       
        $MatkaResult = Withdrawal::find($id);
        $MatkaResult->delete();
        session()->flash('success', 'Withdrawal has been Deleted !!');
        return redirect()->route('admin.withdrawal.index');
    }

}
