@extends('admin.layout.app')
@section('content')
<div class="page-wrapper" style="min-height: 366px;">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-xl-12">

                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Edit {{$title}}</h3>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="bank-inner-details">
                            <div class="row">
                            @if (session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                @endif

                                <div class="col-lg-12 col-md-12">
                                    <form id="formSubmit" action="{{ route('admin.notice.update')}}" method="post" enctype="multipart/form-data">
                                        @csrf
                                     <input type="hidden"  name="id" value="{{@$notices->id}}" />
                                     <div class="row">
                                          <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Description<span class="text-danger">*</span></label>
                                                 <textarea type="text" name="description" class="form-control tinymce" id="editor1" >{{ @$notices->description }}</textarea>
                                              </div>
                                                @error('description')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                        <div class="bank-details-btn ">
                                            <button type="submit" class="btn bank-cancel-btn me-2">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
