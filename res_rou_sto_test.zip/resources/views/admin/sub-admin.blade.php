@extends('admin.layout.app') @section('content')
<div class="page-wrapper">
    <div class="content container-fluid">



        <div class="row">
            <div class="col-sm-12">
                <div class="card card-table">
                    <div class="card-body">

                        <div class="page-header">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="page-title">{{$title}}</h3>
                                </div>
                                <div class="col-auto text-end float-end ms-auto download-grp">
                                    <a href="{{ route('admin.matkaresult.create') }}" class="btn btn-primary"><i class="fas fa-plus"></i></a>
                                </div>
                            </div>
                        </div>
                        @if (session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                @endif
                        <div class="table-responsive">
                            <table class="table border-0 star-student table-hover table-center mb-0 datatable table-striped">
                                <thead class="student-thread">
                                    <tr>
                                        <th>S.No</th>
                                        <th>Name</th>
                                        <th>status</th>
                                      
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1;?>
                                    @foreach($SubAdmins as $SubAdmin)
                                    <tr>
                                        <td>{{$i}}</td>
                                        <td>{{ $SubAdmin->name }}</td>
                                        <td> 
                                        <div class="form-check form-switch">
                                              <input class="form-check-input statusCheck" type="checkbox"  id="statusCheck" data-id="{{ $SubAdmin->id }}" {{ $SubAdmin->status ? 'checked' : '' }}>
                                        </div>
                                        </td>
                                       
                                        
                                    </tr>
                                    <?php $i++;?>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

@endsection
@section('script')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(document).ready(function() {
      
        $('.statusCheck').change(function() {
            
            var id = $(this).data('id');
            var status = $(this).prop('checked') ? 1 : 0;
            var confirmationMessage = status == 1 ? 'Are you sure you want to active?' : 'Are you sure you want to inactive?';
            if (confirm(confirmationMessage)) {
                $.ajax({
                    url: '{{ route("admin.SubAdmin.status") }}',
                    method: 'POST',
                    data: {
                        id: id,
                        status: status,
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        console.log('Status updated successfully.');
                       
                    },
                    error: function(xhr) {
                        console.error('Error updating status.');
                    }
                });
            } else {
                $(this).prop('checked', !status);
            }
        });
    });
</script>


@endsection
