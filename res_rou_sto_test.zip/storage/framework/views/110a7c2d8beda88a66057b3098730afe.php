
<meta name="viewport" content="initial-scale=1.0, width=device-width">
<meta name="robots" content="noindex, nofollow">
<style>
    .f_label{float:left;padding:5px;font-size:15px;font-weight:700;font-family:myfont1;}
    .g_box{border-radius:5px;border:1px solid #ccc;display: inline-block;box-sizing: border-box;width:100%;height:35px;background-color:#f8f8f8;padding:8px;font-size:15px;font-weight:700;margin:5px 0 5px 0;}
    .s_btn{background-color:#133E8C;border:1px solid #133E8C;border-radius:5px;margin:15px 0 0 0;font-size:15px;font-weight:700;cursor:pointer;font-family:myfont1;color:#fff;padding:10px 20px 8px 20px;}
    .header{text-align:center;border-radius:3px;border:2px solid #13316c;box-sizing:border-box;background:radial-gradient(white, #e9f5fa);box-shadow:0 0 5px #13316c;height:60px;padding:0px;margin:5px 0 5px 0;}
    .heading{width:100%;text-align:center;font-size:20px;background-color:#133E8C;color:#fff;margin:2px 0 2px 0;border-radius:3px;border:2px solid #041C47;font-family:myfont1;box-sizing:border-box;}
    .comment_box{border:2px solid ##133E8C;border-radius:5px;padding:5px;width:100%;box-sizing:border-box;text-align:center;margin:5px 0 5px 0;}
    .user_login{border-radius:3px;padding:3px;text-align:center;font-size:20px;font-family:myfont1;margin:5px 0 5px 0;background-color:#133E8C;border:1px solid red;box-shadow:0 0 5px #133E8C;color:yellow;}
</style>

<div class="user_login">USER LOGIN</div>
<div class="comment_box">
    <form method="POST" action="<?php echo e(route('home.loginstore')); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label class="f_label">User Name : </label>
            <input class="g_box" type="text" name="email" size="15" placeholder="Username" required="required" />
        </div>
        <div>
            <label class="f_label">Password : </label>
            <input class="g_box" type="password" name="password" size="15" placeholder="PASSWORD" required="required" />
        </div>
        <div>Remember me?
            <input type="checkbox" name="remember" value="ON" size="15" checked />
        </div>
        <div>
            <input class="s_btn" type="submit" value=" SUBMIT " name="submit" />
        </div>
    </form>
    <div><a href="<?php echo e(route('home.ResultGuessing')); ?>">Return to Forum Page</a></div>
</div>
<div class="comment_box">
    New Member Register Here Free
    <div>
        <button onclick="if (!window.__cfRLUnblockHandlers) return false; window.location.href='<?php echo e(route('home.register')); ?>'" type="button" class="s_btn" data-cf-modified-8e7c4ad755aaf4b205aa5876->Register Now</button>
    </div>
</div>
<style>
    .footer{border-radius:3px;text-align:center;color:#fff;font-size:18px;font-weight:700;font-family:myfont1;height:130px;}
    .home{background-color:#ffb12a;border:1px solid #bc4200;border-radius:20px 0 0 20px;color:#000;padding: 4px 0 2px 0;width:100px;float:right;}
    .back{background-color:#fdf243;border:1px solid #bc4200;border-radius:0 20px 20px 0;color:#000;padding: 4px 0 2px 0;width:100px;float:left;}
    .footer_title{font-size:18px;padding:3px 0;}
    .f_block{width:100%;height:30px;}
    .ff1{float:left;width:50%;}
    .bg3{background-color:#133E8C;border:1px solid #133E8C;box-shadow:0 0 10px #133E8C;}
</style>
<div class="footer bg3" style="margin:10px 0 10px 0;">
    <p class="footer_title">IndoreMatka.com
        <br> ALL RIGHTS RESERVED (2012-2018)</p>
    <div class="f_block">
        <a href="/">
            <div class="ff1">
                <div class="home">HOME</div>
            </div>
        </a>
        <a href="javascript:history.back()">
            <div class="ff1">
                <div class="back">BACK</div>
            </div>
        </a>
    </div>
</div>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"8d147aed3d6c426c","version":"2024.10.1","r":1,"token":"41cfb4a3a50b49079919ccd461b75608","serverTiming":{"name":{"cfExtPri":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}}}'
crossorigin="anonymous"></script>
<script src="<?php echo e(url('front-assets/rocket-loader.min.js')); ?>" data-cf-settings="8e7c4ad755aaf4b205aa5876-|49" defer></script><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/login.blade.php ENDPATH**/ ?>