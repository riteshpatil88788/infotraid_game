<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\{Service,ServiceAgreement,StandardWarning,Regulatory};

class ServiceController extends Controller
{
 
    public function index()
    {
        $data['services'] = DB::table('services')
        ->join('categories', 'services.category', '=', 'categories.id')
        ->join('subcategories', 'services.sub_category', '=', 'subcategories.id')
        ->select('services.*', 'categories.title as c_title', 'subcategories.title as sc_title')
        ->orderBy('services.id', 'desc')
        ->get();
        // echo "<pre>";print_r($data['services']);die;
        $data['categories'] = DB::table('categories')->get();
        // echo "<pre>";print_r($data['categories']);die;
        $data['subcategories'] = DB::table('subcategories')->get();
        $data['title'] = "Services";
        return view('admin.service.index',$data);
    }

    public function create(){
        $data['title'] = "Services";
        $titles = DB::table('services')->pluck('category');
        // echo "<pre>";print_r($titles);die;
        // $data['categories'] = DB::table('categories')->whereNotIn('id', $titles)->get();
        $data['categories'] = DB::table('categories')->get();
        // echo "<pre>";print_r($data['categories']);die;
        $data['subcategories'] = DB::table('subcategories')->get();
        return view('admin.service.create',$data);
    }

    public function store(Request $request){
        
        $request->validate([
          //  'title' => 'required',
            'investment_description' => 'required',
            'product_description' => 'required',
            'category' => 'required',
            'subcategory' => 'required',
           
        ]);
         
        $service = new Service;
       $service->title = $request->title;
        $service->investment_description = $request->investment_description;
        $service->product_description = $request->product_description;
        $service->category = $request->category;
        $service->sub_category = $request->subcategory;
        $service->weekly = $request->weekly;
        $service->monthly = $request->monthly;
        $service->quarterly = $request->quarterly;
        $service->half_yearly = $request->half_yearly;
        $service->yearly = $request->yearly;
        $service->weeklygst = $request->weeklygst;
        $service->monthlygst = $request->monthlygst;
        $service->quarterlygst = $request->quarterlygst;
        $service->half_yearlygst = $request->half_yearlygst;
        $service->yearlygst = $request->yearlygst;
        // if($request->file('image')){
        //     $file = $request->file('image');
        //     $name = time(). '_' .$file->getClientOriginalName();
        //     $file->move('public/images/', $name);
        //     $service->image = $name;
        // }
        $service->save();
        session()->flash('success', 'Services has been created !!');
        return redirect()->route('service.index');
    }

    public function edit($id){

        $data['service'] = DB::table('services')
        ->join('categories', 'services.category', '=', 'categories.id')
        ->join('subcategories', 'services.sub_category', '=', 'subcategories.id')
        ->select('services.*', 'categories.title as c_title', 'subcategories.title as sc_title')
        ->where('services.id', $id)
        ->first();
        // echo "<pre>";print_r($data['service']);die;
        $servicescat = DB::table('services')->pluck('category')->toArray();
        $cat = DB::table('services')->where('id', $id)->first();
        $key = array_search($cat->category, $servicescat);
       
        unset($servicescat[$key]);
        $data['categories'] = DB::table('categories')->get();
        $data['subcategories'] = DB::table('subcategories')->get();
     
        $data['title'] = "Services";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('admin.service.edit',$data);
    }

    public function update(Request $request)
    {
       //  echo "<pre>";print_r($request->all());die;
        //  dd($request->all());
        $request->validate([
          //  'title' => 'required',
          'investment_description' => 'required',
          'product_description' => 'required',
            'category' => 'required',
            'subcategory' => 'required',
           
        ]);
        // if($request->file('image')){
        //     $request->validate([
        //         'image' => 'required|image',
        //     ]);  
        // }
        //  echo "<pre>";print_r($request->all());die;
        $service = Service::find($request->id);
        $service->title = $request->title;
        $service->investment_description = $request->investment_description;
        $service->product_description = $request->product_description;
        $service->category = $request->category;
        $service->sub_category = $request->subcategory;
        $service->weekly = $request->weekly;
        $service->monthly = $request->monthly;
        $service->quarterly = $request->quarterly;
        $service->half_yearly = $request->half_yearly;
        $service->yearly = $request->yearly;
        $service->weeklygst = $request->weeklygst;
        $service->monthlygst = $request->monthlygst;
        $service->quarterlygst = $request->quarterlygst;
        $service->half_yearlygst = $request->half_yearlygst;
        $service->yearlygst = $request->yearlygst;
        // if($request->file('image')){
        //     $file = $request->file('image');
        //     $name = time(). '_' .$file->getClientOriginalName();
        //     $file->move('public/images/', $name);
        //     $service->image = $name;
        // }
        $service->save();
        // dd($user->toArray());
        session()->flash('success', 'Services has been Update !!');
        return redirect()->route('service.index');
    }

    public function destroy($id){
        $service = Service::find($id);
        $service->delete();
        session()->flash('success', 'Services has been Deleted !!');
        return redirect()->route('service.index');
    }

    public function selectCategory(Request $request) {
 
        $subcategories = DB::table('subcategories')->where('category', $request->value)->get();
        
        
        $subcategoryIds = $subcategories->pluck('id')->toArray();
        
        $services = DB::table('services')->whereIn('sub_category', $subcategoryIds)->get();
        // echo "<pre>";print_r($services->toArray());die;
        // Extract the IDs of the subcategories that have associated services
        $serviceSubCategoryIds = $services->pluck('sub_category')->toArray();
        
        // Fetch subcategories that do not have associated services
        $availableSubcategories = DB::table('subcategories')
            ->where('category', $request->value)
            ->whereNotIn('id', $serviceSubCategoryIds)
            ->get();
        
        // Generate the options for the dropdown
        $subcategoryOptions = '<option value="">Select Sub Category</option>';
        foreach ($availableSubcategories as $subcategory) {
            $subcategoryOptions .= '<option value="' . $subcategory->id . '">' . $subcategory->title . '</option>';
        }
        
        // Return the response as JSON
        return response()->json(['subcategory' => $subcategoryOptions]);
    }
    


    public function serviceCategoryList()
    {
        $data['serviceCategory'] = DB::table('service_categories')->orderBy('id','desc')->get();
        $data['title'] = "Lets Talk Form";
        return view('admin.service.service-category-list',$data);
    }

    public function serviceStatus(Request $request)
    {
        // Handle your logic to update status here
        $id = $request->input('id');
        $status = $request->input('status');
        $service = Service::find($id);
        $service->status = $status;
        $service->save();
            return response()->json(['status' => 'Status Active successfully']);
       
       
    }

    public function enquiriesList()
    {
        $data['enquiries'] = DB::table('enquiries')->orderBy('id','desc')->get();
        $data['title'] = "Enquiry Form";
        return view('admin.enquiries',$data);
    }

    public function trialenquiriesList()
    {
        $data['trialenquiries'] = DB::table('trial_enquiries')->orderBy('id','desc')->get();
        $data['title'] = "Trial Enquiry Form";
        return view('admin.trial-enquiries',$data);
    }

    public function careerList()
    {
        $data['careers'] = DB::table('careers')->orderBy('id','desc')->get();
        $data['title'] = "Career Form";
        return view('admin.career',$data);
    }


    public function jobdetaillist()
    {
       
        $data['job_applys'] = DB::table('job_applys')->orderBy('id','desc')->get();
        $data['title'] = "Job Apply Form";
        return view('admin.jobdetail',$data);
    }

    

    public function ServiceAgreementlist()
    {
       $data['services'] = ServiceAgreement::orderBy('id','desc')->get();
        return view('admin.service-agreement',$data);
    }


    public function checkesign($client_id)
    {
   
    $curl = curl_init();
    
    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://kyc-api.aadhaarkyc.io/api/v1/esign/get-signed-document/'.$client_id,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'GET',
      CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJmcmVzaCI6ZmFsc2UsImlhdCI6MTY2MTMyMDQ2MywianRpIjoiMDE2NjgwNzEtYTAwZi00MDEyLTk0YzgtYjZlYTA3NTdiMTA4IiwidHlwZSI6ImFjY2VzcyIsImlkZW50aXR5IjoiZGV2LnBhbmRwaW5mb3RlY2hAc3VyZXBhc3MuaW8iLCJuYmYiOjE2NjEzMjA0NjMsImV4cCI6MTk3NjY4MDQ2MywidXNlcl9jbGFpbXMiOnsic2NvcGVzIjpbIndhbGxldCJdfX0.8VpdEIu_YZQpUqSmm1hHw2Sh3Qor16nk32saNc7Flz4'
          ),
    ));
    
     $response = curl_exec($curl);
    
    
    curl_close($curl);
    $res = json_decode($response); 
    // echo "<pre>";print_r($res);die;
    if(@$res->data->url) {
     return redirect($res->data->url);
    }
    else {
        echo $res->message;
    }
    }



    public function editStandardWarning(){
        $data['Standard'] = DB::table('standard_warnings')->where('id',1)->first();
        $data['title'] = "Standard Warning";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('admin.standard-warning.edit',$data);
    }

    public function updateStandardWarning(Request $request)
    {
    //  dd($request->all());
        $request->validate([
        //    'title' => 'required',
            'description' => 'required',
            
        ]);
        if($request->file('image')){
            $request->validate([
                'image' => 'required|image',
            ]);  
        }
        //  echo "<pre>";print_r($request->all());die;
        $abouts = StandardWarning::find($request->id);
      
        $abouts->description = $request->description;
       
        $abouts->save();
        // dd($user->toArray());
        session()->flash('success', 'Standard Warning has been Update !!');
        return redirect()->route('service.editStandardWarning');
    }


    public function Regulatoryedit(){
        $data['Regulatory'] = DB::table('regulatorys')->where('id',1)->first();
        $data['title'] = "Regulatory";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('admin.regulatory.edit',$data);
    }

    public function Regulatoryupdate(Request $request)
    {
        //  dd($request->all());
        $request->validate([
            'research' => 'required|regex:/^[\pL\s-]+$/u',
            'type' => 'required',
            'registration_no' => 'required',
            'validity' => 'required',
            'office_address' => 'required',
            'contact_details' => 'required|regex:/^[6-9][0-9]{9}$/',
            'email' => 'required',
            'local_office_address' => 'required',
            'compliance_officer' => 'required',
            'trade_name' => 'required|regex:/^[\pL\s-]+$/u',
        ]);

        //  echo "<pre>";print_r($request->all());die;
        $Regulatory = Regulatory::find($request->id);
        $Regulatory->research = $request->research;
        $Regulatory->type = $request->type;
        $Regulatory->registration_no = ucwords($request->registration_no);
        $Regulatory->validity = $request->validity;
        $Regulatory->office_address = $request->office_address;
        $Regulatory->contact_details = $request->contact_details;
        $Regulatory->email = $request->email;
        $Regulatory->local_office_address = $request->local_office_address;
        $Regulatory->compliance_officer = $request->compliance_officer;
        $Regulatory->trade_name = $request->trade_name;
        $Regulatory->save();
        // dd($user->toArray());
        session()->flash('success', 'Regulatory Detail has been Update !!');
        return redirect()->route('service.Regulatoryedit');
    }

    
}
