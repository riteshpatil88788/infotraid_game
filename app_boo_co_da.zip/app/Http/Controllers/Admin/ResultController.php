<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\Result;
use App\Models\User;

class ResultController extends Controller
{
 
    public function index()
    {
        
        $data['results'] = DB::table('results')->orderBy('id','desc')->get();
        $data['title'] = "Result";
        return view('admin.result.index',$data);
    }

    public function create(){
        $data['title'] = "Result";
          $data['matkaresults'] = DB::table('matka_results')->groupBy('title')->orderBy('id','desc')->get();
        return view('admin.result.create',$data);
    }
    
    function singleANkresult($str) {
    // Initialize the sum
    $sum = 0;$str = (string)$str;

    // Loop through each character in the string
    for ($i = 0; $i < strlen($str); $i++) {
        // Check if the character is a digit
        if (is_numeric($str[$i])) {
            $sum += (int)$str[$i];  // Add the digit to the sum
        }
    }

    // If the sum is a two-digit number, return the rightmost digit
    if ($sum >= 10) {
        return $sum % 10;  // Get the rightmost digit
    }

    // Return the sum if it's a single digit
    return $sum;
   }
    
    public function store(Request $request){
        $request->validate([
            'matka_result_id' => 'required',
            'patta1' => 'required|numeric|digits:3',
           
        ]);
       //  echo "<pre>";print_r($request->all());die;
        $MatkaResult = new Result;
        $MatkaResult->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $MatkaResult->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;
        $MatkaResult->matka_result_id = $request->matka_result_id;
        $MatkaResult->patta1 = $request->patta1;
        $MatkaResult->save();
         
        $bids = DB::table('bid_history')->where([['game_id', $request->matka_result_id], ['status', 0]])->get();
        $matka_results = DB::table('matka_results')->select('firsttime', 'lasttime')->where('id', $request->matka_result_id)->first();
        $ftime = date('h:i', strtotime($matka_results->firsttime));
        $ltime = date('h:i', strtotime($matka_results->lasttime));
        $ftime = strtotime(date("Y-m-d") . " " . $ftime);
        $ltime = strtotime(date("Y-m-d") . " " . $ltime);
        foreach($bids as $bid){
            $game = DB::table('plays')->where('id', $bid->play_game_id)->first();
            $gamerate = DB::table('game_rates')->where('play', $bid->play_game_id)->first();
            $user = User::find($bid->user_id);
            if($bid->game_type == 'open'){
               if($game->title == "Single Ank"){
                 if((int)$this->singleANkresult($request->patta1) == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status' => 2]);     
                 }
               }elseif($game->title == "Single Pana"){
                 if((int)$request->patta1 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }elseif((int)$this->singleANkresult($request->patta1) == (int)$this->singleANkresult($bid->number)){
                   $gamerate = DB::table('game_rates')->where('play', 1)->first();
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }
               }elseif($game->title == "Double Pana"){
                 if((int)$request->patta1 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }elseif((int)$this->singleANkresult($request->patta1) == (int)$this->singleANkresult($bid->number)){
                   $gamerate = DB::table('game_rates')->where('play', 1)->first();
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }  
               }elseif($game->title == "pana family"){
                  if((int)$request->patta1 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }  
               }elseif($game->title == "SP DP TP"){
                  if((int)$request->patta1 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }elseif((int)$this->singleANkresult($request->patta1) == (int)$this->singleANkresult($bid->number)){
                   $gamerate = DB::table('game_rates')->where('play', 1)->first();
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }  
               }elseif($game->title == "Jodi"){
                //  if((int)$request->patta1 == (int)$bid->number){
                //   $winamount = round($gamerate->rate/$gamerate->unit);
                //   $winamount = (int)$winamount * (int)$bid->amount;
                //   $user->wallet += $winamount;
                //   $user->save();
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                //  }else{
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                //  }   
               }elseif($game->title == "Triple Pana"){
                  if((int)$request->patta1 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }  
               }elseif($game->title == "Two Digit Pana"){
                 if((int)$request->patta1 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }elseif(strpos($request->patta1, $bid->digit)){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }   
               }elseif($game->title == "SP Motor"){
                 if((int)$request->patta1 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }   
               }elseif($game->title == "DP Motor"){
                 if((int)$request->patta1 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }   
               }elseif($game->title == "Jodi Family"){
                //  if((int)$request->patta1 == (int)$bid->number){
                //   $winamount = round($gamerate->rate/$gamerate->unit);
                //   $winamount = (int)$winamount * (int)$bid->amount;
                //   $user->wallet += $winamount;
                //   $user->save();
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                //  }else{
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                //  }   
               }elseif($game->title == "Red Jodi"){
                //  if((int)$request->patta1 == (int)$bid->number){
                //   $winamount = round($gamerate->rate/$gamerate->unit);
                //   $winamount = (int)$winamount * (int)$bid->amount;
                //   $user->wallet += $winamount;
                //   $user->save();
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                //  }else{
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                //  }   
               }elseif($game->title == "Digit Base Jodi"){
                // if((int)$request->patta1 == (int)$bid->number){
                //   $winamount = round($gamerate->rate/$gamerate->unit);
                //   $winamount = (int)$winamount * (int)$bid->amount;
                //   $user->wallet += $winamount;
                //   $user->save();
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                //  }else{
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                //  }    
               }elseif($game->title == "Odd Even"){
                 if((int)$this->singleANkresult($request->patta1) == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }  
               }elseif($game->title == "Half Sangam (A)"){
                   $result = $request->patta1."-".$this->singleANkresult($request->patta1);
                if($result == $bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }    
               }elseif($game->title == "Half Sangam (B)"){
                //  $result1 = $request->patta1."-".$this->singleANkresult($request->patta1);
                // if($result == $bid->number){
                //   $winamount = round($gamerate->rate/$gamerate->unit);
                //   $winamount = (int)$winamount * (int)$bid->amount;
                //   $user->wallet += $winamount;
                //   $user->save();
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                //  }else{
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                //  }  
               }elseif($game->title == "Full Sangam"){
                  // $result2 = $request->patta1."-".$this->singleANkresult($request->patta1)."".$this->singleANkresult($request->patta2)."-".$request->patta2;
                // if($result2 == $bid->number){
                //   $winamount = round($gamerate->rate/$gamerate->unit);
                //   $winamount = (int)$winamount * (int)$bid->amount;
                //   $user->wallet += $winamount;
                //   $user->save();
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                //  }else{
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                //  }   
               }          
            }
        // echo "<pre>";print_r($MatkaResult);die;
        
     }
     session()->flash('success', 'Result has been created !!');
        return redirect()->route('admin.result.index');
    }

    public function edit($id){
        $data['result'] = DB::table('results')->where('id',$id)->first();
        $data['matkaresults'] = DB::table('matka_results')->groupBy('title')->orderBy('id','desc')->get();
        $data['title'] = "Result";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('admin.result.edit',$data);
    }

    public function update(Request $request)
    {
        //  dd($request->all());
        $request->validate([
            'matka_result_id' => 'required',
            'patta2' => 'required|numeric|digits:3',
           
        ]);
         // echo "<pre>";print_r($request->all());die;
        $MatkaResult = Result::where('id',$request->id)->first();
        $MatkaResult->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $MatkaResult->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;       
        $MatkaResult->matka_result_id = $request->matka_result_id;
        $MatkaResult->patta2 = $request->patta2;
        $MatkaResult->save();
        // dd($user->toArray());
        $bids = DB::table('bid_history')->where([['game_id', $request->matka_result_id], ['status', 0]])->get();
        $matka_results = DB::table('matka_results')->select('firsttime', 'lasttime')->where('id', $request->matka_result_id)->first();
        $ftime = date('h:i', strtotime($matka_results->firsttime));
        $ltime = date('h:i', strtotime($matka_results->lasttime));
        $ftime = strtotime(date("Y-m-d") . " " . $ftime);
        $ltime = strtotime(date("Y-m-d") . " " . $ltime);
        foreach($bids as $bid){
            $game = DB::table('plays')->where('id', $bid->play_game_id)->first();
            $gamerate = DB::table('game_rates')->where('play', $bid->play_game_id)->first();
            $user = User::find($bid->user_id);
            if($bid->game_type == 'close'){
               if($game->title == "Single Ank"){
                 if((int)$this->singleANkresult($request->patta2) == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status' => 2]);     
                 }
               }elseif($game->title == "Single Pana"){
                 if((int)$request->patta2 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }elseif((int)$this->singleANkresult($request->patta2) == (int)$this->singleANkresult($bid->number)){
                   $gamerate = DB::table('game_rates')->where('play', 1)->first();
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }
               }elseif($game->title == "Double Pana"){
                 if((int)$request->patta2 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }elseif((int)$this->singleANkresult($request->patta2) == (int)$this->singleANkresult($bid->number)){
                   $gamerate = DB::table('game_rates')->where('play', 1)->first();
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }  
               }elseif($game->title == "pana family"){
                  if((int)$request->patta2 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }  
               }elseif($game->title == "SP DP TP"){
                  if((int)$request->patta2 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }elseif((int)$this->singleANkresult($request->patta2) == (int)$this->singleANkresult($bid->number)){
                   $gamerate = DB::table('game_rates')->where('play', 1)->first();
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }  
               }elseif($game->title == "Jodi"){
                //  if((int)$request->patta1 == (int)$bid->number){
                //   $winamount = round($gamerate->rate/$gamerate->unit);
                //   $winamount = (int)$winamount * (int)$bid->amount;
                //   $user->wallet += $winamount;
                //   $user->save();
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                //  }else{
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                //  }   
               }elseif($game->title == "Triple Pana"){
                  if((int)$request->patta2 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }  
               }elseif($game->title == "Two Digit Pana"){
                 if((int)$request->patta2 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }elseif(strpos($request->patta2, $bid->digit)){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }   
               }elseif($game->title == "SP Motor"){
                 if((int)$request->patta2 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }   
               }elseif($game->title == "DP Motor"){
                 if((int)$request->patta2 == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }   
               }elseif($game->title == "Jodi Family"){
                //  if((int)$request->patta1 == (int)$bid->number){
                //   $winamount = round($gamerate->rate/$gamerate->unit);
                //   $winamount = (int)$winamount * (int)$bid->amount;
                //   $user->wallet += $winamount;
                //   $user->save();
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                //  }else{
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                //  }   
               }elseif($game->title == "Red Jodi"){
                //  if((int)$request->patta1 == (int)$bid->number){
                //   $winamount = round($gamerate->rate/$gamerate->unit);
                //   $winamount = (int)$winamount * (int)$bid->amount;
                //   $user->wallet += $winamount;
                //   $user->save();
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                //  }else{
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                //  }   
               }elseif($game->title == "Digit Base Jodi"){
                // if((int)$request->patta1 == (int)$bid->number){
                //   $winamount = round($gamerate->rate/$gamerate->unit);
                //   $winamount = (int)$winamount * (int)$bid->amount;
                //   $user->wallet += $winamount;
                //   $user->save();
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                //  }else{
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                //  }    
               }elseif($game->title == "Odd Even"){
                 if((int)$this->singleANkresult($request->patta2) == (int)$bid->number){
                   $winamount = round($gamerate->rate/$gamerate->unit);
                   $winamount = (int)$winamount * (int)$bid->amount;
                   $user->wallet += $winamount;
                   $user->save();
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }  
               }elseif($game->title == "Half Sangam (A)"){
                //   $result = $request->patta1."-".$this->singleANkresult($request->patta1);
                // if($result == $bid->number){
                //   $winamount = round($gamerate->rate/$gamerate->unit);
                //   $winamount = (int)$winamount * (int)$bid->amount;
                //   $user->wallet += $winamount;
                //   $user->save();
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                //  }else{
                //   DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                //  }    
               }elseif($game->title == "Half Sangam (B)"){
                 $result1 = $this->singleANkresult($request->patta2)."-".$request->patta2;
                if($result == $bid->number){
                  $winamount = round($gamerate->rate/$gamerate->unit);
                  $winamount = (int)$winamount * (int)$bid->amount;
                  $user->wallet += $winamount;
                  $user->save();
                  DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                  DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }  
               }elseif($game->title == "Full Sangam"){
                   $result2 = $request->patta1."-".$this->singleANkresult($request->patta1)."".$this->singleANkresult($request->patta2)."-".$request->patta2;
                if($result2 == $bid->number){
                  $winamount = round($gamerate->rate/$gamerate->unit);
                  $winamount = (int)$winamount * (int)$bid->amount;
                  $user->wallet += $winamount;
                  $user->save();
                  DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                  DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }   
               }   
            }else{
                if($game->title == "Jodi"){
                 $jresult = $this->singleANkresult($request->patta1)."".$this->singleANkresult($request->patta2);
                 if((int)$jresult == (int)$bid->number){
                  $winamount = round($gamerate->rate/$gamerate->unit);
                  $winamount = (int)$winamount * (int)$bid->amount;
                  $user->wallet += $winamount;
                  $user->save();
                  DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                  DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }   
               }elseif($game->title == "Jodi Family"){
                   $jfresult = $this->singleANkresult($request->patta1)."".$this->singleANkresult($request->patta2);
                 if((int)$jfresult == (int)$bid->number){
                  $winamount = round($gamerate->rate/$gamerate->unit);
                  $winamount = (int)$winamount * (int)$bid->amount;
                  $user->wallet += $winamount;
                  $user->save();
                  DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                  DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }   
               }elseif($game->title == "Red Jodi"){
                $rjresult = $this->singleANkresult($request->patta1)."".$this->singleANkresult($request->patta2);
                 if((int)$rjresult == (int)$bid->number){
                  $winamount = round($gamerate->rate/$gamerate->unit);
                  $winamount = (int)$winamount * (int)$bid->amount;
                  $user->wallet += $winamount;
                  $user->save();
                  DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);  
                 }else{
                  DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }    
               }elseif($game->title == "Digit Base Jodi"){
                  $dbjresult = $this->singleANkresult($request->patta1)."".$this->singleANkresult($request->patta2);
                if(in_array($dbjresult,explode(",", $bid->digit))){
                  $winamount = round($gamerate->rate/$gamerate->unit);
                  $winamount = (int)$winamount * (int)$bid->amount;
                  $user->wallet += $winamount;
                  $user->save();
                  DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 1]);
                 }else{
                  DB::table('bid_history')->where('id', $bid->id)->update(['status'=> 2]);     
                 }    
               }
            }
        // echo "<pre>";print_r($MatkaResult);die;
        
     }
        session()->flash('success', 'Result has been Update !!');
        return redirect()->route('admin.result.index');
    }

    public function destroy($id){
       
       
        $MatkaResult = Result::find($id);
        $MatkaResult->delete();
        session()->flash('success', 'Result has been Deleted !!');
        return redirect()->route('admin.result.index');
    }

    
}
