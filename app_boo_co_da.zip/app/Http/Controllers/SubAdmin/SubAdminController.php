<?php

namespace App\Http\Controllers\SubAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;

class SubAdminController extends Controller
{
    //todo: admin login form
    public function login()
    {
        return view('subadmin.auth.login');
    }

    //todo: subadmin login functionality
    public function login_functionality(Request $request){
        // Validate input fields
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);
    
        // Attempt to authenticate with email, password, and status = 1
        if (Auth::guard('subadmin')->attempt(
            ['email' => $request->email, 'password' => $request->password, 'status' => 1],
            $request->has('remember') // check if "remember me" was checked
        )) {
            session()->flash('success', 'Successfully logged in!');
            return redirect()->route('subadmin.dashboard');
        } else {
            // Authentication failed, redirect back with error message
            session()->flash('error', 'Invalid email, password, or account is not active');
            return back()->withInput($request->only('email'));
        }
    }
    

    public function dashboard()
    {
     
        return view('subadmin.dashboard');
    }


    //todo: subadmin logout functionality
    public function logout(){
        Auth::guard('subadmin')->logout();
        return redirect()->route('login.form');
    }
}
