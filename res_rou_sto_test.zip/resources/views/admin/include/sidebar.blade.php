
<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="menu-title">
                    <span>Main Menu</span>
                </li>
                <li class="submenu">
                    <a href="#"><i class="feather-grid"></i> <span> Dashboard</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a href="{{route('admin.dashboard')}}" class="active"><i class="feather-grid"></i> <span>Dashboard</span></a></li>
                    </ul>
                </li>
                <li>
                     <a href="{{route('admin.SubAdmin.index')}}"><i class="fas fa-holly-berry"></i> <span>Sub Admins</span></a>
                </li>
                 <li class="">
                    <a href="{{route('admin.user.index')}}"><i class="fab fa-servicestack"></i> <span>Users</span></a>
                </li>
                 <li class="">
                    <a href="{{route('admin.result.resultlist')}}"><i class="fab fa-servicestack"></i> <span>Market Bid</span></a>
                </li>
                 <li class="">
                    <a href="{{route('admin.bid.bidlist')}}"><i class="fab fa-servicestack"></i> <span>Bid List</span></a>
                </li>
                <li class="">
                    <a href="{{route('admin.matkaresult.index')}}"><i class="fab fa-servicestack"></i> <span>Matka Result</span></a>
                </li>
                <li class="">
                    <a href="{{route('admin.result.index')}}"><i class="fab fa-servicestack"></i> <span>Result</span></a>
                </li>
                <li class="">
                    <a href="{{route('admin.header.edit')}}"><i class="fab fa-servicestack"></i> <span>Header Detail</span></a>
                </li>
                <li class="">
                    <a href="{{route('admin.notice.edit')}}"><i class="fab fa-servicestack"></i> <span>Notice</span></a>
                </li>
                <li class="">
                    <a href="{{route('admin.FastestLiveUpdate.edit')}}"><i class="fab fa-servicestack"></i> <span>Footer Detail</span></a>
                </li>
                <li class="">
                    <a href="{{route('admin.KnowDes.edit')}}"><i class="fab fa-servicestack"></i> <span>Disclatmer Description</span></a>
                </li>
                <li class="">
                    <a href="{{route('admin.SattaMatka.edit')}}"><i class="fab fa-servicestack"></i> <span>Satta Matka Detail</span></a>
                </li>
                <li class="">
                    <a href="{{route('admin.KnowAbout.edit')}}"><i class="fab fa-servicestack"></i> <span>Know About Detail</span></a>
                </li>
                <li class="">
                    <a href="{{route('admin.play.index')}}"><i class="fab fa-servicestack"></i> <span>Play</span></a>
                </li>
                <li class="">
                    <a href="{{route('admin.playlist.index')}}"><i class="fab fa-servicestack"></i> <span>Play Lists</span></a>
                </li>
                <li class="">
                    <a href="{{route('admin.gamerate.index')}}"><i class="fab fa-servicestack"></i> <span>Game Rate</span></a>
                </li>
                <li class="">
                    <a href="{{route('admin.withdrawal.index')}}"><i class="fab fa-servicestack"></i> <span>Withdrawal</span></a>
                </li>
               
               
               
                
               
                
                
            </ul>
        </div>
    </div>
</div>