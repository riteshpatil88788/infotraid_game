<?php

namespace App\Http\Controllers\SubAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\KnowAbout;

class KnowAboutController extends Controller
{
 
    public function edit(){
        $data['KnowAbouts'] = DB::table('know_abouts')->where('id',1)->first();
        $data['title'] = "Know About";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('subadmin.know-about.edit',$data);
    }

    public function update(Request $request)
    {
    //  dd($request->all());
        $request->validate([
        //    'title' => 'required',
            'description' => 'required',
        ]);
        //  echo "<pre>";print_r($request->all());die;
        $abouts = KnowAbout::find($request->id);
        $abouts->description = $request->description;
        $abouts->save();
        // dd($user->toArray());
        session()->flash('success', 'Know About has been Update !!');
        return redirect()->route('subadmin.KnowAbout.edit');
    }



    
}
