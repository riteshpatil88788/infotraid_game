<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\KnowDes;

class KnowDesController extends Controller
{
 
    public function edit(){
        $data['KnowDess'] = DB::table('know_des')->where('id',1)->first();
        $data['title'] = "Disclatmer Description";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('admin.disclatmer.edit',$data);
    }

    public function update(Request $request)
    {
    //  dd($request->all());
        $request->validate([
        //    'title' => 'required',
            'description' => 'required',
        ]);
        // echo "<pre>";print_r($request->all());die;
        $abouts = KnowDes::find($request->id);
        $abouts->description = $request->description;
        $abouts->save();
        // dd($user->toArray());
        session()->flash('success', 'Know Description has been Update !!');
        return redirect()->route('admin.KnowDes.edit');
       
    }



    
}
