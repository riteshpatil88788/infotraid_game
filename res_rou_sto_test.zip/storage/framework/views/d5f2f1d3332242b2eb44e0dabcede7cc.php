 
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content container-fluid">

        <div class="page-header">
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-sub-header">
                        <h3 class="page-title">Welcome </h3>
                       
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-xl-3 col-sm-6 col-12 d-flex">
                <div class="card bg-comman w-100">
               
                <a href="#">
                    <div class="card-body">
                        <div class="db-widgets d-flex justify-content-between align-items-center">
                            <div class="db-info">
                                <h6>Lets Talk</h6>
                                <h3>10</h3>
                            </div>
                            <div class="db-icon">
                                <img src="<?php echo e(url('assets/img/icons/dash-icon-01.svg')); ?>" alt="Dashboard Icon">
                            </div>
                        </div>
                    </div>
                  </a>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 col-12 d-flex">
                <div class="card bg-comman w-100">
                <a href="#">
                    <div class="card-body">
                        <div class="db-widgets d-flex justify-content-between align-items-center">
                            <div class="db-info">
                                <h6>Trial Enquiries</h6>
                                <h3>10</h3>
                            </div>
                            <div class="db-icon">
                                <img src="<?php echo e(url('assets/img/icons/dash-icon-02.svg')); ?>" alt="Dashboard Icon">
                            </div>
                        </div>
                    </div>
                  </a>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 col-12 d-flex">
                <div class="card bg-comman w-100">
                <a href="#">
                    <div class="card-body">
                        <div class="db-widgets d-flex justify-content-between align-items-center">
                            <div class="db-info">
                                <h6>Enquiries</h6>
                                <h3>10</h3>
                            </div>
                            <div class="db-icon">
                                <img src="<?php echo e(url('assets/img/icons/dash-icon-03.svg')); ?>" alt="Dashboard Icon">
                            </div>
                        </div>
                    </div>
                 </a>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 col-12 d-flex">
                <div class="card bg-comman w-100">
                <a href="#">
                    <div class="card-body">
                        <div class="db-widgets d-flex justify-content-between align-items-center">
                            <div class="db-info">
                                <h6>Service Agreement</h6>
                                <h3>10</h3>
                            </div>
                            <div class="db-icon">
                                <img src="<?php echo e(url('assets/img/icons/dash-icon-04.svg')); ?>" alt="Dashboard Icon">
                            </div>
                        </div>
                    </div>
                    </a>
                </div>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('subadmin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/subadmin/dashboard.blade.php ENDPATH**/ ?>