<?php $__env->startSection('content'); ?>
<div class="page-wrapper" style="min-height: 366px;">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-xl-12">

                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Edit <?php echo e($title); ?></h3>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="bank-inner-details">
                            <div class="row">
                            <?php if(session('success')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>

                                <div class="col-lg-12 col-md-12">
                                    <form id="formSubmit" action="<?php echo e(route('admin.notice.update')); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                     <input type="hidden"  name="id" value="<?php echo e(@$notices->id); ?>" />
                                     <div class="row">
                                          <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Description<span class="text-danger">*</span></label>
                                                 <textarea type="text" name="description" class="form-control tinymce" id="editor1" ><?php echo e(@$notices->description); ?></textarea>
                                              </div>
                                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                  <p style="color:red;"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>
                                        <div class="bank-details-btn ">
                                            <button type="submit" class="btn bank-cancel-btn me-2">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/admin/notice/edit.blade.php ENDPATH**/ ?>