<?php

use App\Http\Controllers\SubAdmin\{SubAdminController,ServiceController,AboutController,QRcodeController,MatkaResultController,GuessingFormController,HeaderController,PlayController,NoticeController,FastestLiveUpdateController, KnowDesController,KnowAboutController,SattaMatkaController,PlayListController,GameRateController};
use App\Http\Controllers\{HomeController};
use Illuminate\Support\Facades\Route;

// Front 


Route::get('/cache', function () {
    // Clearing caches
    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('route:clear');
    Artisan::call('view:clear');

    return 'Caches cleared successfully.';
});

Route::fallback(function() {
  return response()->view('error', [], 404);
});


Route::get('subadmin/login',[SubAdminController::class,'login'])->name('login.form');
Route::post('subadmin/login-functionality',[SubAdminController::class,'login_functionality'])->name('login.functionality');

Route::group(['middleware'=>'subadmin', 'prefix' => 'subadmin', 'as' => 'subadmin.' ],function(){
        Route::get('/logout',[SubAdminController::class,'logout'])->name('logout');
        Route::get('/dashboard',[SubAdminController::class,'dashboard'])->name('dashboard');

        // about
        Route::get('/about-edit',[AboutController::class,'edit'])->name('about.edit');
        Route::post('/about-update',[AboutController::class,'update'])->name('about.update');

      // MatkaResult
      Route::get('/matka-result',[MatkaResultController::class,'index'])->name('matkaresult.index'); 
      Route::get('/matka-result-crerate',[MatkaResultController::class,'create'])->name('matkaresult.create'); 
      Route::post('/matka-result-store',[MatkaResultController::class,'store'])->name('matkaresult.store');
      Route::post('/matka-result-update',[MatkaResultController::class,'update'])->name('matkaresult.update');
      Route::get('/matka-result-edit/{id}',[MatkaResultController::class,'edit'])->name('matkaresult.edit');
      Route::get('/matka-result-destroy/{id}',[MatkaResultController::class,'destroy'])->name('matkaresult.destroy');

      // GuessingForm
      Route::get('/guessing-form',[GuessingFormController::class,'index'])->name('GuessingForm.index'); 
      Route::get('/guessing-form-crerate',[GuessingFormController::class,'create'])->name('GuessingForm.create'); 
      Route::post('/guessing-form-store',[GuessingFormController::class,'store'])->name('GuessingForm.store');
      Route::post('/guessing-form-update',[GuessingFormController::class,'update'])->name('GuessingForm.update');
      Route::get('/guessing-form-edit/{id}',[GuessingFormController::class,'edit'])->name('GuessingForm.edit');
      Route::get('/guessing-form-destroy/{id}',[GuessingFormController::class,'destroy'])->name('GuessingForm.destroy');

    
      // Header
      Route::get('/header-edit',[HeaderController::class,'edit'])->name('header.edit');
      Route::post('/header-update',[HeaderController::class,'update'])->name('header.update');
     
      // notice
      Route::get('/notice-edit',[NoticeController::class,'edit'])->name('notice.edit');
      Route::post('/notice-update',[NoticeController::class,'update'])->name('notice.update');
    
      // FastestLiveUpdate
      Route::get('/fastest-live-updates-edit',[FastestLiveUpdateController::class,'edit'])->name('FastestLiveUpdate.edit');
      Route::post('/fastest-live-updates-update',[FastestLiveUpdateController::class,'update'])->name('FastestLiveUpdate.update');
     
      // KnowDes
      Route::get('/know-updates-edit',[KnowDesController::class,'edit'])->name('KnowDes.edit');
      Route::post('/know-updates-update',[KnowDesController::class,'update'])->name('KnowDes.update');
      
      // SattaMatka
      Route::get('/satta-matka-edit',[SattaMatkaController::class,'edit'])->name('SattaMatka.edit');
      Route::post('/satta-matka-update',[SattaMatkaController::class,'update'])->name('SattaMatka.update');
     
      // KnowDes
      Route::get('/know-about-edit',[KnowAboutController::class,'edit'])->name('KnowAbout.edit');
      Route::post('/know-about-update',[KnowAboutController::class,'update'])->name('KnowAbout.update');

     
      Route::get('/play-list', [PlayListController::class, 'index'])->name('playlist.index');
      Route::get('/play-list-crerate',[PlayListController::class,'create'])->name('playlist.create'); 
      Route::post('/play-list-store',[PlayListController::class,'store'])->name('playlist.store');
      Route::post('/play-list-update',[PlayListController::class,'update'])->name('playlist.update');
      Route::get('/play-list-edit/{id}',[PlayListController::class,'edit'])->name('playlist.edit');
      Route::get('/play-list-destroy/{id}',[PlayListController::class,'destroy'])->name('playlist.destroy');


      Route::get('/play', [PlayController::class, 'index'])->name('play.index');
      Route::get('/play-crerate',[PlayController::class,'create'])->name('play.create'); 
      Route::post('/play-store',[PlayController::class,'store'])->name('play.store');
      Route::post('/play-update',[PlayController::class,'update'])->name('play.update');
      Route::get('/play-edit/{id}',[PlayController::class,'edit'])->name('play.edit');
      Route::get('/play-destroy/{id}',[PlayController::class,'destroy'])->name('play.destroy');

      Route::get('/game-rate', [GameRateController::class, 'index'])->name('gamerate.index');
      Route::get('/game-rate-crerate',[GameRateController::class,'create'])->name('gamerate.create'); 
      Route::post('/game-rate-store',[GameRateController::class,'store'])->name('gamerate.store');
      Route::post('/game-rate-update',[GameRateController::class,'update'])->name('gamerate.update');
      Route::get('/game-rate-edit/{id}',[GameRateController::class,'edit'])->name('gamerate.edit');
      Route::get('/game-rate-destroy/{id}',[GameRateController::class,'destroy'])->name('gamerate.destroy');
});




