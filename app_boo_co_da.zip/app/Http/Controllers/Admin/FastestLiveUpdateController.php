<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\FastestLiveUpdate;

class FastestLiveUpdateController extends Controller
{
 
    public function edit(){
        $data['FastestLiveUpdates'] = DB::table('fastest_live_updates')->where('id',1)->first();
        $data['title'] = "Footer Description";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('admin.footer.edit',$data);
    }

    public function update(Request $request)
    {
    //  dd($request->all());
        $request->validate([
        //    'title' => 'required',
            'description' => 'required',
        ]);
        // echo "<pre>";print_r($request->all());die;
        $abouts = FastestLiveUpdate::find($request->id);
        $abouts->description = $request->description;
        $abouts->save();
        // dd($user->toArray());
        session()->flash('success', 'Fastest Live Update Description has been Update !!');
        return redirect()->route('admin.FastestLiveUpdate.edit');
       
    }



    
}
