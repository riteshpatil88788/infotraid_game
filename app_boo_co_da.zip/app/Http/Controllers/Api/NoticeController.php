<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Notice;
use Illuminate\Support\Facades\Auth;

class NoticeController extends Controller
{
    public function index(){
        
        $data['title'] = "Notices";
        $data['notices'] = DB::table('notices')->where('id',1)->first();
       
        if (!$data['notices']) {
            return response()->json(['status' => false,  'data' => [], 'message' => 'Record not found']);
        }
    return response()->json(['status' => true, 'data' => $data, 'message' => 'Record Successfully']);
    }

 



    
}
