<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GamePointAmuntBid extends Model
{
    use HasFactory;

    protected $table = "game_point_amunt_bids";



    protected $fillable = [
        
       'user_id',
        'type_id',
        'play_type',
        'digit',
        'points',
        'oc_type',
        'total_bid',
        'total_points',
        
       
       

    ];
}
