<?php

namespace App\Http\Controllers\SubAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\MatkaResult;

class MatkaResultController extends Controller
{
 
    public function index()
    {
    //    echo "<pre>";print_r(Auth::guard('subadmin')->check());die;
       
            $data['matkaresults'] = DB::table('matka_results')->where('subadmin_id',Auth::guard('subadmin')->user()->id)->orderBy('id','desc')->get();
       
        $data['title'] = "Matka Result";
        return view('subadmin.matka-result.index',$data);
    }

    public function create(){
        $data['title'] = "Matka Result";
        return view('subadmin.matka-result.create',$data);
    }

    public function store(Request $request){
      //  echo "<pre>";print_r($request->all());die;
        $request->validate([
            'title' => 'required',
            'patta_value' => 'required|numeric|digits:3',
            'firsttime' => 'required',
            'lasttime' => 'required',
           
        ]);
       //  echo "<pre>";print_r($request->all());die;
        $MatkaResult = new MatkaResult;
        $MatkaResult->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $MatkaResult->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;
        
        $MatkaResult->title = $request->title;
        $MatkaResult->patta_value = $request->patta_value;
        $MatkaResult->firsttime = $request->firsttime;
        $MatkaResult->lasttime = $request->lasttime;
        $MatkaResult->jodi_url = $request->jodi_url;
        $MatkaResult->panel_url = $request->panel_url;
        $MatkaResult->save();
        session()->flash('success', 'Matka Result has been created !!');
        return redirect()->route('subadmin.matkaresult.index');
    }

    public function edit($id){
        $data['matkaresult'] = DB::table('matka_results')->where('id',$id)->first();
        $data['title'] = "Matka Result";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('subadmin.matka-result.edit',$data);
    }

    public function update(Request $request)
    {
        //  dd($request->all());
        $request->validate([
            'title' => 'required',
            'patta_value' => 'required|numeric|digits:3',
            'firsttime' => 'required',
            'lasttime' => 'required',
           
        ]);
        //  echo "<pre>";print_r($request->all());die;
        $MatkaResult = MatkaResult::find($request->id);
        $MatkaResult->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $MatkaResult->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;       
        $MatkaResult->title = $request->title;
        $MatkaResult->patta_value = $request->patta_value;
        $MatkaResult->firsttime = $request->firsttime;
        $MatkaResult->lasttime = $request->lasttime;
        $MatkaResult->jodi_url = $request->jodi_url;
        $MatkaResult->panel_url = $request->panel_url;
        $MatkaResult->save();
        // dd($user->toArray());
        session()->flash('success', 'Matka Result has been Update !!');
        return redirect()->route('subadmin.matkaresult.index');
    }

    public function destroy($id){
       
       
        $MatkaResult = MatkaResult::find($id);
        $MatkaResult->delete();
        session()->flash('success', 'Matka Result has been Deleted !!');
        return redirect()->route('subadmin.matkaresult.index');
    }

    
}
