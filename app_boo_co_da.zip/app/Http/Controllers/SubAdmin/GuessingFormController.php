<?php

namespace App\Http\Controllers\SubAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\GuessingForm;

class GuessingFormController extends Controller
{
 
    public function index()
    {
    //    echo "<pre>";print_r(Auth::guard('subadmin')->check());die;
       
            $data['GuessingForms'] = DB::table('guessing_forms')->where('subadmin_id',Auth::guard('subadmin')->user()->id)->orderBy('id','desc')->get();
       
        $data['title'] = "Guessing Form";
        return view('subadmin.guessing-form.index',$data);
    }

    public function create(){
        $data['title'] = "Guessing Form";
        return view('subadmin.guessing-form.create',$data);
    }

    public function store(Request $request){
      //  echo "<pre>";print_r($request->all());die;
        $request->validate([
            'title' => 'required',
            'patta_value' => 'required|numeric|digits:3',
           
           
        ]);
       //  echo "<pre>";print_r($request->all());die;
        $GuessingForm = new GuessingForm;
        $GuessingForm->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $GuessingForm->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;
        
        $GuessingForm->title = $request->title;
        $GuessingForm->patta_value = $request->patta_value;
        $GuessingForm->save();
        session()->flash('success', 'Guessing Form has been created !!');
        return redirect()->route('subadmin.GuessingForm.index');
    }

    public function edit($id){
        $data['GuessingForms'] = DB::table('guessing_forms')->where('id',$id)->first();
        $data['title'] = "Guessing Form";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('subadmin.guessing-form.edit',$data);
    }

    public function update(Request $request)
    {
        //  dd($request->all());
        $request->validate([
            'title' => 'required',
            'patta_value' => 'required|numeric|digits:3',
           
           
        ]);
        //  echo "<pre>";print_r($request->all());die;
        $GuessingForm = GuessingForm::find($request->id);
        $GuessingForm->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $GuessingForm->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;       
        $GuessingForm->title = $request->title;
        $GuessingForm->patta_value = $request->patta_value;
        $GuessingForm->save();
        // dd($user->toArray());
        session()->flash('success', 'Guessing Form has been Update !!');
        return redirect()->route('subadmin.GuessingForm.index');
    }

    public function destroy($id){
       
       
        $GuessingForm = GuessingForm::find($id);
        $GuessingForm->delete();
        session()->flash('success', 'Guessing Form has been Deleted !!');
        return redirect()->route('subadmin.GuessingForm.index');
    }

    
}
