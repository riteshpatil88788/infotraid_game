@extends('admin.layout.app') @section('content')
<div class="page-wrapper">
    <div class="content container-fluid">



        <div class="row">
            <div class="col-sm-12">
                <div class="card card-table">
                    <div class="card-body">

                        <div class="page-header">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="page-title">{{$title}}</h3>
                                </div>
                                <div class="col-auto text-end float-end ms-auto download-grp">
                                    <a href="{{ route('admin.gamerate.create') }}" class="btn btn-primary"><i class="fas fa-plus"></i></a>
                                </div>
                            </div>
                        </div>
                        @if (session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                @endif
                        <div class="table-responsive">
                            <table class="table border-0 star-student table-hover table-center mb-0 datatable table-striped">
                                <thead class="student-thread">
                                    <tr>
                                        <th>S.No</th>
                                        <th>Name</th>
                                        <th>Amount</th>
                                        <th>Withdrawal Status</th>
                                        <th class="text-end">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1;?>
                                    @foreach($withdrawal as $withdra)
                                    @php
                                    $user = App\Models\User::where('id',$withdra->user_id)->first();
                                    @endphp
                                    <tr>
                                        <td>{{$i}}</td>
                                        <td>{{ $user->name }}</td>
                                        <td>{{ $withdra->amount }}</td>
                                         <td>
                                          
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-light dropdown-toggle" type="button" id="withdrawalStatusDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                                    @if($withdra->withdrawal_status == 0)
                                                        Request
                                                    @elseif($withdra->withdrawal_status == 1)
                                                        Accepted
                                                    @elseif($withdra->withdrawal_status == 2)
                                                        Reject
                                                    @endif
                                                </button>
                                                <ul class="dropdown-menu" aria-labelledby="withdrawalStatusDropdown">
                                                    <li>
                                                        <a class="dropdown-item" href="javascript:void(0)" onclick="WithdrawalStatus({{ $withdra->id }}, 0)">
                                                            Request
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item" href="javascript:void(0)" onclick="WithdrawalStatus({{ $withdra->id }}, 1)">
                                                            Accepted
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item" href="javascript:void(0)" onclick="WithdrawalStatus({{ $withdra->id }}, 2)">
                                                            Reject
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>

                                        </td>
                                        <td class="text-end">
                                            <div class="actions">
                                                <a href="{{ route('admin.withdrawal.destroy', $withdra->id) }}" class="btn btn-sm bg-success-light me-2" onclick="return confirm('Do you really want to Delete?')">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php $i++;?>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

@endsection
@section('script')
  <script>
function WithdrawalStatus(withdrawalId, status) {
    $.ajax({
        url: '{{route('admin.withdrawal-status')}}',
        type: 'POST',
        data: {
            _token: '{{ csrf_token() }}', // Laravel CSRF token for security
            id: withdrawalId,
            status: status
        },
        success: function(response) {
            if (response.success) {
                alert(response.message);
                location.reload(); // Reload the page to reflect the updated status
            } else {
                alert('Error: ' + response.message);
            }
        },
        error: function(xhr) {
            alert('An error occurred: ' + xhr.responseText);
        }
    });
}
  </script>
@endsection