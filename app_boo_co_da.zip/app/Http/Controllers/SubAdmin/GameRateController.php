<?php

namespace App\Http\Controllers\SubAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\GameRate;

class GameRateController extends Controller
{
 
    public function index()
    {
        $data['gamerates'] = DB::table('game_rates')->orderBy('id','desc')->get();
        $data['title'] = "Game Rate";
        return view('subadmin.game-rate.index',$data);
    }

    public function create(){
        $data['title'] = "Game Rate";
        return view('subadmin.game-rate.create',$data);
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
                 
        ]);
    
        $GameRate = new GameRate;
    
        $GameRate->title = $request->title;
        $GameRate->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $GameRate->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;
        $GameRate->save();
    
        session()->flash('success', 'Game Rate has been created !!');
        return redirect()->route('subadmin.gamerate.index');
    }
    

    public function edit($id){
        $data['GameRate'] = DB::table('game_rates')->where('id',$id)->first();
        $data['title'] = "Game Rate";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('subadmin.game-rate.edit',$data);
    }

    public function update(Request $request)
    {
        //  dd($request->all());
        $request->validate([
            'title' => 'required',
           
        ]);
        //  echo "<pre>";print_r($request->all());die;
        $GameRate = GameRate::find($request->id);
        $GameRate->title = $request->title;
        $GameRate->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $GameRate->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;
        $GameRate->save();
        // dd($user->toArray());
        session()->flash('success', 'Game Rate has been Update !!');
        return redirect()->route('subadmin.gamerate.index');
    }

    public function destroy($id){
       
       
        $GameRate = GameRate::find($id);
     
        $GameRate->delete();
        session()->flash('success', 'Game Rates has been Deleted !!');
        return redirect()->route('subadmin.gamerate.index');
    }

    
}
