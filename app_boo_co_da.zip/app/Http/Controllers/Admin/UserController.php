<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\User;

class UserController extends Controller
{
 
    public function index(){
        // echo 12;die;
        $data['users'] = DB::table('users')->get();
        $data['title'] = "User";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('admin.user',$data);
    }

    public function status(Request $request){
       // echo "<pre>";print_r($request->all());die;
        if($request->id){
            $SubAdmin = User::find($request->id);
            $SubAdmin->experts = $request->status;
            $SubAdmin->save();
        }
        return response()->json(['status' => 'Sxperts Active successfully']);
    }
    
}
