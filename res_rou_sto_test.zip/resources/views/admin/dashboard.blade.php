@extends('admin.layout.app') 
@section('content')
<div class="page-wrapper">
    <div class="content container-fluid">

        <div class="page-header">
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-sub-header">
                        <h3 class="page-title">Welcome </h3>
                       
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-xl-3 col-sm-6 col-12 d-flex">
                <div class="card bg-comman w-100">
               
                <a href="#">
                    <div class="card-body">
                        <div class="db-widgets d-flex justify-content-between align-items-center">
                            <div class="db-info">
                                <h6>Bids</h6>
                                <h3>@php echo DB::table('bid_history')->where('status',0)->count(); @endphp</h3>
                            </div>
                            <div class="db-icon">
                                <img src="{{url('assets/img/icons/dash-icon-01.svg')}}" alt="Dashboard Icon">
                            </div>
                        </div>
                    </div>
                  </a>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 col-12 d-flex">
                <div class="card bg-comman w-100">
                <a href="#">
                    <div class="card-body">
                        <div class="db-widgets d-flex justify-content-between align-items-center">
                            <div class="db-info">
                                <h6>Winners</h6>
                                <h3>@php echo DB::table('bid_history')->where('status',1)->count(); @endphp</h3>
                            </div>
                            <div class="db-icon">
                                <img src="{{url('assets/img/icons/dash-icon-02.svg')}}" alt="Dashboard Icon">
                            </div>
                        </div>
                    </div>
                  </a>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 col-12 d-flex">
                <div class="card bg-comman w-100">
                <a href="#">
                    <div class="card-body">
                        <div class="db-widgets d-flex justify-content-between align-items-center">
                            <div class="db-info">
                                <h6>Lose</h6>
                                <h3>@php echo DB::table('bid_history')->where('status',2)->count(); @endphp</h3>
                            </div>
                            <div class="db-icon">
                                <img src="{{url('assets/img/icons/dash-icon-03.svg')}}" alt="Dashboard Icon">
                            </div>
                        </div>
                    </div>
                 </a>
                </div>
            </div>
          
            
        </div>
    </div>
</div>
@endsection