 <?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content container-fluid">



        <div class="row">
            <div class="col-sm-12">
                <div class="card card-table">
                    <div class="card-body">

                        <div class="page-header">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="page-title"><?php echo e($title); ?></h3>
                                </div>
                                <div class="col-auto text-end float-end ms-auto download-grp">
                                    <a href="<?php echo e(route('subadmin.GuessingForm.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i></a>
                                </div>
                            </div>
                        </div>
                        <?php if(session('success')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table border-0 star-student table-hover table-center mb-0 datatable table-striped">
                                <thead class="student-thread">
                                    <tr>
                                        <th>S.No</th>
                                        <th>Title</th>
                                        <th>Patta</th>
                                        <th class="text-end">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1;?>
                                    <?php $__currentLoopData = $GuessingForms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GuessingForm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($GuessingForm->title); ?></td>
                                        <td><?php echo e($GuessingForm->patta_value); ?></td>
                                       
                                        <td class="text-end">
                                            <div class="actions">
                                                <a href="<?php echo e(route('subadmin.GuessingForm.edit', $GuessingForm->id)); ?>" class="btn btn-sm bg-danger-light">
                                                    <i class="feather-edit"></i>
                                                </a>
                                                <a href="<?php echo e(route('subadmin.GuessingForm.destroy', $GuessingForm->id)); ?>" class="btn btn-sm bg-success-light me-2" onclick="return confirm('Do you really want to Delete?')">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            
                                            </div>
                                        </td>
                                    </tr>
                                    <?php $i++;?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('subadmin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/subadmin/guessing-form/index.blade.php ENDPATH**/ ?>