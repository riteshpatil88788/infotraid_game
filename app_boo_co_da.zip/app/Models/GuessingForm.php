<?php



namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

use Illuminate\Database\Eloquent\Model;



class GuessingForm extends Model{

    use HasFactory;

    protected $table = "guessing_forms";



    protected $fillable = [

        'admin_id',
        'subadmin_id',
        'title',
        'patta_value',

    ];





    



}