<?php

use App\Http\Controllers\Admin\{AdminController,MatkaResultController,ResultController,HeaderController,PlayController,SubAdminController,NoticeController,FastestLiveUpdateController, KnowDesController,KnowAboutController,SattaMatkaController,PlayListController,GameRateController,UserController};
use App\Http\Controllers\{HomeController};
use App\Http\Controllers\Auth\{LoginController,RegisterController};
use Illuminate\Support\Facades\Route;

// Front 


Route::get('/cache', function () {
    // Clearing caches
    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('route:clear');
    Artisan::call('view:clear');

    return 'Caches cleared successfully.';
});

Route::fallback(function() {
  return response()->view('error', [], 404);
});

Route::get('/',[HomeController::class,'index'])->name('home.index');

Route::get('/login',[LoginController::class,'login'])->name('home.login');
Route::post('/login-store',[LoginController::class,'loginfunction'])->name('home.loginstore');
Route::get('/register',[RegisterController::class,'register'])->name('home.register');
Route::post('/register-store',[RegisterController::class,'registerstore'])->name('home.registerstore');
Route::get('/logout',[LoginController::class,'logout'])->name('home.logout');


Route::get('/jodi/{any}',[HomeController::class,'jodi'])->name('home.jodi');
Route::get('/panel/{any}',[HomeController::class,'panel'])->name('home.panel');
Route::post('/show-guessing-message/',[HomeController::class,'ShowAlert'])->name('home.ShowAlert');
Route::post('/show-expert-message/',[HomeController::class,'ExpertShowAlert'])->name('home.ExpertShowAlert');
Route::get('/result-guessing-forum',[HomeController::class,'ResultGuessing'])->name('home.ResultGuessing');
Route::post('/gussing-store/',[HomeController::class,'gussingstore'])->name('home.guessingstore');
Route::post('/exports-store/',[HomeController::class,'exportsstore'])->name('home.exportsstore');
Route::get('/exports-form/',[HomeController::class,'expertGuessing'])->name('home.expertGuessing');
Route::get('/profile/{id}',[HomeController::class,'profile'])->name('home.profile');
// admin
Route::get('admin/login',[AdminController::class,'login'])->name('login.Adminform');
Route::post('admin/login-functionality',[AdminController::class,'Adminlogin_functionality'])->name('login.Adminlogin_functionality');


Route::group(['middleware'=>'admin','prefix' => 'admin', 'as' => 'admin.'],function(){

      Route::get('/logout',[AdminController::class,'Adminlogout'])->name('Adminlogout');
      Route::get('/dashboard',[AdminController::class,'dashboard'])->name('dashboard');
      Route::get('/withdrawal',[AdminController::class,'withdrawal'])->name('withdrawal.index');
      Route::post('/withdrawal/update-status', [AdminController::class, 'updateStatus'])->name('withdrawal-status');
      Route::post('/withdrawal/destroy/{id}', [AdminController::class, 'Withdrawaldestroy'])->name('withdrawal.destroy');

      // service
      Route::get('admin/service',[ServiceController::class,'index'])->name('service.index'); 
      Route::get('admin/service-crerate',[ServiceController::class,'create'])->name('service.create'); 
      Route::post('admin/service-store',[ServiceController::class,'store'])->name('service.store');
      Route::post('admin/service-update',[ServiceController::class,'update'])->name('service.update');
      Route::get('admin/service-edit/{id}',[ServiceController::class,'edit'])->name('service.edit');
      Route::get('admin/service-destroy/{id}',[ServiceController::class,'destroy'])->name('service.destroy');
      Route::post('admin/service-category',[ServiceController::class,'selectCategory'])->name('service.selectcategoty');
      Route::post('admin/service-status',[ServiceController::class,'serviceStatus'])->name('service.status');

      // about
      Route::get('admin/about-edit',[AboutController::class,'edit'])->name('about.edit');
      Route::post('admin/about-update',[AboutController::class,'update'])->name('about.update');
    
      // Header
      Route::get('admin/header-edit',[HeaderController::class,'edit'])->name('header.edit');
      Route::post('admin/header-update',[HeaderController::class,'update'])->name('header.update');
     
      // notice
      Route::get('admin/notice-edit',[NoticeController::class,'edit'])->name('notice.edit');
      Route::post('admin/notice-update',[NoticeController::class,'update'])->name('notice.update');
    
      // FastestLiveUpdate
      Route::get('admin/fastest-live-updates-edit',[FastestLiveUpdateController::class,'edit'])->name('FastestLiveUpdate.edit');
      Route::post('admin/fastest-live-updates-update',[FastestLiveUpdateController::class,'update'])->name('FastestLiveUpdate.update');
     
      // KnowDes
      Route::get('admin/know-updates-edit',[KnowDesController::class,'edit'])->name('KnowDes.edit');
      Route::post('admin/know-updates-update',[KnowDesController::class,'update'])->name('KnowDes.update');
      
      // SattaMatka
      Route::get('admin/satta-matka-edit',[SattaMatkaController::class,'edit'])->name('SattaMatka.edit');
      Route::post('admin/satta-matka-update',[SattaMatkaController::class,'update'])->name('SattaMatka.update');
     
      // KnowDes
      Route::get('admin/know-about-edit',[KnowAboutController::class,'edit'])->name('KnowAbout.edit');
      Route::post('admin/know-about-update',[KnowAboutController::class,'update'])->name('KnowAbout.update');
 
      // MatkaResult
      Route::get('/matka-result',[MatkaResultController::class,'index'])->name('matkaresult.index'); 
      Route::get('/matka-result-crerate',[MatkaResultController::class,'create'])->name('matkaresult.create'); 
      Route::post('/matka-result-store',[MatkaResultController::class,'store'])->name('matkaresult.store');
      Route::post('/matka-result-update',[MatkaResultController::class,'update'])->name('matkaresult.update');
      Route::get('/matka-result-edit/{id}',[MatkaResultController::class,'edit'])->name('matkaresult.edit');
      Route::get('/matka-result-destroy/{id}',[MatkaResultController::class,'destroy'])->name('matkaresult.destroy');
      
      // MatkaResult
      Route::get('/result',[ResultController::class,'index'])->name('result.index'); 
      Route::get('/result-crerate',[ResultController::class,'create'])->name('result.create'); 
      Route::post('/result-store',[ResultController::class,'store'])->name('result.store');
      Route::post('/result-update',[ResultController::class,'update'])->name('result.update');
      Route::get('/result-edit/{id}',[ResultController::class,'edit'])->name('result.edit');
      Route::get('/result-destroy/{id}',[ResultController::class,'destroy'])->name('result.destroy');

      Route::get('/sub-admin',[SubAdminController::class,'index'])->name('SubAdmin.index');
      Route::post('/sub-admin',[SubAdminController::class,'status'])->name('SubAdmin.status');
      
      Route::get('/user',[UserController::class,'index'])->name('user.index');
      Route::post('/user',[UserController::class,'status'])->name('user.status');
      
      Route::get('/result-list',[PlayListController::class,'resultlist'])->name('result.resultlist');
      Route::get('/bid-list',[PlayListController::class,'bidlist'])->name('bid.bidlist');
      Route::post('/bid-list',[PlayListController::class,'bidlist'])->name('bid.bidlist');
  


     
      Route::get('/play-list', [PlayListController::class, 'index'])->name('playlist.index');
      Route::get('/play-list-crerate',[PlayListController::class,'create'])->name('playlist.create'); 
      Route::post('/play-list-store',[PlayListController::class,'store'])->name('playlist.store');
      Route::post('/play-list-update',[PlayListController::class,'update'])->name('playlist.update');
      Route::get('/play-list-edit/{id}',[PlayListController::class,'edit'])->name('playlist.edit');
      Route::get('/play-list-destroy/{id}',[PlayListController::class,'destroy'])->name('playlist.destroy');


      Route::get('/play', [PlayController::class, 'index'])->name('play.index');
      Route::get('/play-crerate',[PlayController::class,'create'])->name('play.create'); 
      Route::post('/play-store',[PlayController::class,'store'])->name('play.store');
      Route::post('/play-update',[PlayController::class,'update'])->name('play.update');
      Route::get('/play-edit/{id}',[PlayController::class,'edit'])->name('play.edit');
      Route::get('/play-destroy/{id}',[PlayController::class,'destroy'])->name('play.destroy');

      Route::get('/game-rate', [GameRateController::class, 'index'])->name('gamerate.index');
      Route::get('/game-rate-crerate',[GameRateController::class,'create'])->name('gamerate.create'); 
      Route::post('/game-rate-store',[GameRateController::class,'store'])->name('gamerate.store');
      Route::post('/game-rate-update',[GameRateController::class,'update'])->name('gamerate.update');
      Route::get('/game-rate-edit/{id}',[GameRateController::class,'edit'])->name('gamerate.edit');
      Route::get('/game-rate-destroy/{id}',[GameRateController::class,'destroy'])->name('gamerate.destroy');


});





