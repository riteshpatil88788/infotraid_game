<?php



namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

use Illuminate\Database\Eloquent\Model;



class MatkaResult extends Model{

    use HasFactory;

    protected $table = "matka_results";



    protected $fillable = [

        'admin_id',
        'subadmin_id',
        'title',
        'patta_value',
        'patta_value2',
        'jodi_value',
        'firsttime',
        'lasttime',
        'jodi_url',
        'panel_url',

    ];





    



}