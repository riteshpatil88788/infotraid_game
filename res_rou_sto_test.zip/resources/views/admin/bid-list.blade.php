@extends('admin.layout.app')
@section('content')
<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card card-table">
                    <div class="card-body">
                        
                        <!-- Filter Form -->
                        <div class="page-header">
                            <form method="POST" action="{{ route('admin.bid.bidlist') }}" class="row g-3">
                                @csrf
                                <div class="col-md-4">
                                    <label for="name" class="form-label">User Name</label>
                                    <input type="text" name="name" id="name" class="form-control" 
                                           value="{{ old('name') }}" placeholder="Enter user name">
                                </div>
                                <div class="col-md-4">
                                    <label for="title" class="form-label">Matka Title</label>
                                    <input type="text" name="title" id="title" class="form-control" 
                                           value="{{ old('title') }}" placeholder="Enter matka title">
                                </div>
                                <div class="col-md-4">
                                    <label for="play" class="form-label">Game Name</label>
                                    <input type="text" name="play" id="play" class="form-control" 
                                           value="{{ old('play') }}" placeholder="Enter Game title">
                                </div>
                                <div class="col-md-12 mt-3">
                                    <button type="submit" class="btn btn-primary">Filter</button>
                                    <a href="{{ route('admin.bid.bidlist') }}" class="btn btn-secondary">Clear</a>
                                </div>
                            </form>
                        </div>

                        <!-- Success Message -->
                        @if (session('success'))
                        <div class="alert alert-success mt-3">
                            {{ session('success') }}
                        </div>
                        @endif

                        <!-- Data Table -->
                        <div class="table-responsive mt-4">
                            <table class="table border-0 star-student table-hover table-center mb-0 datatable table-striped">
                                <thead class="student-thread">
                                    <tr>
                                        <th>S.No</th>
                                        <th>User Name</th>
                                        <th>Title</th>
                                        <th>Game Name</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if($bid_history->isNotEmpty())
                                        @foreach($bid_history as $key => $bid_his)
                                        <tr>
                                            <td>{{ $key + 1 }}</td>
                                            <td>{{ $bid_his->name }}</td>
                                            <td>{{ $bid_his->m_title }}</td>
                                            <td>{{ $bid_his->p_title }}</td>
                                            <td>{{ $bid_his->total_bid_amount }}</td>
                                        </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="5" class="text-center">No data found for the selected filters.</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

