<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KnowAbout extends Model{
    use HasFactory;
    protected $table = "know_abouts";

    protected $fillable = [
        'description',
    ];


    

}