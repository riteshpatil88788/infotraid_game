
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card card-table">
                    <div class="card-body">
                        
                        <!-- Filter Form -->
                        <div class="page-header">
                            <form method="POST" action="<?php echo e(route('admin.bid.bidlist')); ?>" class="row g-3">
                                <?php echo csrf_field(); ?>
                                <div class="col-md-4">
                                    <label for="name" class="form-label">User Name</label>
                                    <input type="text" name="name" id="name" class="form-control" 
                                           value="<?php echo e(old('name')); ?>" placeholder="Enter user name">
                                </div>
                                <div class="col-md-4">
                                    <label for="title" class="form-label">Matka Title</label>
                                    <input type="text" name="title" id="title" class="form-control" 
                                           value="<?php echo e(old('title')); ?>" placeholder="Enter matka title">
                                </div>
                                <div class="col-md-4">
                                    <label for="play" class="form-label">Game Name</label>
                                    <input type="text" name="play" id="play" class="form-control" 
                                           value="<?php echo e(old('play')); ?>" placeholder="Enter Game title">
                                </div>
                                <div class="col-md-12 mt-3">
                                    <button type="submit" class="btn btn-primary">Filter</button>
                                    <a href="<?php echo e(route('admin.bid.bidlist')); ?>" class="btn btn-secondary">Clear</a>
                                </div>
                            </form>
                        </div>

                        <!-- Success Message -->
                        <?php if(session('success')): ?>
                        <div class="alert alert-success mt-3">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>

                        <!-- Data Table -->
                        <div class="table-responsive mt-4">
                            <table class="table border-0 star-student table-hover table-center mb-0 datatable table-striped">
                                <thead class="student-thread">
                                    <tr>
                                        <th>S.No</th>
                                        <th>User Name</th>
                                        <th>Title</th>
                                        <th>Game Name</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($bid_history->isNotEmpty()): ?>
                                        <?php $__currentLoopData = $bid_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bid_his): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($bid_his->name); ?></td>
                                            <td><?php echo e($bid_his->m_title); ?></td>
                                            <td><?php echo e($bid_his->p_title); ?></td>
                                            <td><?php echo e($bid_his->amount); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center">No data found for the selected filters.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $('.statusCheck').change(function() {
            var id = $(this).data('id');
            var status = $(this).prop('checked') ? 1 : 0;
            var confirmationMessage = status == 1 
                ? 'Are you sure you want to activate?' 
                : 'Are you sure you want to deactivate?';
                
            if (confirm(confirmationMessage)) {
                $.ajax({
                    url: '<?php echo e(route("admin.user.status")); ?>',
                    method: 'POST',
                    data: {
                        id: id,
                        status: status,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        alert('Status updated successfully.');
                    },
                    error: function(xhr) {
                        console.error('Error updating status.');
                    }
                });
            } else {
                $(this).prop('checked', !status);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/admin/big-list.blade.php ENDPATH**/ ?>