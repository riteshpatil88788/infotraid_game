@extends('admin.layout.app')
@section('content')
<div class="page-wrapper" style="min-height: 366px;">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-xl-12">

                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Edit {{$title}}</h3>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="bank-inner-details">
                            <div class="row">
                           
                                <div class="col-lg-12 col-md-12">
                                    <form id="formSubmit" action="{{ route('admin.matkaresult.update')}}" method="post" enctype="multipart/form-data">
                                        @csrf
                                     <input type="hidden"  name="id" value="{{$matkaresult->id}}" />
                                     <div class="row">
                                          <div class="col-lg-12 col-md-12">
                                              <div class="form-group ">
                                                 <label>Title<span class="text-danger">*</span></label>
                                                 <input type="text" name="title" class="form-control" id="title" value="{{ $matkaresult->title }}">
                                              </div>
                                                @error('title')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                          <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Open Time<span class="text-danger">*</span></label>
                                                 <input type="time" name="firsttime" class="form-control" id="firsttime" value="{{ $matkaresult->firsttime }}">
                                              </div>
                                                @error('firsttime')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>  
                                           <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Close Time<span class="text-danger">*</span></label>
                                                 <input type="time" name="lasttime" class="form-control" id="lasttime" value="{{ $matkaresult->lasttime }}">
                                              </div>
                                                @error('lasttime')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                           <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Jodi Link<span class="text-danger">*</span></label>
                                                 <input type="text" name="jodi_url" class="form-control" id="jodi_url" value="{{ $matkaresult->jodi_url }}">
                                              </div>
                                                @error('jodi_url')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                           <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Panel Link<span class="text-danger">*</span></label>
                                                 <input type="text" name="panel_url" class="form-control" id="panel_url" value="{{ $matkaresult->panel_url }}">
                                              </div>
                                                @error('panel_url')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                        </div>
                                        <div class="bank-details-btn ">
                                            <button type="submit" class="btn bank-cancel-btn me-2">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
