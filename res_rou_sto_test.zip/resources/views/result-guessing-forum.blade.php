<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    
    
    
    
    
    <!-- End Wayback Rewrite JS Include -->


    <title> GUESSING FORUM KALYAN MATKA RESULT GUESSING MADHUR - </title>
    <meta http-equiv="refresh" content="900" />
    <meta name="description" content="satta matka, matka,341 guessing, matka guessing, kalyan matka, matka result, satta matka 341, kalyan guessing, guessing forum, satta bazar, सात्त मटका, मटका, satta king, madhur matka " />
    <meta name="keywords" content="satta matka, matka,341 guessing, matka guessing, kalyan matka, matka result, satta matka 341, kalyan guessing, guessing forum, satta bazar, सात्त मटका, मटका, satta king, madhur matka " />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
    <meta name="google" value="notranslate" />

   <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>

    

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async=async src="https://www.googletagmanager.com/gtag/js?id=G-TVDGB9FMGW"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'G-TVDGB9FMGW');
    </script>
</head>
<body>
    <!-- BEGIN WAYBACK TOOLBAR INSERT -->
    <style type="text/css">
        body {
            margin-top: 0 !important;
            padding-top: 0 !important;
            /*min-width:800px !important;*/
        }
    </style>
    
    <div id="wm-ipp-base" lang="en" style="display: block; direction: ltr;">
    </div>


    <div id="donato" style="position:relative;width:100%;">
        <div id="donato-base">
            
        </div>
    </div>
    
    <!-- END WAYBACK TOOLBAR INSERT -->
    <style>

        @font-face {
            font-family: myfont1;
            /* src: url(/web/20200513044723im_/https://app.sattamatka.mobi/LatoLatin-BoldItalic.woff2);*/
        }

        .head_div {
            width: 100%;
            box-sizing: border-box;
        }

        .logo {
            /*background-image: url('../../index_files/logosm.jpeg');*/
            /* background-size: auto auto;
            background-position: center;
            height: 120px;*/
            background-repeat: no-repeat;
            background-size: auto auto;
            background-position: center;
            /*width: 75%;*/
            height: 100%;
            text-align: center;
            background-repeat: no-repeat;
            float: none;
            margin-left: auto;
            margin-right: auto;
        }

        .header {
            border-radius: 3px;
            border: 3px solid #13316c;
            box-sizing: border-box;
            background: radial-gradient(white, #e9f5fa);
            box-shadow: 0 0 10px #13316c;
            height: 75px;
        }

        .b_msg {
            font-family: myfont1;
            font-size: 12px;
            box-sizing: border-box;
            color: #fff;
            margin: 6px 0 0 0;
            padding: 5px 0;
            text-align: center;
            width: 100%;
            background-color: #0033cc;
            margin: 8px 0 0 0;
        }

        @media only screen and (max-width:480px) {
            .logo {
                background-size: 100% auto;
            }

            .b_msg {
                font-size: 9px;
            }
        }
    </style>


    <!--header start-->

    <div class="head_div">
        <a href="javascript:void(0);">
            <div class="header">
                <div class="logo">
                    <img class="logo ptb-10 mb-0" src="{{url('front-assets/images/logo.jpg')}}" alt="SattaMatka" />
                </div>
                
            </div>
            
        </a>
    </div>
    <div class="b_msg">
        Use Google Chrome or Mozilla Firefox, Safari Browser to use and see this Website. Do not use UC Browser UC Mini and opera Mini.
        <div>इस वेबसाइट का उपयोग करने और देखने के लिए Google क्रोम या मोज़िला फ़ायरफ़ॉक्स, सफ़ारी ब्राउज़र का उपयोग करें। यूसी ब्राउज़र यूसी मिनी और ओपेरा मिनी का उपयोग न करें।.</div>
    </div>
    <!--header end--><!--posting rules start-->
    <style>
        h1 {
            text-align: center;
            font-size: 13px;
            background-color: #03c;
            color: #fff;
        }

        .heros {
            width: 66.67%;
            float: left;
            background-color: #25a2b8;
            padding: 7px 0;
            font-size: 30px;
        }

        @media only screen and (max-width:480px) {
            .logo {
                background-size: 100% auto;
            }

            .b_msg {
                font-size: 9px;
            }

            .heros {
                width: 66.67%;
                float: left;
                background-color: #25a2b8;
                padding: 12px 0;
                font-size: 22px;
            }
        }

        .i_btn1 {
            padding: 7px 10px;
            color: #fff;
            font-weight: 700;
            font-family: myfont1;
            margin-top: 7px;
            cursor: pointer;
            border-radius: 3px;
        }
    </style>
    <h1>
        Kalyan matka result satta matka guessing forum all satta bazar guessing
        <br />सात्त मटका कल्याण मटका  मटका रेसुल्ट
    </h1>

    <div class="postrule">
        <p class="postrule_head1">Posting Rules:-</p>
        <p class="postrule_head2">
            2 OPEN YA CLOSE
            <br />
            6 JODI
            <br />
            AUR 8 PANNA
            <br />
            AUR RESULT TIME SE 21 MIN PHELE GAME POST KARNA HOGA....!!!!
            <br />
            Dont Mention Date Or Time In Your Post.
            <br />
        </p>
        <hr />
        <small>
            <center>
                <b>
                    <font color="red">
                        Top 10 Guesser Of Guessing Forum..<br />

                        Will Be Allowed To Experts Forum &amp; Chatforum<br />

                        Top 10 Guessers Will Be Announced On Every Sunday<br />
                    </font>
                </b>
            </center>
        </small>
        <p></p>
        <a href="" style="text-decoration:none;">
            <div class="read_forum">Click Here To Read Full Guessing Forum Rules</div>
        </a>
    </div>
    <!--posting rule end-->
    <style>
        .postrule_head1,
        .postrule_head2,
        .read_forum {
            text-align: center;
            font-weight: 700;
        }

        .profile_head,
        .read_forum {
            color: #fff;
            font-family: myfont1;
        }

        .postrule_head1,
        .postrule_head2,
        .profile_head,
        .read_forum {
            font-family: myfont1;
        }



        .comment_box,
        .profile {
            box-shadow: 0 0 10px #b3b3b3;
        }

        .postrule {
            border: 2px solid #039686;
            background-color: #e5fffc;
            margin: 8px 0 0 0;
            float: left;
            width: 100%;
            box-sizing: border-box;
        }

        .postrule_head1 {
            padding: 0px 0 0 0;
        }

        .postrule_head2 {
            font-size: 15px;
        }

        .read_forum {
            font-size: 18px;
            background-color: #039686;
            margin: 0;
            padding: 4px 0 0;
        }

        .profile {
            background-color: #133e8c;
            border: 2px solid #001945;
            text-align: center;
            float: left;
            width: 100%;
            box-sizing: border-box;
        }





        .profile_user {
            font-size: 20px;
            font-family: myfont1;
            color: #fff;
        }



        .comment_box {
            border: 2px solid #a15001;
            border-radius: 5px;
            float: left;
            margin: 10px 0 0 0;
            width: 100%;
            box-sizing: border-box;
        }



        /* .quote {
            background-color: #6ff;
            color: red;
            border-width: 1px;
            border-color: #6ff;
            font-weight: 700;
            font-style: italic;
            margin: 1px;
            padding: 10px;
        }*/

        .profile_head {
            width: 33%;
            margin: 5px 0;
            float: left;
        }

        .profile_head_img {
            float: left;
            margin: 0 0 0 30%;
        }



        .profile_head_menu {
            float: left;
            padding: 8px 0 8px 5px;
            font-size: 20px;
            font-family: myfont1;
            color: #fff;
        }





        @media only screen and (max-width:480px) {

            .postrule_head1,
            .postrule_head2 {
                font-size: 10px;
            }

            .read_forum {
                font-size: 15px;
                padding: 2px 0;
            }





            .profile_head {
                /*width:33.33%;*/

                float: left;
                margin: 4px 0;
            }



            .profile_head_img {
                float: left;
                margin: 0 0 0 0;
            }



            .profile_head_menu {
                float: left;
                padding: 8px 0 8px 5px;
                font-size: 15px;
                font-family: myfont1;
                color: #fff;
            }

            .profile_head_profile {
                width: 25%;
            }

            .profile_head_post {
                width: 30%;
            }

            .profile_head_ach {
                width: 45%;
            }

            .profile_user {
                font-size: 15px;
                font-family: myfont1;
                color: #fff;
                margin-top: 5px;
            }
        }

        .profile_head.profile_head_ach.a span.profile_head_menu {
            width: auto;
            text-align: center;
        }

        .profile_head.profile_head_ach.a {
            width: 100%;
            text-align: center;
            float: none;
            clear: both;
            MARGIN-TOP: 30PX;
        }

        .mains {
            width: 100%;
            text-align: center;
            display: inline-block;
            clear: both;
        }

        .profile_head_menu {
            float: none !important;
        }

        .mains .profile_head {
            width: 33%;
            text-align: center;
            float: none;
            display: inline-block;
        }

        .profile_head_menu.butto {
            background: #440e62;
            padding: 9px 10px;
            border-radius: 10px;
            display: inline-block;
            width: auto;
            vertical-align: middle;
        }

        @media only screen and (max-width:767px) {
            .mains .profile_head {
                width: auto;
                text-align: center;
                float: none;
                display: inline-block;
            }
        }
    </style>

    <!--header start-->
    <!--header end-->



    <style>
        .g_box {
            border-radius: 5px;
            border: 1px solid #ccc;
            display: inline-block;
            box-sizing: border-box;
            width: 100%;
            height: 150px;
            background-color: #f8f8f8;
            padding: 8px;
            font-size: 15px;
            font-weight: 700;
            font-style: italic;
        }

        .m_box {
            margin: 10px;
        }

        ::placeholder {
            color: #b3b3b3;
            opacity: 1;
        }

        .g_btn {
            background-color: #a15001;
            color: #fff;
            border: 1px solid #a15001;
            padding: 2px 10px;
            margin: 10px 0;
            cursor: pointer;
            font-weight: 700;
            font-family: myfont1;
        }

        .panel {
            padding: 0 18px;
            display: none;
            background-color: #d4f2fb;
            overflow: hidden;
            font-weight: 800;
            margin-top: 10px;
            border: 2px solid #ea0707;
            border-radius: 7px;
        }

            .panel p {
                font-style: italic;
                font-family: myfont1;
                margin: 5px;
            }

        .chart_title2 {
            background-color: #25a2b8;
            border-radius: 5px 5px 0 0;
            text-align: center;
            color: #fff;
            padding: 2px 0;
            font-family: myfont1;
            font-weight: 700;
            font-size: 18px;
            margin: 11px 0 0 0;
        }

        .chart_head2 {
            background-color: #b6e7ef;
            text-align: center;
            font-family: myfont1;
            font-weight: 700;
            font-size: 18px;
            padding: 5px 0 4px 0;
            color: #000;
        }
    </style>
    <style>
        .live_update {
            border-radius: 3px;
            border: 1px solid #461300;
            box-shadow: 0 0 2px #461300;
            background-color: #fff0eb;
            margin: 10px 0 5px 0;
        }

        .live_head {
            font-family: myfont1;
            color: #fff;
            background-color: #6c1d00;
            font-size: 20px;
            margin: 0;
            font-weight: 700;
            text-align: center;
            padding: 10px 0;
        }


        .live_title {
            color: #252525;
            font-family: myfont1;
            font-weight: 700;
            font-size: 20px;
        }

        .live_num {
            color: #bb016e;
            font-family: myfont1;
            font-weight: 700;
            font-size: 20px;
            margin: -11px 0 6px 0;
        }

        .refresh_btn {
            background-color: #ff4300;
            border: 1px solid #ab3a0f;
            color: #fff;
            padding: 5px;
            cursor: pointer;
        }

        .matka_live {
            border-radius: 3px;
            padding: 10px 0;
            text-align: center;
            color: #fff;
            font-size: 20px;
            font-weight: 700;
            font-family: myfont1;
        }

        .user_login {
            border-radius: 3px;
            padding: 10px 0;
            text-align: center;
            font-size: 20px;
            font-weight: 700;
            font-family: myfont1;
            margin: 15px 0 0 0;
            background-color: #133e8c;
            border: 1px solid #001b4d;
            box-shadow: 0 0 10px #001b4d;
        }

        .i_btn1 {
            padding: 7px 10px;
            color: #fff;
            font-weight: 700;
            font-family: myfont1;
            margin: 7px;
            cursor: pointer;
            border-radius: 3px;
        }

        .m_live {
            margin: 7px 0;
        }

        .matka_live2 {
            border-radius: 3px;
            padding: 0px 0 18px 0;
            text-align: center;
            border-bottom: 2px solid #8c8583;
            border-left: 40px solid #fff0eb;
            border-right: 40px solid #fff0eb;
        }


        .bg1 {
            background-color: #e11d03;
            border: 1px solid #461300;
            box-shadow: 0 0 10px #461300;
        }

        .bg2 {
            background-color: #ff9104;
            border: 1px solid #a15b01;
            box-shadow: 0 0 10px #a15b01;
        }

        .bg3 {
            background-color: #133e8c;
            border: 1px solid #001b4d;
            box-shadow: 0 0 10px #001b4d;
        }

        .bg4 {
            background-color: #e70042;
            border: 1px solid #700020;
            box-shadow: 0 0 10px #700020;
        }

        .bg5 {
            background-color: #00aa3c;
            border: 1px solid #003e16;
            box-shadow: 0 0 10px #003e16;
        }

        .bg6 {
            background-color: #ff6100;
            border: 1px solid #704700;
            box-shadow: 0 0 10px #704700;
        }

        .bg7 {
            background-color: #98043f;
            border: 1px solid #610127;
            box-shadow: 0 0 10px #610127;
        }

        .bg8 {
            background-color: #4b0049;
            border: 1px solid #290028;
            box-shadow: 0 0 10px #290028;
        }

        .matka_result {
            border-radius: 3px;
            border: 1px solid #bf1600;
            background-color: #fff2f0;
        }

        .matka_result_box {
            border-bottom: 2px solid #8c8583;
        }

        .matka_title {
            text-align: center;
            font-family: myfont1;
            color: #e11d03;
            font-size: 20px;
            font-weight: 700;
            margin: 15px 0 0 0;
        }

        .matka_num {
            text-align: center;
            font-family: myfont1;
            color: #252525;
            font-size: 20px;
            font-weight: 700;
            margin: 2px 0 12px 0;
        }


        .refresh {
            background-color: #6e2d02;
            border: 1px solid #3f1900;
            text-align: center;
            color: #fff;
            padding: 10px 0;
            width: 30%;
            margin: 20px 0 0 0;
            font-family: myfont1;
            font-size: 20px;
            border-radius: 3px;
            cursor: pointer;
            font-weight: 700;
            box-shadow: 0 0 10px #461300;
            margin-left: auto;
            margin-right: auto;
        }


        @media only screen and (max-width: 480px) {

            .matka_live {
                font-size: 20px;
            }

            .live_update {
                margin: 5px 0;
            }

            .refresh {
                width: 40%;
            }
        }

        .blinking {
            animation: blinkingText 0.8s infinite;
            font-size: 25px;
            color: red;
        }
    </style>
    <style>
        .showoriginal {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 20px;
            top: 5px;
        }

            .showoriginal input {
                display: none;
            }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ca2222;
            -webkit-transition: .4s;
            transition: .4s;
            border-radius: 34px;
        }

            .slider:before {
                position: absolute;
                content: "";
                height: 18px;
                width: 18px;
                left: 4px;
                bottom: 1px;
                background-color: white;
                -webkit-transition: .4s;
                transition: .4s;
                border-radius: 50%;
            }

        input:checked + .slider {
            background-color: #2ab934;
        }

        input:focus + .slider {
            box-shadow: 0 0 1px #2196F3;
        }

        input:checked + .slider:before {
            -webkit-transform: translateX(26px);
            -ms-transform: translateX(26px);
            transform: translateX(25px);
        }

        /*------ ADDED CSS ---------*/
        .slider:after {
            content: 'OFF';
            color: white;
            display: block;
            position: absolute;
            transform: translate(-50%,-50%);
            top: 50%;
            left: 50%;
            font-size: 10px;
            font-family: Verdana, sans-serif;
        }

        input:checked + .slider:after {
            content: 'ON';
        }

        /*--------- END --------*/
    </style>

    <!--
         <hr><div class="chart_title2">
          Are You A Guesser..?<br/>
          Do You Want To Be A Guesser..?<br/></div>
          <div class="chart_head2">
    <a href="https://app.sattamatka.mobi/apk/app-release.apk">Click Here</a></div></div>
    -->

    <div class="profile" style="margin:10px 0 10px 0;">
        <div class="profile_head" style="width:100%; text-align:center;">
            GUESSING FORUM
        </div>

    </div>

    <!--
          <div class="postrule">
          <div class="read_forum">Play Matka Online<br/>
    101% Trusted<br/>
    <a href="https://rsgames.mobi">Download Now</a></div></div>echo '<div align="center" style="font-weight: bolder;font-style: italic;margin: 5px;">To Play Online Matka<br/>Whats App Or Call<br/>07769826748</div>';
    -->


    <div class="postrule">
        <div class="read_forum">
            Play Matka Online
            <br />
            101% Trusted
            <br />
            <a href="#" style="color:red">Download Now</a>
        </div>
    </div>

    <div style="text-align:center;margin-top:345px;">
        <a href="/Home/Reports">
            <input type="button" value="Top 10" />
        </a>
        <input type="button" value="Refresh" onclick="parent.location=&quot;javascript:location.reload()&quot;" /> --
        <input type="button" onclick="window.location.href=&#39;index.php&#39;" value="GoTo Home" />
        <input type="button" onclick="toggle();" value="Emojis" />
        <br />
        <br />
        <div hidden=hidden class="row1 time-table" style="border-radius: 5px; margin: 0px 10px 20px; box-shadow: white 0px 0px 10px 2px; text-align: center !important; padding-top: 0px; clear: both !important;">
            
            <table class="table table_box scview" align="center" style="border-style: solid;border-width: 2px;">
                <thead class="scview">
                    <tr style="background: #a8655e; color: white;">
                        <td style="padding: 7px;">Code To Use</td>
                        <td style="padding: 7px;">Output Emoji Displays</td>
                    </tr>
                </thead>
                <tbody class="bg-color2 scview">
                    <tr>
                        <td>:dance:</td>
                        <td><img src="https://storage.googleapis.com/sattamatka-cdn-bucket/emojis/dance.gif" height="30px" alt="dance" /></td>
                    </tr>
                    <tr>
                        <td>:fire1:</td>
                        <td><img src="https://storage.googleapis.com/sattamatka-cdn-bucket/emojis/firecracker1.gif" height="30px" alt="fire1" /></td>
                    </tr>
                    <tr>
                        <td>:fire2:</td>
                        <td><img src="https://storage.googleapis.com/sattamatka-cdn-bucket/emojis/firecracker2.gif" height="30px" alt="fire2" /></td>
                    </tr>
                    <tr>
                        <td>:gunfire:</td>
                        <td><img src="https://storage.googleapis.com/sattamatka-cdn-bucket/emojis/gunfire.gif" height="30px" alt="gunfire" /></td>
                    </tr>
                    <tr>
                        <td>:lol:</td>
                        <td><img src="https://storage.googleapis.com/sattamatka-cdn-bucket/emojis/lol.gif" height="30px" alt="lol" /></td>
                    </tr>
                    <tr>
                        <td>:congrats:</td>
                        <td><img src="https://storage.googleapis.com/sattamatka-cdn-bucket/emojis/congrats.gif" height="30px" alt="congrats" /></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <p id="emojitoggle" hidden=hidden>:dance: &nbsp; :fire1: &nbsp; :fire2: &nbsp; :gunfire: &nbsp; :lol: &nbsp; :congrats: </p>


    </div>

    <div style="text-align:center;margin-top:5px;margin-top:5px;">
    </div>


    <div class="panel" style="text-align:center;">
        <p>NOTICE:-</p>
        <p>SUPREME DAY TOP 10 GUESSERS</p>
        <p>SUPREME NIGHT TOP 10 GUESSERS</p>
        <p>OF THIS WEEK WILL GET 1000/-RS</p>
        <p>POINTS ON RS GAME APP</p>
        <p>UPDATE YOUR RS GAME DETAILS</p>
        <p>TOP 10 GUESSER NAME WILL BE ANNOUNCED AT SUNDAY...</p>
        <p>SUPREME RESULT TIMING:-</p>
        <p>SUPREME DAY</p>
        <p>OPEN 3:35 PM</p>
        <p>CLOSE 5:35 PM</p>
        <p>SUPREME NIGHT</p>
        <p>OPEN 8:35 PM</p>
        <p>CLOSE 11:35 PM</p>
    </div>
    <form id="forumForm" method="post" action="#">
        <input type="hidden" name="com_id" value="" />
        <input type="hidden" name="com_typ" value="comment" />
        <input type="hidden" name="selectedMarketId" id="selectedMarketId" value="" />
        <div class="comment_box">
            <input type="hidden" value="" name="userid" />
        </div>
    </form>

    <!--form end-->
    <!--Comment-->



    <style>

        .table {
            border-spacing: 2px;
            width: 100%;
            border: 2px solid black;
            border-collapse: collapse;
        }

        .table_box {
            width: 50%;
            text-align: center;
        }

        table.scview {
            width: 100px;
        }

        thead.scview, tbody tr {
            display: table;
            width: 100%;
            table-layout: fixed;
        }

        .time-table {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
            text-align: center;
            padding-top: 10px;
        }

        .gf_box {
            float: left;
            width: 100%;
            border-radius: 5px;
            border: 3px solid #ff8c05;
            margin: 5px 0;
            box-sizing: border-box;
            z-index: 999999;
        }

        .gf_title {
            float: left;
            width: 100%;
            height: 35px;
            /* border-radius:4px 4px 0 0;	*/
            background-color: #ff8c05;
        }

        .gf_title_left {
            float: left;
            width: 50%;
            height: 30px;
            padding: 8px 0;
            font-weight: 700;
            color: #580138;
            font-family: myfont1;
        }

        .gf_title_right {
            float: left;
            text-align: right;
            width: 40%;
            height: 30px;
            padding: 8px 0;
            font-weight: 700;
            font-family: myfont1;
        }

        .gf_title_left > img {
            width: 2.5%;
            float: left;
            padding-left: 4px;
        }

        .gf_comment {
            float: left;
            /*text-align:center;*/
            width: 100%;
        }

        pre {
            padding: 3px 0;
            font-weight: 700;
            white-space: pre-wrap; /* Since CSS 2.1 */
            white-space: -moz-pre-wrap; /* Mozilla, since 1999 */
            white-space: -pre-wrap; /* Opera 4-6 */
            white-space: -o-pre-wrap; /* Opera 7 */
            word-wrap: break-word;
            text-align: center;
            font-size: 15px;
            font-style: italic;
            overflow: hidden;
        }

        .gf_bottom {
            float: left;
            width: 100%;
        }

        .gf_bottom_left {
            float: left;
            background-color: #ffe3b3;
            width: 50%;
            text-align: center;
            font-weight: 700;
            font-family: myfont1;
            padding: 3px 0;
            color: #580138;
        }

        .gf_bottom_right {
            float: left;
            width: 50%;
            background-color: #dbb988;
            text-align: center;
            font-weight: 700;
            font-family: myfont1;
            padding: 3px 0;
            color: #580138;
        }



        .gf_bottom2 {
            float: left;
            width: 100%;
        }

        .gf_bottom_left2 {
            float: left;
            width: 50%;
            background-color: #dbb988;
            text-align: center;
            color: #580138;
            font-weight: 700;
            font-family: myfont1;
            padding: 3px 0;
        }

        .gf_bottom_right2 {
            float: left;
            width: 50%;
            background-color: #ffe3b3;
            text-align: center;
            padding: 3px 0;
            color: #580138;
            font-weight: 700;
            font-family: myfont1;
        }


        @media only screen and (max-width:480px) {

            .gf_title_left > img {
                width: 12%;
                padding-left: 4px;
            }

            .gf_title_right {
                padding: 9px 0;
                font-weight: 700;
                font-size: 12px;
                font-family: myfont1;
            }

            .gf_bottom_right2 {
                font-size: 15px;
                padding: 3px 0 4px 0;
            }
        }

        .quote {
            background-color: #66FFFF;
            color: red;
            border-width: 1px;
            border-color: #66FFFF;
            margin-top: -16px;
            margin-bottom: -25px;
            margin-left: 1px;
            margin-right: 1px;
            padding-top: 1px;
            padding-bottom: 1px;
            padding-left: 1px;
            padding-right: 1px;
            font-weight: bold;
            font-style: italic;
            font-size: 13px;
        }
    </style>
    @php 
  
    @endphp
         @foreach($guessing as $guess)
         @php 
         
         $user = DB::table('users')->where('id',$guess->user_id)->first();
         @endphp
        <div id="listitem" class="gf_box" data-gameid="5">
            <div class="gf_title">
                <div class="gf_title_left">
                    &nbsp;&nbsp;
                    <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/admin.png" alt="satka-matka-admin" style="cursor:pointer;" onclick="window.location.href=&#39;/Home/UserProfile?userid=38205;" />
                    &nbsp;
                    <u>
                            <span style="color:#aa2a2a;font-weight:bold;text-align:center;font-size: 12pt;word-wrap: break-word;font-family: Tahoma;">
                                {{$user->name}}
                            </span>
                    </u>
                </div>


                <div style="" class="gf_title_right">{{ \Carbon\Carbon::parse($guess->created_at)->format('Y-m-d h:i A') }} </div>
            </div>
            <div class="gf_comment">
                <pre>
                <div class="quote" style="margin-left: 2px;margin-right: 2px;">
                    <span style='display:block;line-height:25px;'>{{$guess->description}}</span>
                </div>
             </pre>
            </div>

            <div class="gf_bottom">
                <div class="gf_bottom_left">
                    <a href="{{ route('home.index') }}">Google Chrome</a>
                </div>
                <div class="gf_bottom_right">
                        <a style="text-decoration:none;color:#361400 !important" href="javascript:void(0)" onclick="ShowAlert();"> (Quote)</a>
                </div>
                <div align="left" id="forumComment_309533" hidden=hidden style="background-color:#d1caa0;margin-left:5px;margin-right:5px;">
                    <textarea id="txtForumComment309533" name="w3review" rows="2" cols="50" style="width:100%;height:30px;padding-bottom:0px;"></textarea>
                    

                   
                    <input style="margin-top:10px;" type="button" class="" value="Post Quote" id="btnForumPost_309533" onclick="PostForumComment(38205,309533)" />

                </div>
            </div>

            <div class="gf_bottom2">
                <div class="gf_bottom_left2">
                    <a href="#" onclick="gototop();">
                        <u style="color:#a7024c;">GoTop</u>
                    </a>
                </div>
                <div class="gf_bottom_right2">
                    <a href="#" onclick="gotobottum();">
                        <u style="color:#c61700;">GoBottom</u>
                    </a>
                </div>
            </div>
        </div>
        
       @endforeach
    <br />

    <div id="bottom"></div>

    <style>
        .current, .disabled {
            color: #ff0000;
            background: #FFEB3B
        }

        .current, .disabled, .n_btn, .pg_num {
            font-weight: 700;
            padding: 3px;
            font-family: myfont1;
            border: 2px solid #003aff;
            margin: 0 0 0 5px;
            display: inline-block;
            float: left
        }

        a, a:hover {
            text-decoration: none
        }

        .pagination {
            color: #7a0238;
            display: inline-block
        }

        .pg_num {
            color: #252525
        }

        .n_btn {
            color: #7a0238
        }
    </style>

    <div style="float:left; width:100%;">
        <br />
        <div class="pagination">

                {{ $guessing->links() }}


            
        </div>
    </div>

    <style>
        .refresh {
            background-color: #440e62;
            border: 1px solid #14001f;
            text-align: center;
            color: #fff;
            padding: 8px;
            font-family: myfont1;
            box-sizing: border-box;
            margin: 10px 0 0 0;
            font-size: 20px;
            font-weight: 700;
            box-shadow: 0 0 10px #461300;
            width: 10%;
            text-align: center;
            text-decoration: none;
        }
    </style>

    <div align="center" style=" width: 100%;text-align: center;margin-top: 17px;float: left;">
        <a href="#" class="refresh" onclick="gototop();">
            Go To Top
        </a>
        <a href="{{ route('home.logout') }}" class="refresh" style="margin-left:5px;" onclick="event.preventDefault(); document.getElementById('logout').submit();">
            Log Out
        </a>

        <form id="logout" action="{{ route('home.logout') }}" method="get" style="display: none;">
        @csrf
    </form>
        
    </div>

    <style>
        .footer {
            width: 100%;
            box-sizing: border-box;
            float: left;
            text-align: center;
            color: #fff;
            font-size: 20px;
            font-weight: 700;
            font-family: myfont1;
            height: 170px
        }

        .back, .home {
            color: #000;
            padding: 5px 0;
            width: 50%
        }

        .home {
            background-color: #ffb12a;
            border: 1px solid #bc4200;
            border-radius: 20px 0 0 20px;
            float: right
        }

        .back {
            background-color: #fdf243;
            border: 1px solid #bc4200;
            border-radius: 0 20px 20px 0;
            float: left
        }

        .footer_title {
            font-size: 18px;
            padding: 10px 0
        }

        .bg8 {
            background-color: #dc0340;
            border: 1px solid #84003b
        }

        @media only screen and (max-width:480px) {
            .footer {
                height: 140px
            }

            .back, .home {
                width: 70%;
                font-size: 16px
            }

            .footer_title {
                font-size: 14px;
                padding: 10px 0
            }
        }
    </style>
    <!--FOOTER START-->

    <style>
        .f_block {
            width: 100%;
            height: 50px;
        }

        .ff1 {
            float: left;
            width: 50%;
        }

        .footer {
            width: 100%;
            box-sizing: border-box;
            /* float: left; */
            text-align: center;
            color: #fff;
            font-size: 20px;
            font-weight: 700;
            font-family: myfont1;
            height: 100% !important;
            clear: both;
        }
    </style>

    <div class="footer bg8" style="margin:15px 0 75px 0;">
        <p class="footer_title">
            SERVER: MATKA GUESSING
            <br />
            AD BOSS SATTA MATKA
            <br />
            ALL RIGHTS RESERVED (2012-2024)
            <br />
            CONTACT ADMIN
        </p>
        <div class="f_block">
            <a href='/'>
                <div class="ff1">
                    <div class="home">HOME</div>
                </div>
            </a>
            <a href="#">
                <div class="ff1">
                    <div class="back">BACK</div>
                </div>
            </a>
        </div>
    </div>
    <!--FOOTER end-->

    <script>
        function gotobottum() {
            $("html, body").animate({ scrollTop: $(document).height() }, 1000);
        }
        //function gototop() {
        //     $("html, body").animate({ scrollTop: 0 });
        //}

    </script>

    <style>
        .fixed_menubar {
            display: block;
            width: 100%;
            background-color: #f2f2f2;
            border-top: 1px solid #d9d9d9;
            height: 68px;
            z-index: 10;
            position: fixed;
            bottom: 0;
        }

        .bottom_menus {
            width: 25%;
            float: left;
            cursor: pointer;
            text-align: center;
        }

            .bottom_menus > i {
                color: #bfbfbf;
                font-size: 28px;
                padding: 6px 0;
            }

                .bottom_menus > i:hover {
                    color: #ff4d4d
                }

        .bottom_menus_title {
            color: #a6a6a6;
            font-weight: 700;
            margin: 0px 0 0 0;
            font-size: 15px;
            font-family: myfont1;
            /* line-height:18px; */
        }

        .bb1 {
            color: #133E8C;
        }


        @media only screen and (max-width:480px) {
            .fixed_menubar {
                display: block;
                width: 100%;
                background-color: #f2f2f2;
                border-top: 1px solid #d9d9d9;
                height: 58px;
                z-index: 10;
                position: fixed;
                bottom: 0;
            }

            .bottom_menus {
                width: 20%;
                float: left;
                cursor: pointer;
                text-align: center;
            }

                .bottom_menus > img {
                }

            .bottom_menus_title {
                color: #a6a6a6;
                font-size: 11px;
                font-family: myfont1;
                line-height: 12px;
            }

            .bb1 {
                color: #133E8C;
            }
        }
        
                .b14 {
            position: fixed;
            bottom: 75px;
            left: 15px;
            border: 1px solid #141313;
            background: #2c2841 !important;
            color: #fff;
            padding: 5px;
            font-style: italic;
            font-weight: bold;
            border-radius: 5px;
            text-align: center;
            background-color: #2481cc !important;
        }
            .k-content {
        height: 100px !important;
    }
        table.k-editor {
        width: 100% !important;
        height: 100px !important;
        font-size: 100%;
        vertical-align: top;
        position: relative;
        border: 0px !important;
        background-color: #ffd1d1 !important;
    }

    /*  pre {
        display: block;
        padding: 9.5px;
        margin: 0 0 10px;
        font-size: 13px;
        line-height: 1.42857143;
        color: #333333;
        word-break: break-all;
        word-wrap: break-word;
        background-color: none !important;
        border: 0px solid #ccc !important;
        border-radius: 0px;
    }*/

    pre {
        white-space: pre-line;
        display: block;
        padding-bottom: 0px;
        margin: 0px;
        margin-top: 0px;
        font-size: 15px;
        background-color: #ffffff;
        overflow: hidden;
    }

    .name-field {
        width: 60% !important;
        color: #00a !important;
        background-color: #ffd1d1 !important;
        background-repeat: repeat-x !important;
        background-position: 50% bottom !important;
        margin-right: 1px !important;
        padding: 1px 4px !important;
        border: 0px solid #d3cabd !important;
    }

    /*input {
        color: #00a !important;
        background-color: #ffd1d1 !important;
        background-repeat: repeat-x !important;
        background-position: 50% bottom !important;
        margin-right: 1px !important;
        padding: 1px 4px !important;
        border: 0px solid #d3cabd !important;
    }*/

    .k-editor .k-editable-area .k-content {
        box-sizing: border-box;
        border-width: 3px !important;
        border-color: black;
        border-style: solid;
        /*background-color: #fde7e7 !important;*/
    }

    .k-editor .k-editable-area {
        width: 100%;
        height: 100%;
        outline: 0;
        border: 0px;
        background-color: #fde7e7 !important;
    }

    table.k-editor {
        width: 100%;
        height: 250px;
        table-layout: fixed;
        border-style: none;
        border-collapse: separate;
        border-spacing: 0px !important;
        font-size: 100%;
        vertical-align: top;
        position: relative;
        border-width: 0px !important;
        border-color: none !important;
        border-radius: 0px !important;
        background-color: #FFD9D9 !important;
    }

    .k-gantt-toolbar .k-state-default, .k-grid .k-grouping-header, .k-grid-header, .k-grid-header-wrap, .k-grouping-header .k-group-indicator, .k-header, .k-pager-wrap, .k-pager-wrap .k-link, .k-pager-wrap .k-textbox {
        border-width: 0px !important;
        border-color: none !important;
        border-radius: 0px !important;
    }
        .o2 a.currentpage {
        border: 1px solid red;
        padding: 3px;
    }

    .o2 a:hover {
        border: 1px solid red;
    }
        select#select_market_name {
        padding: 7px 7px;
        width: 220px;
        border: 2px solid #ff8c05;
        border-radius: 10PX;
        /* margin-bottom: 10px; */
    }

        select#select_market_name:focus {
            outline: none;
        }

    .guessing-duplicate-sec {
        padding: 20px 10px;
        border: 2px solid #ff8c05;
        margin-top: 20px;
        border-radius: 10px;
    }

    .market-name-print {
        /* position: relative;
                top: 10px;
                left: 10px;*/
        font-weight: 700;
        font-style: italic;
    }

    .error {
        color: red;
    }
        .tox .tox-statusbar {
        display: none !important;
    }
    
        input[type=checkbox] {
        height: 0;
        width: 0;
        visibility: hidden;
    }

    label {
        cursor: pointer;
        text-indent: -9999px;
        width: 50px;
        height: 20px;
        background: grey;
        display: flex;
        border-radius: 40px;
        position: relative;
    }

        label:after {
            content: '';
            position: absolute;
            top: 3px;
            left: 2px;
            width: 15px;
            height: 15px;
            background: #fff;
            border-radius: 15px;
            transition: 0.3s;
        }

    input:checked + label {
        background: #DC143C;
    }

        input:checked + label:after {
            left: calc(100% - 5px);
            transform: translateX(-100%);
        }

    label:active:after {
        width: 130px;
    }
    </style>

    <div class="fixed_menubar">
           <a style="text-decoration:none;color:#003f6b !important" href="{{ route('home.index')}}">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/home-grey.png" width="25" alt="satta-matka" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title ">Home</p>
            </div>
        </a>
        <a style="text-decoration:none;color:#003f6b !important" href="{{route('home.ResultGuessing')}}">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/guessing-forum.png" width="25" alt="guessing-forum" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title bb1">
                    Guessing
                    <br />Forum
                </p>
            </div>
        </a>
        <a style="text-decoration:none;color:#003f6b !important" href="">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/guessing-forum.png" width="25" alt="chatting -forum" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title">
                    Chatting
                    <br />Forum
                </p>
            </div>
        </a>
        <a style="text-decoration:none;color:#003f6b !important" href="{{route('home.expertGuessing')}}">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/experts-forum-grey.png" width="25" alt="experts-forum" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title  ">
                    Experts
                    <br />Forum
                </p>
            </div>
        </a>
        <!--a style="text-decoration:none;color:#003f6b !important" href="tricks-forum.php" >
        <div class="bottom_menus">
           <img src="icon_g/trick-forum.png" width="25" alt="tricks-forum" style="margin:4px 0 0 0;" />
           <p class="bottom_menus_title  ">Tricks<br/>Forum</p>
        </div>
        </a-->
        <a style="text-decoration:none;color:#003f6b !important" href="javascript:void(0);" onclick="window.location.reload();">
            <div class="bottom_menus">
                <img src="https://storage.googleapis.com/sattamatka-cdn-bucket/images/refresh2.png" width="25" alt="Refresh" style="margin:4px 0 0 0;" />
                <p class="bottom_menus_title ">
                    Refresh
                    <br />Page
                </p>
            </div>
        </a>
    </div>
<!-- HTML for Modal -->
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog">
    <!-- Modal Content -->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Form</h4>
      </div>
      <div class="modal-body">
        <form id="dynamicForm">
            @csrf
            
          <div class="form-group">
           <textarea type="text" class="form-control" id="addTextarea" name="exparts"></textarea>
        </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" id="submitForm">Submit</button>
      </div>
    </div>
  </div>
</div>








    <style>
        .a14 {
            position: fixed;
            bottom: 60px;
            right: 5px;
            cursor: pointer;
            padding: 5px;
        }
    </style>
    <!--------------------------fixed navigation end-------------------------->
    

    <script>

        function gotobottum() {
            $("html, body").animate({ scrollTop: $(document).height() }, 1000);
        }
        //function gototop() {
        //    /* $("html, body").animate({ scrollTop: 0 });*/
        //}
        // Initialize the modal element


    </script>

    <script>
        //$('.accordion').click(function () {
        //    $(".panel").toggle("active");
        //});
    </script>

    







<script>

    function PostForumTopic() {

        var market_name_str = $("#select_market_name").val();
        if (market_name_str == '') {
            $("#err_select_market_name").html("Please Select Market");
            $("#err_select_market_name").focus();
            return;
        }

        var data =
        {
            gameMarketId: $("#select_market_name").val(),
            //Subject: $("#txtforumPost").val()
            Subject: $("#Comm").val(),
            ForumType:1,
           
        };

        //console.log(data);

         $.ajax({
             url: '/Home/PostForumTopic',
             type: 'POST',
             data: JSON.stringify({ forumModel: data}),
             dataType: "text",
             cache: false,
             contentType: "application/json; charset=utf-8",
             success: function (response) {
                 var json = JSON.parse(response);
                 var base_url = window.location.origin;
                 //debugger;
                 if (json.code == 1) { // User not Logged in
                     console.log('User not Logged in')
                     window.location.replace(base_url + '/Home/Login');
                 }
                 else {
                     window.location.replace(window.location.href.split('?')[0]);
                 }
             },
             error: function(response) {
                 var json = JSON.parse(response);
                 alert(json["message"]);
             }
         });
    }

    function ShowHideForumComment(touserid) {
        console.log("#forumComment_" + touserid);
        $("#forumComment_" + touserid).show();
        return false;
    }

    function ShowAlert() {
    $.ajax({
        url: "{{route('home.ShowAlert')}}", // Laravel route ka URL
        type: 'POST', // Request type (POST, GET, etc.)
        data: {
            _token: $('meta[name="csrf-token"]').attr('content'), // CSRF token
            customData: 'Some data here' // Agar aapko additional data bhejna ho
        },
         success: function(response) {
             
            if (response.success == true) {
            $('#myModal').modal('show');
            } else {
                alert(response.message); // Show the response message
            }
        },
        
    });
}

 $(document).ready(function () {
    // Add a new textarea dynamically
   

    // Handle form submission via AJAX
    $('#submitForm').on('click', function (e) {
        e.preventDefault();

        var formData = new FormData($('#dynamicForm')[0]);

        $.ajax({
            url: "{{ route('home.guessingstore')}}", // Define your Laravel route here
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                // Handle success (e.g., show success message)
                alert('Form submitted successfully!');
                $('#myModal').modal('hide');
                window.location.reload();
            },
            error: function (xhr, status, error) {
                // Handle error (e.g., show error message)
                alert('Something went wrong!');
            }
        });
    });
});


     function DeleteForumPost(forumid){

        var data =
        {
            ForumId: forumid,
            ForumType: 0,
        };

         $.ajax({
             url: '/Home/DeleteForumPost',
             type: 'POST',
             data: JSON.stringify({ forumModel: data}),
             dataType: "json",
             cache: false,
             contentType: "application/json; charset=utf-8",
             success: function (response) {
                 if (response.success == true) {
                     alert('Forum Post Deleted successfully');
                     //Remove html tag from DOM
                     $("#listitem_" + forumid).remove();
                 }
                 else {
                     console.log(response);
                 }
             },
             error: function (response) {
                 //var json = JSON.parse(response);
                 console.log(response);
                 //alert(json["message"]);
             },
        });
}

     function BlockUser(id){

        $.ajax({
            url: '/Home/BlockUser'+ "/"+ id,
            type: 'POST',
            //dataType: "json",
            data: id,
            cache: false,
            //contentType: "application/json; charset=utf-8",
            success: function (result) {
                alert(result);
                },
                error: function (result) {
                   alert(result);
                }
            });
    }

</script>



<script>

    function gototop() {
        $('html,body').animate({ scrollTop: 0 }, "slow");
    }

</script>

<script>
    $(document).ready(function () {

        $("#txtAutoSearch").on("keyup", function () {
            var value = $(this).val().toLowerCase();
            $("#forumrows div.eachforumrow").filter(function () {
            });
        });
    });

    function FilterPosts() {
        var value = $("#txtAutoSearch").val().toLowerCase();

        $("#forumrows div.eachforumrow").filter(function () {
            $(this).toggle($(this).find("div:nth-child(2) > font:nth-child(2) > b").text().toLowerCase().indexOf(value) > -1)
        });
    }

</script>








<script>

    function marketNameAppend() {
        //var market_name_str = $("#select_market_name").val();
        var market_name_str = $("#select_market_name option:selected").text();
        console.log(market_name_str);
        if (market_name_str !== '') {

            $("#err_select_market_name").html("");
            var market_name_split = market_name_str.split("#");

            if (market_name_split[1] == "khabar") {
                var html = "*¯¯¯¯¯¯\_:emoji255:_/¯¯¯¯¯¯*<br><br><br>KHABAR KI TAYARI<br><br><br>*¯¯¯¯¯¯\_:emoji266:_/¯¯¯¯¯¯*";
                $("#market_name_div").html(html);
            } else if (market_name_split[1] == "close") {
                $("#market_name_div").addClass("market-name-print");
                var html = market_name_split[0];
                $("#market_name_div").html(html + "<br>CLOSE");
            } else {
                var html = market_name_split[0];
                $("#market_name_div").html(html);

                //add the market name to multi line textbox
                var marketName = market_name_split[0] + '\r\n';
                $("#Comm").val(marketName);
                $("#Comm").focus();

                var oldUrl = "/Home/Forum?selectedMarketId=";
                var newUrl = oldUrl + $("#select_market_name").val();
                console.log(newUrl);
                $("#anchorFilter").attr("href", newUrl);

                $("#selectedMarketId").val($("#select_market_name").val());

            }

        } else {
            $("#market_name_div").html('');
        }
    }

</script>



</body>
</html>
