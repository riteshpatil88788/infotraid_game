<?php

namespace App\Http\Controllers\SubAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\SattaMatka;

class SattaMatkaController extends Controller
{
 
    public function edit(){
        $data['SattaMatkas'] = DB::table('satta_matkas')->where('id',1)->first();
        $data['title'] = "Satta Matka";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('subadmin.satta-matka.edit',$data);
    }

    public function update(Request $request)
    {
    //  dd($request->all());
        $request->validate([
        //    'title' => 'required',
            'description' => 'required',
        ]);
        //  echo "<pre>";print_r($request->all());die;
        $abouts = SattaMatka::find($request->id);
        $abouts->description = $request->description;
        $abouts->save();
        // dd($user->toArray());
        session()->flash('success', 'Satta Matka Description has been Update !!');
        return redirect()->route('subadmin.SattaMatka.edit');
    }



    
}
