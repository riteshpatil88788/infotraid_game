<!DOCTYPE html>
<html lang="zxx">
   <head>
      <meta charset="utf-8">
      <meta name="csrf-token" content="{{ csrf_token() }}">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="{{url('front-assets/css/bootstrap.min.css')}}">
      <link rel="stylesheet" href="{{url('front-assets/css/flaticon.css')}}">
      <link rel="stylesheet" href="{{url('front-assets/css/remixicon.css')}}">
      <link rel="stylesheet" href="{{url('front-assets/css/owl.carousel.min.css')}}">
      <link rel="stylesheet" href="{{url('front-assets/css/odometer.min.css')}}">
      <link rel="stylesheet" href="{{url('front-assets/css/aos.css')}}">
      <link rel="stylesheet" href="{{url('front-assets/css/style.css')}}">
      <link rel="stylesheet" href="{{url('front-assets/css/dark-theme.css')}}">
      <link rel="stylesheet" href="{{url('front-assets/css/responsive.css')}}">
      <link rel="stylesheet" type="text/css" href="https://site-assets.fontawesome.com/releases/v6.1.0/css/all.css">
      <title>Indore Makta</title>
      <link rel="icon" type="image/png" href="{{url('front-assets/img/new/faviidream.png')}}">
   </head>
   <body>
      <div class="page-wrapper">
        @include('include.header')
        @yield('content')
        @include('include.footer')
        </div>
        <a href="javascript:void(0)" class="back-to-top bounce"><i class="ri-arrow-up-s-line"></i></a>
        <script src="{{url('front-assets/js/jquery.min.js')}}"></script>
        <script src="{{url('front-assets/js/bootstrap.bundle.min.js')}}"></script>
        <script src="{{url('front-assets/js/form-validator.min.js')}}"></script>
        <script src="{{url('front-assets/js/contact-form-script.js')}}"></script>
        <script src="{{url('front-assets/js/aos.js')}}"></script>
        <script src="{{url('front-assets/js/owl.carousel.min.js')}}"></script>
        <script src="{{url('front-assets/js/jquery.appear.js')}}"></script>
        <script src="{{url('front-assets/js/odometer.min.js')}}"></script>
        <script src="{{url('front-assets/js/fslightbox.js')}}"></script>
        <script src="{{url('front-assets/js/tweenmax.min.js')}}"></script>
        <script src="{{url('front-assets/js/main.js')}}"></script>
  
@yield('script')
<script>
  

const tabs = document.querySelector(".wrapper");

const tabButton = document.querySelectorAll(".tab-button");

const contents = document.querySelectorAll(".content");



tabs.onclick = e => {

const id = e.target.dataset.id;

if (id) {

 tabButton.forEach(btn => {

   btn.classList.remove("active");

 });

 e.target.classList.add("active");



 contents.forEach(content => {

   content.classList.remove("active");

 });

 const element = document.getElementById(id);

 element.classList.add("active");

}

}

</script>

</body>
</html>