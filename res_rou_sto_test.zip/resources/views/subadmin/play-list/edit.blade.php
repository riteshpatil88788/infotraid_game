@extends('subadmin.layout.app')
@section('content')
<div class="page-wrapper" style="min-height: 366px;">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-xl-12">

                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Edit {{$title}}</h3>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="bank-inner-details">
                            <div class="row">
                           
                                <div class="col-lg-12 col-md-12">
                                    <form id="formSubmit" action="{{ route('subadmin.playlist.update')}}" method="post" enctype="multipart/form-data">
                                        @csrf
                                     <input type="hidden"  name="id" value="{{$playlist->id}}" />
                                     <div class="row">
                                     <div class="col-lg-12 col-md-12">
                                                <div class="form-group ">
                                                    <label>Game Name<span class="login-danger">*</span></label>
                                                    <select class="form-control" name="title" id="selectcategory">
                                                        <option>Select Game</option>
                                                        @foreach($matkaresults as $matkaresult)
                                                        <option value="{{ $matkaresult->title }}" {{ $matkaresult->title == $playlist->title ? 'selected' : '' }}>{{ $matkaresult->title }}</option>
                                                        @endforeach
                                                    </select>
                                                    @error('title')
                                                    <p style="color:red;">{{ $message }}</p>
                                                    @enderror
                                                </div>
                                            </div>
                                          <div class="col-lg-12 col-md-12">
                                            <div class="form-group">
                                                <label>Play List<span class="login-danger">*</span></label>
                                                <div>
                                                    @php
                                                        $playArray = explode(',', $playlist->play ?? '');
                                                    @endphp
                                                    
                                                     @foreach($plays as $play)
                                                      <label class="mr-1"> <input type="checkbox" name="play[]" value="{{$play->title}}" {{ in_array($play->title, $playArray) ? 'checked' : '' }}>{{ $play->title}}</label><br>
                                                      @endforeach
                                                    
                                                  </div>
                                                  @error('play')
                                                      <p style="color:red;">{{ $message }}</p>
                                                  @enderror
                                            </div>
                                        </div>

                                        </div>
                                        <div class="bank-details-btn ">
                                            <button type="submit" class="btn bank-cancel-btn me-2">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
