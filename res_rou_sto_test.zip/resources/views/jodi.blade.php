<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indore Bazar</title>
    <meta name="description" content="We Provide the fastest updated kalyan chart,our kalyan chart has all old 2018 2019 kalyan matka jodi records, check out our kalyan chart now.">
    <link rel="stylesheet" href="{{ asset('front-assets/style.css') }}">
    <link rel="stylesheet" href="https://storage.googleapis.com/sattamatka-cdn-bucket/index_files/bootstrap.min.css">
    <style>
        .showinred {
            color: red;
        }
        
        .container {
            width: 100%;
            padding: 15px;
            margin: 0 auto;
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            max-width: 100%;
            margin-bottom: 1rem;
        }

        @media (max-width: 768px) {
            table {
                font-size: 14px;
            }
            .timebazar {
                font-size: 20px;
            }
        }

        @media (max-width: 576px) {
            table {
                font-size: 12px;
            }
            .timebazar {
                font-size: 18px;
            }
            .go-to-bottom,
            .go-to-top {
                padding: 8px 15px;
                font-size: 14px;
            }
        }

        .footer-last {
            padding: 20px;
        }

        .ftr-btn {
            margin: 10px;
        }

        .my-btnn-l {
            display: inline-block;
            margin: 5px;
        }

        .my-btnn-l a {
            color: white;
            text-decoration: none;
        }
    </style>
</head>
<body id="fcontent">
    <script data-cfasync="false" src="{{ asset('tbutton.js') }}"></script>
    <div class="container">
        <div id="banner">
            <div class="header">
              <a href="{{url('/')}}">
                <img class="logo ptb-10 mb-0" src="{{url('front-assets/images/logo.jpg')}}" alt="SattaMatka">
              </a>
            </div>
            <div class="satta-matka-jodi-subtitle">
                <h1>Complete {{$titlejodi}} jodi chart of satta matka</h1>
                <h2>We are proud to present you the {{$titlejodi}} jodi chart, this {{$titlejodi}} chart contains detailed history of jodi records of every year including 2018 and 2019,Our charts are always updated the first in the industry. Our {{$titlejodi}} chart has been published in various newspapers and is the official repository of {{$titlejodi}} matka, we are also the oldest running and most popular site due to our well updated charts of various markets like {{$titlejodi}} matka. Presented by our {{$titlejodi}} matka expert Dr. Admin sir. The records of this {{$titlejodi}} chart have been carefully collected by our satta matka guru it cotains all jodi records and is updated as soon as the {{$titlejodi}} result is declared.</h2>
            </div>
            <div class="text-center my-3">
                <a href="javascript:void(0);" class="btn btn-primary go-to-bottom" onclick="bottomFunction()">Go To Bottom</a>
            </div>
        </div>

        <div class="card" style="background-color: #1b2a49; border: 2px solid #7d0506;">
            <div class="card-body text-center">
                <h2 class="timebazar text-white">TIME BAZAR</h2>
                <div class="table-responsive">
                    <table class="table table-bordered bg-white">
                        <thead>
                            <tr>
                                <th>Monday</th>
                                <th>Tuesday</th>
                                <th>Wednesday</th>
                                <th>Thursday</th>
                                <th>Friday</th>
                                <th>Saturday</th>
                                <th>Sunday</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                use Carbon\Carbon;
                                $weeks = [];
                                foreach ($results as $result) {
                                    $date = $result->created_at ? Carbon::parse($result->created_at) : null;
                                    if ($date) {
                                        $week = $date->weekOfYear;
                                        $dayOfWeek = $date->dayOfWeekIso - 1;
                                        
                                        $resultpatta1 = $result->patta1 ? array_sum(str_split($result->patta1)) : null;
                                        $digitSumPatta1 = $resultpatta1 ? $resultpatta1 % 10 : '*';
                                        
                                        $resultpatta2 = $result->patta2 ? array_sum(str_split($result->patta2)) : null;
                                        $digitSumPatta2 = $resultpatta2 ? $resultpatta2 % 10 : '*';
                                        
                                        $weeks[$week][$dayOfWeek][] = [
                                            'patta1' => $digitSumPatta1,
                                            'patta2' => $digitSumPatta2,
                                        ];
                                    }
                                }
                            @endphp

                            @foreach ($weeks as $week => $weekData)
                                @php
                                    $maxEntries = max(array_map('count', $weekData));
                                @endphp

                                @for ($entry = 0; $entry < $maxEntries; $entry++)
                                    <tr>
                                        @for ($day = 0; $day < 7; $day++)
                                            @php
                                                $dayData = $weekData[$day][$entry] ?? null;
                                             
                                $combinedValue = ($dayData['patta1'] ?? '*') . ($dayData['patta2'] ?? '*');
                                $highlightValues = ['00', '05', '11', '16', '22', '27', '33', '38', '44', '49', '50', '55', '61', '66', '72', '77', '83', '88', '94', '99', '**'];
                                $isHighlighted = in_array($combinedValue, $highlightValues);
                          
                                            @endphp
                                            <td class="{{ $isHighlighted ? 'text-danger' : '' }}">
                                                @if ($dayData)
                                                    {{ $combinedValue }}
                                                @else
                                                    **
                                                @endif
                                            </td>
                                        @endfor
                                    </tr>
                                @endfor
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="text-center mt-4">
            <div class="top_button">
                <a href="javascript:void(0);" class="btn btn-primary go-to-top" onclick="topFunction()">Go To Top</a>
            </div>
        </div>

        <footer class="footer-last text-center">
            <h4 class="text-primary font-weight-bold">
                AD Boss Satta Matka <br> 
                ALL RIGHTS RESERVED <br>
                (2024-2025) <br>
                CONTACT ADMIN <br>
                *** <br>
            </h4>
            <div class="d-flex justify-content-center">
                <button class="btn btn-primary my-btnn-l ftr-btn" style="background:#0000;">
                    <a href="javascript:history.go(-1)">BACK</a>
                </button>
                <button class="btn btn-primary btn-orange my-btnn-l ftr-btn" style="background:red;">
                    <a href="{{ url('/') }}">HOME</a>
                </button>
            </div>
        </footer>

    </div>

    <script src="https://storage.googleapis.com/sattamatka-cdn-bucket/index_files/jquery.min.js"></script>
</body>
</html>