@extends('admin.layout.app')
@section('content')
<div class="page-wrapper" style="min-height: 366px;">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-xl-12">

                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Edit {{$title}}</h3>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="bank-inner-details">
                            <div class="row">
                           
                                <div class="col-lg-12 col-md-12">
                                    <form id="formSubmit" action="{{ route('admin.play.update')}}" method="post" enctype="multipart/form-data">
                                        @csrf
                                     <input type="hidden"  name="id" value="{{$play->id}}" />
                                     <div class="row">
                                     <div class="col-lg-12 col-md-12 ">
                                                <div class="form-group">
                                                    <label>Title<span class="text-danger">*</span></label>
                                                    <input type="text" name="title" class="form-control" value="{{ $play->title }}">
                                                </div>
                                                @error('title')
                                                <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                            </div>
                                     <div class="col-lg-12 col-md-12">
                                        <div class="form-group ">
                                            <label>Upload Image<span class="text-danger">*</span></label>
                                               <input type="file" class="form-control" name="image">
                                                @if(!empty(@$play->image))
                                                <img src="{{url('images/'.@$play->image ) }}" width="150px">
                                                @else

                                                @endif
                                            @error('image')
                                                     <p  style="color:red;">{{ $message }}</p>
                                            @enderror
                                            </div>
                                        </div>
                                         <div class="col-lg-12 col-md-12">
                                        <div class="form-group ">
                                            <!--<label>Game Type<span class="text-danger">*</span></label>-->
                                            <!--  <select class="form-control" name="type">-->
                                            <!--      <option value="open" {{ $play->type == "open" ? 'selected' : '' }}>Open</option>-->
                                            <!--       <option value="close" {{ $play->type == "close" ? 'selected' : '' }}>Close</option>-->
                                            <!--        <option value="mid" {{ $play->type == "mid" ? 'selected' : '' }}>Mid</option>-->
                                            <!--  </select>-->
                                            <label>
                                                <input type="checkbox" name="type[]" value="open" {{ in_array('open',explode(",",$play->type)) ? 'checked' : '' }}> Open
                                            </label><br>
                                            <label>
                                                <input type="checkbox" name="type[]" value="close" {{ in_array('close',explode(",",$play->type)) ? 'checked' : '' }}> Close
                                            </label><br>
                                            <label>
                                                <input type="checkbox" name="type[]" value="mid" {{ in_array('mid',explode(",",$play->type)) ? 'checked' : '' }}> Mid
                                            </label><br>
                                            </div>
                                        </div>
                                        </div>
                                        </div>
                                        <div class="bank-details-btn ">
                                            <button type="submit" class="btn bank-cancel-btn me-2">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
