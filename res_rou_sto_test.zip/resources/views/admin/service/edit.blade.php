@extends('admin.layout.app')
@section('content')
<div class="page-wrapper" style="min-height: 366px;">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Edit {{$title}}</h3>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="bank-inner-details">
                            <div class="row align-items-center">
                                <div class="col-lg-12 col-md-12">
                                    <form id="formSubmit" action="{{ route('service.update')}}" method="post" enctype="multipart/form-data">
                                        @csrf
                                        <input type="hidden"  name="id" value="{{$service->id}}" />
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12">
                                                <div class="form-group ">
                                                    <label>Category<span class="login-danger">*</span></label>
                                                    <select class="form-control" name="category" id="selectcategory">
                                                        <option>Select Category</option>
                                                        @foreach($categories as $category)
                                                        <option value="{{ $category->id }}" {{ $category->id == $service->category ? 'selected' : '' }}>{{ $category->title }}</option>
                                                        @endforeach
                                                    </select>
                                                    @error('category')
                                                    <p style="color:red;">{{ $message }}</p>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-lg-12 col-md-12">
                                                <div class="form-group ">
                                                    <label>Sub Category<span class="login-danger">*</span></label>
                                                    <select class="form-control" name="subcategory" id="subcategory">
                                                        <option>Select Sub Category </option>
                                                        @foreach($subcategories as $subcategory)
                                                        <option value="{{ $subcategory->id }}" {{ $subcategory->id ==  $service->sub_category ? 'selected' : '' }}>{{$subcategory->title}}</option>
                                                        @endforeach
                                                    </select>
                                                    @error('subcategory')
                                                    <p style="color:red;">{{ $message }}</p>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-lg-12 col-md-12 d-none">
                                                <div class="form-group">
                                                    <label>Title<span class="text-danger">*</span></label>
                                                    <input type="text" name="title" class="form-control" value="{{ $service->title }}">
                                                </div>
                                                @error('title')
                                                <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                            </div>
                                            <div class="col-lg-12 col-md-12">
                                                <div class="form-group">
                                                    <label>Product Description<span class="text-danger">*</span></label>
                                                    <textarea type="text" name="product_description" class="form-control tinymce" id="editor1" >{{ $service->product_description }}</textarea>
                                                </div>
                                                @error('product_description')
                                                <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                            </div>
                                            <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Investment Description<span class="text-danger">*</span></label>
                                                 <textarea type="text" name="investment_description" class="form-control tinymce" id="editor1" >{{ $service->investment_description }}</textarea>
                                              </div>
                                                @error('investment_description')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>Weekly</label>
                                                <input type="text" name="weekly" id="weekly" class="form-control" value="{{ $service->weekly }}">
                                            </div>
                                            @error('weekly')
                                            <p style="color:red;">{{ $message }}</p>
                                            @enderror
                                        </div>
                                        <div class="col-2 mt-5">
                                            <div class="form-group">
                                                <input type="checkbox" id="weeklycheck" {{ $service->weeklygst ? 'checked' : '' }}>
                                                <label for="weeklycheck">Weekly GST</label>
                                            </div>
                                        </div>
                                        <div class="col-4" id="weeklygst" style="{{ $service->weeklygst ? '' : 'display: none;' }}">
                                            <div class="form-group">
                                                <label></label>
                                                <input type="text" name="weeklygst" class="form-control" value="{{ $service->weeklygst ? $service->weeklygst : '' }}" readonly>
                                            </div>
                                            @error('weekly')
                                            <p style="color:red;">{{ $message }}</p>
                                            @enderror
                                        </div>
                                        <!-- Monthly Section -->
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>Monthly</label>
                                                <input type="text" name="monthly" id="monthly" class="form-control" value="{{ $service->monthly }}">
                                            </div>
                                            @error('monthly')
                                            <p style="color:red;">{{ $message }}</p>
                                            @enderror
                                        </div>
                                        <div class="col-2 mt-5">
                                            <div class="form-group">
                                                <input type="checkbox" id="monthlycheck" {{ $service->monthlygst ? 'checked' : '' }}>
                                                <label for="monthlycheck">Monthly GST</label>
                                            </div>
                                        </div>
                                        <div class="col-4" id="monthlygst" style="{{ $service->monthlygst ? '' : 'display: none;' }}">
                                            <div class="form-group">
                                                <label></label>
                                                <input type="text" name="monthlygst" class="form-control" value="{{ $service->monthlygst ? $service->monthlygst : '' }}" readonly>
                                            </div>
                                        </div>
                                        <!-- Quarterly Section -->
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>Quarterly</label>
                                                <input type="text" name="quarterly" id="quarterly" class="form-control" value="{{ $service->quarterly }}">
                                            </div>
                                            @error('quarterly')
                                            <p style="color:red;">{{ $message }}</p>
                                            @enderror
                                        </div>
                                        <div class="col-2 mt-5">
                                            <div class="form-group">
                                                <input type="checkbox" id="quarterlycheck" {{ $service->quarterlygst ? 'checked' : '' }}>
                                                <label for="quarterlycheck">Quarterly GST</label>
                                            </div>
                                        </div>
                                        <div class="col-4" id="quarterlygst" style="{{ $service->quarterlygst ? '' : 'display: none;' }}">
                                            <div class="form-group">
                                                <label></label>
                                                <input type="text" readonly name="quarterlygst" class="form-control" value="{{ $service->quarterlygst ? $service->quarterlygst : '' }}">
                                            </div>
                                        </div>
                                        <!-- Half Yearly Section -->
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>Half Yearly</label>
                                                <input type="text" name="half_yearly" id="half_yearly" class="form-control" value="{{ $service->half_yearly }}">
                                            </div>
                                        </div>
                                        <div class="col-2 mt-5">
                                            <div class="form-group">
                                                <input type="checkbox" id="half_yearlycheck" {{ $service->half_yearlygst ? 'checked' : '' }}>
                                                <label for="half_yearlycheck">Half Yearly GST</label>
                                            </div>
                                        </div>
                                        <div class="col-4" id="half_yearlygst" style="{{ $service->half_yearlygst ? '' : 'display: none;' }}">
                                            <div class="form-group">
                                                <label></label>
                                                <input type="text" readonly name="half_yearlygst" class="form-control" value="{{ $service->half_yearlygst ? $service->half_yearlygst : '' }}">
                                            </div>
                                        </div>
                                        <!-- Yearly Section -->
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>Yearly</label>
                                                <input type="text" name="yearly" id="yearly" class="form-control" value="{{ $service->yearly }}">
                                            </div>
                                            @error('yearly')
                                            <p style="color:red;">{{ $message }}</p>
                                            @enderror
                                        </div>
                                        <div class="col-2 mt-5">
                                            <div class="form-group">
                                                <input type="checkbox" id="yearlycheck" {{ $service->yearlygst ? 'checked' : '' }}>
                                                <label for="yearlycheck">Yearly GST</label>
                                            </div>
                                        </div>
                                        <div class="col-4" id="yearlygst" style="{{ $service->yearlygst ? '' : 'display: none;' }}">
                                            <div class="form-group">
                                                <label></label>
                                                <input type="text" readonly name="yearlygst" class="form-control" value="{{ $service->yearlygst ? $service->yearlygst : '' }}">
                                            </div>
                                        </div>
                                        <span id="error-messages"></span>
                                        <div class="bank-details-btn ">
                                            <button type="submit" class="btn bank-cancel-btn me-2">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
<script>
    $(document).ready(function() {
        
        $('#selectcategory').change(function() {
        
            var selectedValue = $(this).val();
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                url: "{{ route('service.selectcategoty') }}",
                method: 'POST',
                data: {
                    value: selectedValue,
                    _token: csrfToken
                },
                success: function(response) {
                    $('#subcategory').html(response.subcategory);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    
        $(document).ready(function() {
            function toggleGST(checkboxId, gstDivId, gstInputName) {
                $(checkboxId).change(function() {
                    if (this.checked) {
                        $(gstDivId).show();
                        $(`input[name="${gstInputName}"]`).val('+18 GST');
                    } else {
                        $(gstDivId).hide();
                        $(`input[name="${gstInputName}"]`).val('');
                    }
                });
            }
    
            toggleGST('#weeklycheck', '#weeklygst', 'weeklygst');
            toggleGST('#monthlycheck', '#monthlygst', 'monthlygst');
            toggleGST('#quarterlycheck', '#quarterlygst', 'quarterlygst');
            toggleGST('#half_yearlycheck', '#half_yearlygst', 'half_yearlygst');
            toggleGST('#yearlycheck', '#yearlygst', 'yearlygst');
    
    
            function restrictToNumbers(inputId) {
                $(inputId).on('input', function() {
                    this.value = this.value.replace(/[^0-9]/g, '');
                });
            }
    
            restrictToNumbers('#weekly');
            restrictToNumbers('#monthly');
            restrictToNumbers('#quarterly');
            restrictToNumbers('#half_yearly');
            restrictToNumbers('#yearly');
    
    
        });
    
        $("#formSubmit").submit(function(e) {
            $(".interval-error").remove(); // Remove existing error messages
    
            // Check if at least one interval field is filled
            var weekly = $("#weekly").val().trim();
            var monthly = $("#monthly").val().trim();
            var quarterly = $("#quarterly").val().trim();
            var half_yearly = $("#half_yearly").val().trim();
            var yearly = $("#yearly").val().trim();
    
            // Array to hold error messages
            var errors = [];
    
            // Check each interval field
            if (weekly === "" && monthly === "" && quarterly === "" && half_yearly === "" && yearly === "") {
                errors.push("At least one interval field is required.");
            }
    
            // If there are errors, prevent form submission and display errors
            if (errors.length > 0) {
                e.preventDefault(); // Prevent form submission
                for (var i = 0; i < errors.length; i++) {
                    $("#error-messages").append('<p class="interval-error" style="color: red;">' + errors[i] + '</p>');
                }
            }
        });
    
    
    });
    
    
     
</script>
@endsection