<div class="header">
<div class="header-left">
 <img src="{{ url('front-assets/images/logo.jpg')}}" width="200px">
</div>
    
<div class="top-nav-search">

</div>
<a class="mobile_btn" id="mobile_btn">
<i class="fas fa-bars"></i>
 <img src="{{ url('front-assets/images/logo.jpg')}}" width="200px">
</a>

    <ul class="nav user-menu">

        <li class="nav-item dropdown has-arrow new-user-menus">

            <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">

                <span class="user-img">

<img class="rounded-circle" src="{{ url('assets/img/icons/dash-icon-01.svg')}}" width="31" alt="Ryan Taylor">

<div class="user-text">

<h6>{{ ucfirst(Auth::guard('admin')->name) }}</h6>

</div>

</span>

    </a>

      <div class="dropdown-menu">

          <a class="dropdown-item" href="{{ route('admin.Adminlogout') }}" onclick="event.preventDefault(); document.getElementById('logout').submit();">Log Out</a>

        <form id="logout" action="{{ route('admin.Adminlogout') }}" method="get" style="display: none;">



        @csrf



    </form>



</div>



        </li>



    </ul>



</div>