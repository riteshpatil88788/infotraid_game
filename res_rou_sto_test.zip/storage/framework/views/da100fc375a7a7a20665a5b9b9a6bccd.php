 <?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content container-fluid">



        <div class="row">
            <div class="col-sm-12">
                <div class="card card-table">
                    <div class="card-body">

                        <div class="page-header">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="page-title"><?php echo e($title); ?></h3>
                                </div>
                                <!--<div class="col-auto text-end float-end ms-auto download-grp">-->
                                <!--    <a href="" class="btn btn-primary"><i class="fas fa-plus"></i></a>-->
                                <!--</div>-->
                            </div>
                        </div>
                        <?php if(session('success')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table border-0 star-student table-hover table-center mb-0 datatable table-striped">
                                <thead class="student-thread">
                                    <tr>
                                        <th>S.No</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Status</th>
                                      
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1;?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->phone); ?></td>
                                        <td> 
                                        <div class="form-check form-switch">
                                              <input class="form-check-input statusCheck" type="checkbox"  id="statusCheck" data-id="<?php echo e($user->id); ?>" <?php echo e($user->experts ? 'checked' : ''); ?>>
                                        </div>
                                        </td>
                                       
                                        
                                    </tr>
                                    <?php $i++;?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(document).ready(function() {
      
        $('.statusCheck').change(function() {
            
            var id = $(this).data('id');
            var status = $(this).prop('checked') ? 1 : 0;
            var confirmationMessage = status == 1 ? 'Are you sure you want to active?' : 'Are you sure you want to inactive?';
            if (confirm(confirmationMessage)) {
                $.ajax({
                    url: '<?php echo e(route("admin.user.status")); ?>',
                    method: 'POST',
                    data: {
                        id: id,
                        status: status,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        console.log('Status updated successfully.');
                       
                    },
                    error: function(xhr) {
                        console.error('Error updating status.');
                    }
                });
            } else {
                $(this).prop('checked', !status);
            }
        });
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/admin/user.blade.php ENDPATH**/ ?>