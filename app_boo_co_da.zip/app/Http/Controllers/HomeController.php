<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\{Service,Category,Regulatory,StandardWarning,SubCategory,Jobapply,JobDetail,ServiceCategory,About,Refund,Disclaimer,Privacy,Disclosure,Terms,Faq,Investor,Grievance,Contact,Enquiry,TrialEnquiry,Complaint,QRcode,Bank,Career,ServiceAgreement};
use DB;
use Mpdf\Mpdf;
use Dompdf\Dompdf;
use Dompdf\Options;
use Illuminate\Support\Facades\Validator;
use GuzzleHttp\Client;
use App\Mail\KycMail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use App\Models\{MatkaResult,Notice,KnowAbout,SattaMatka,HeaderDes,FastestLiveUpdate,KnowDes,Result};

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }
    
    public function index()
    {
        $today = Carbon::today();
        $data['matkaresults'] = MatkaResult::groupBy('title')->latest()->get();
        $now = \Carbon\Carbon::now();
        $data['resultpatta'] = Result::
            where(function($query) use ($now) {
                $query->where('created_at', '>=', $now->copy()->subMinutes(45))
                      ->orWhere('updated_at', '>=', $now->copy()->subMinutes(45));
            })
            ->latest()
            ->get();
        // echo "<pre>";print_r($data['matkaresults']->toArray());die;
        $data['SattaMatkas'] = SattaMatka::first();
        $data['KnowAbouts'] = KnowAbout::first();
        $data['KnowDes'] = KnowDes::first();
        $data['Notices'] = Notice::first();
        $data['HeaderDes'] = HeaderDes::first();
        $data['FastestLiveUpdates'] = FastestLiveUpdate::first();
        
        
        // $to_name = 'Infotrain';
        // $to_email = "infotrain12@infotrain.shop";
        // $subject = 'Laravel Static Test Mail';
        // $messageBody = "This is a test email sent from Laravel without using a Blade view 12.";
        
        // Mail::raw($messageBody, function($message) use ($to_name, $to_email, $subject) {
        //     $message->to($to_email, $to_name)
        //             ->subject($subject)
        //             ->from('infotrain12@infotrain.shop', 'Infotrain'); // Match SMTP credentials
        // });

    
        
        
        
       //  echo "<pre>";print_r($matkaresult->toArray());die;
        return view('index',$data);
        
    }
    public function login()
    {
        return view('login');
    }
    public function register()
    {
        return view('register');
    }
    public function ResultGuessing()
    {
        $data['guessing'] = DB::table('guessings')
        ->join('users', 'guessings.user_id', '=', 'users.id')
        ->orderByDesc('guessings.id')
        ->paginate(10);

      //  dd($data['guessing']);
        return view('result-guessing-forum',$data);
    }
    
     public function gussingstore(Request $request){
         
         $request->validate([
        'exparts' => 'required',
        
    ]);

    $data = DB::table('guessings')->insert([
         'user_id' => Auth::user()->id,
         'description' => $request->exparts,
        ]);

    return response()->json(['message' => 'Form submitted successfully!']);
     }
     
    public function expertGuessing()
    {
        $data['experts'] = DB::table('guessings')
    ->join('users', 'guessings.user_id', '=', 'users.id')
    ->where('users.experts', 1)
    ->orderByDesc('guessings.id')
    ->paginate(10);

        // dd($data['experts']);
        return view('expert-forum',$data);
    }
    
  
     
     public function exportsstore(Request $request){
         
         $request->validate([
        'exparts' => 'required',
        
    ]);
   $user = DB::table('users')->where('id', Auth::user()->id)->where('experts', Auth::user()->experts)->first();
    if(Auth::user()->experts =! 1){
         return response()->route('home.expertGuessing');
    }
    $data = DB::table('guessings')->insert([
         'user_id' => Auth::user()->id,
         'description' => $request->exparts,
        ]);

    return response()->json(['message' => 'Form submitted successfully!']);
     }
    public function jodi($id)
    {
        $data['results'] = Result::where('matka_result_id',$id)->get();
        $data['matkaresult'] = MatkaResult::where('id',$id)->first();
        
        //   echo "<pre>";print_r($data['results']->toArray());die;
        $data['titlejodi'] = $data['matkaresult']->title;
     
    
        return view('jodi', $data);
    }
    
    public function panel($id)
    {
        $data['results'] = Result::where('matka_result_id',$id)->get();
        $data['matkaresult'] = MatkaResult::where('id',$id)->first();
        
        //   echo "<pre>";print_r($data['results']->toArray());die;
        $data['titlejodi'] = $data['matkaresult']->title;

       return view('panel',  $data);

    }
    
        public function ShowAlert(Request $request)
    {
        if (Auth::check()) {
            return response()->json([
                'success' => true,
            ]); // 200 status for success
        }
    
        return response()->json([
            'success' => false,
            'message' => 'Please login to quote or you don\'t have permission to quote.',
        ]); // 401 status for unauthorized
    }
        public function ExpertShowAlert(Request $request)
    {
        if (Auth::check()) {
            return response()->json([
                'success' => true,
            ]); // 200 status for success
        }
    
        return response()->json([
            'success' => false,
            'message' => 'Please login to quote or you don\'t have permission to quote.',
        ]); // 401 status for unauthorized
    }
    
        public function profile($id)
    {
       $data['user'] = DB::table('users')->where('id',$id)->first(); 
       $data['guessing'] = DB::table('guessings')
    ->where('user_id', $id)
    ->count();
        return view('profile', $data);
    }

  
 
    

    
}
