<?php



namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

use Illuminate\Database\Eloquent\Model;



class GameRate extends Model{

    use HasFactory;

    protected $table = "game_rates";



    protected $fillable = [

        'admin_id',
        'subadmin_id',
        'title',
        'unit',
        'rate',
        
       
       

    ];





    



}