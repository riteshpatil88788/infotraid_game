@extends('admin.layout.app')
@section('content')
<div class="page-wrapper">
    <div class="content container-fluid">



        <div class="row">
            <div class="col-sm-12">
                <div class="card card-table">
                    <div class="card-body">

                        <div class="page-header">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="page-title">{{$title}}</h3>
                                </div>
                                <div class="col-auto text-end float-end ms-auto download-grp">
                                    <!-- <a href="{{ route('service.create') }}" class="btn btn-primary"><i class="fas fa-plus"></i></a> -->
                                    <button id="download-csv" class="btn btn-primary">Download CSV</button>

                                </div>
                            </div>
                        </div>
                       
                        <div class="table-responsive">
                            <table class="table border-0 star-student table-hover table-center mb-0 datatable table-striped">
                                <thead class="student-thread">
                                    <tr>
                                        <th>S.No</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Category</th>
                                        <th>Sub Category</th>
                                        <th>Message</th>
                                        <th>Date</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1;?>
                                    @foreach($serviceCategory as $service)
                                    <tr>
                                        <td>{{$i}}</td>
                                        <td>
                                           {{ $service->name }}
                                        </td>
                                        <td>
                                           {{ $service->email }}
                                        </td>
                                        <td>
                                           {{ $service->phone }}
                                        </td>
                                        <td>
                                           {{ $service->category }}
                                        </td>
                                        <td>
                                           {{ $service->subcategory }}
                                        </td>
                                        <td>
                                           <!-- {{ $service->message }} -->
                                           <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#messageview" data-message="{{ $service->message }}">
                                                View
                                                </button>
                                        </td>
                                        <td>
                                           {{ date('Y-m-d',strtotime($service->created_at)) }}
                                        </td>
                                    </tr>
                                    <?php $i++;?>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="messageview" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Message</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Message
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
@endsection
@section('script')
<script>
$(document).ready(function() {
    $('#download-csv').click(function() {
        // Your CSV data headers
        var csvData = [
            ["Name", "Email", "phone","Category", "Sub Category", "Message", "Date"]
        ];

        // Loop through the PHP contacts data and add each contact to CSV data
        <?php foreach($serviceCategory as $service): ?>
        csvData.push([
            "<?php echo addslashes($service->name); ?>",
            "<?php echo addslashes($service->email); ?>",
            "<?php echo addslashes($service->phone); ?>",
            "<?php echo addslashes($service->category); ?>",
            "<?php echo addslashes($service->subcategory); ?>",
            "<?php echo addslashes(substr($service->message, 0, 50)); ?>\"",
            "<?php echo date('d-m-Y', strtotime($service->created_at)); ?>",
        ]);
        <?php endforeach; ?>

        // Convert array of arrays into CSV string
        var csvString = "";
        csvData.forEach(function(rowArray) {
            var row = rowArray.join(",");
            csvString += row + "\r\n";
        });

        // Create a Blob from the CSV string
        var blob = new Blob([csvString], { type: 'text/csv' });

        // Create a link element
        var link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = "service-category.csv";

        // Append the link to the body (required for Firefox)
        document.body.appendChild(link);

        // Programmatically click the link to trigger the download
        link.click();

        // Remove the link from the document
        document.body.removeChild(link);
    });
});

document.addEventListener('DOMContentLoaded', function () {
        var exampleModal = document.getElementById('messageview');
        exampleModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var message = button.getAttribute('data-message');
            var modalBody = exampleModal.querySelector('.modal-body');
            modalBody.textContent = message;
        });
    });
</script>
@endsection
