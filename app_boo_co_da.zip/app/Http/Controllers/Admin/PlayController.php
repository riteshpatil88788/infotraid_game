<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\Play;

class PlayController extends Controller
{
 
    public function index()
    {
        $data['matkaresults'] = DB::table('matka_results')->orderBy('id','desc')->groupBy('title')->get();
        $data['plays'] = DB::table('plays')->orderBy('id','desc')->get();
        $data['title'] = "Play";
        return view('admin.play.index',$data);
    }

    public function create(){
        $data['title'] = "Play";
        $data['matkaresults'] = DB::table('matka_results')->orderBy('id','desc')->groupBy('title')->get();
        return view('admin.play.create',$data);
    }

    public function store(Request $request)
    {
       
        $request->validate([
            'title' => 'required',
            'image' => 'required', 
        ]);
    
        $Play = new Play;
    
        $Play->title = $request->title;
        if($request->file('image')){
            $file = $request->file('image');
            $name = time(). '_' .$file->getClientOriginalName();
            $file->move(public_path('images'), $name);
            $Play->image = $name;
        }
        $Play->type = implode(",",$request->type);
        $Play->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $Play->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;
        $Play->save();
    
        session()->flash('success', 'Play has been created !!');
        return redirect()->route('admin.play.index');
    }
    

    public function edit($id){
        $data['play'] = DB::table('plays')->where('id',$id)->first();
        $data['matkaresults'] = DB::table('matka_results')->orderBy('id','desc')->groupBy('title')->get();
        $data['title'] = "Play";
        // echo "<pre>";print_r($abouts->toArray());die;
        return view('admin.play.edit',$data);
    }

    public function update(Request $request)
    {
        //  dd($request->all());
        $request->validate([
            'title' => 'required',
           
        ]);
        if($request->file('image')){
            $request->validate([
                'image' => 'required',
            
            ]);
        }
        //  echo "<pre>";print_r($request->all());die;
        $Play = Play::find($request->id);
        $Play->title = $request->title;
        if($request->file('image')){
            $file = $request->file('image');
            $name = time(). '_' .$file->getClientOriginalName();
            $file->move(public_path('images'), $name);
            $Play->image = $name;
        }
        $Play->type = implode(",",$request->type);
        $Play->admin_id = Auth::guard('admin')->check() ? Auth::guard('admin')->user()->id : null;
        $Play->subadmin_id = Auth::guard('subadmin')->check() ? Auth::guard('subadmin')->user()->id : null;
        $Play->save();
        // dd($user->toArray());
        session()->flash('success', 'Play has been Update !!');
        return redirect()->route('admin.play.index');
    }

    public function destroy($id){
       
       
        $play = Play::find($id);
     
        $play->delete();
        session()->flash('success', 'Plays has been Deleted !!');
        return redirect()->route('admin.play.index');
    }

    
}
