<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\{UserController,SattaMatkaController,PlayController,GameRateController,NoticeController,MatkaResultController,KnowDesController,KnowAboutController,FastestLiveUpdateController,HeaderController};

Route::get('login', function () {
    return response()->json(['status' => false,'date' => [],'message' => 'Unauthorized User'],404);
})->name('login');
Route::post('/register', [UserController::class, 'register']);
Route::post('/login', [UserController::class, 'login']);
Route::post('forgot-password', [UserController::class, 'sendResetLinkEmail']);

// echo 12;die;
Route::post('reset-password', [UserController::class, 'reset']);
// Routes that require the user to be authenticated
Route::post('/withdraw_callback', [UserController::class, 'withdraw_callback'])->name('withdraw.callback');
Route::middleware('auth:sanctum')->group(function () {
    Route::get('/user', [UserController::class, 'user']);
    Route::post('/logout', [UserController::class, 'logout']);
    Route::get('/notice', [NoticeController::class, 'index']);
    Route::get('/matka-result', [MatkaResultController::class, 'index']);
    Route::get('/home-list', [MatkaResultController::class, 'homelist']);
    Route::get('/jodi', [MatkaResultController::class, 'jodi']);
    Route::get('/panel', [MatkaResultController::class, 'panel']);
    Route::get('/live-update', [MatkaResultController::class, 'liveUpdate']);
    Route::post('/change-password', [UserController::class, 'changePassword']);
    Route::get('/satta-matka', [SattaMatkaController::class, 'index']);
    Route::get('/know-des', [KnowDesController::class, 'index']);
    Route::get('/know-about', [KnowAboutController::class, 'index']);
    Route::get('/fastest-live-update', [FastestLiveUpdateController::class, 'index']);
    Route::get('/header', [HeaderController::class, 'index']);
    Route::get('/game-rate', [GameRateController::class, 'index']);
    Route::get('/play-list', [PlayController::class, 'index']);
    Route::post('/game-data-store', [PlayController::class, 'GameDatastore']);
    
    Route::get('/time-table', [MatkaResultController::class, 'timeTable']);
    Route::post('/wallet', [UserController::class, 'wallet']);
    Route::post('/withdrawal', [UserController::class, 'withdrawal']);
    Route::get('/wallet-history', [UserController::class, 'walletHistory']);
    Route::get('/withdrawal-history', [UserController::class, 'withdrawalHistory']);
    Route::post('/bank-detail', [UserController::class, 'bankDetail']);
    Route::post('/bank-detail-update', [UserController::class, 'bankDetailupdate']);
    Route::get('/profile', [UserController::class, 'profile']);
    Route::post('/profile-update', [UserController::class, 'profileupdate']);
    Route::get('/get_wallet', [UserController::class, 'get_wallet']);
    Route::get('/winning-history', [UserController::class, 'winnerlist']);
    Route::get('/bid-history', [UserController::class, 'bidlist']);
    Route::get('/passbook', [UserController::class, 'passbook']);
    
    Route::post('/single-ank', [PlayController::class, 'singleAnk']);
    Route::post('/jodi', [PlayController::class, 'jodi']);
    Route::post('/single-pana', [PlayController::class, 'singlepana']);
    Route::post('/double-pana', [PlayController::class, 'doublepana']);
    Route::post('/triple-pana', [PlayController::class, 'triplepana']);
    Route::post('/pana-family', [PlayController::class, 'panafamily']);
    Route::post('/sp-dp-tp', [PlayController::class, 'SpDpTp']);
    Route::post('/two-digit-pana', [PlayController::class, 'twoDigitPana']);
    Route::post('/sp-motor', [PlayController::class, 'SpMotor']);
    Route::post('/dp-motor', [PlayController::class, 'DpMotor']);
    Route::post('/odd-even', [PlayController::class, 'OddEven']);
    Route::post('/red-jodi', [PlayController::class, 'red_jodi']);
    Route::post('/jodi-family', [PlayController::class, 'jodi_family']);
    Route::post('/digitbasejodi', [PlayController::class, 'digitbasejodi']);
    Route::post('/halfsangamA', [PlayController::class, 'halfsangam1']);
    Route::post('/halfsangamB', [PlayController::class, 'halfsangam2']);
    Route::post('/fullsangam', [PlayController::class, 'fullsangam']);
 
 
});



