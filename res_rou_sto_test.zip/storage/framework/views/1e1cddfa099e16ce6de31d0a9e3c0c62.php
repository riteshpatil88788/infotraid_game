<?php $__env->startSection('content'); ?>
<div class="page-wrapper" style="min-height: 366px;">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-xl-12">

                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Edit <?php echo e($title); ?></h3>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="bank-inner-details">
                            <div class="row">
                           
                                <div class="col-lg-12 col-md-12">
                                    <form id="formSubmit" action="<?php echo e(route('admin.result.update')); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                     <input type="hidden"  name="id" value="<?php echo e($result->id); ?>" />
                                     <div class="row">
                                     <div class="col-lg-12 col-md-12">
                                                <div class="form-group ">
                                                    <label>Game Name<span class="login-danger">*</span></label>
                                                    <select class="form-control" name="matka_result_id" id="selectcategory" required>
                                                        <option value="">Select Game</option>
                                                        <?php $__currentLoopData = $matkaresults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matkaresult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($matkaresult->id); ?>" <?php echo e($matkaresult->id == $result->matka_result_id ? 'selected' : ''); ?>><?php echo e($matkaresult->title); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['matka_result_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <p style="color:red;"><?php echo e($message); ?></p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                          <div class="col-lg-12 col-md-12">
                                            <div class="form-group">
                                            <label>Patta1<span class="login-danger">*</span></label>
                                            <input type="text" name="patta1" class="form-control" id="patta1" value="<?php echo e($result->patta1); ?>" readonly>
                                                  <?php $__errorArgs = ['patta1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                      <p style="color:red;"><?php echo e($message); ?></p>
                                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <div>
                                            </div>
                                             <div class="col-lg-12 col-md-12">
                                            <div class="form-group">
                                            <label>Patta2<span class="login-danger">*</span></label>
                                            <input type="text" name="patta2" class="form-control" id="patta2" value="<?php echo e($result->patta2); ?>">
                                                  <?php $__errorArgs = ['patta2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                      <p style="color:red;"><?php echo e($message); ?></p>
                                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <div>
                                            </div>
                                        </div>
                                        </div>
                                        <div class="bank-details-btn ">
                                            <button type="submit" class="btn bank-cancel-btn me-2">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/admin/result/edit.blade.php ENDPATH**/ ?>