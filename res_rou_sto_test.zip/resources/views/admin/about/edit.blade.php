@extends('admin.layout.app')
@section('content')
<div class="page-wrapper" style="min-height: 366px;">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-xl-12">

                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Edit {{$title}}</h3>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="bank-inner-details">
                            <div class="row">
                            @if (session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                @endif

                                <div class="col-lg-12 col-md-12">
                                    <form id="formSubmit" action="{{ route('about.update')}}" method="post" enctype="multipart/form-data">
                                        @csrf
                                     <input type="hidden"  name="id" value="{{@$about->id}}" />
                                     <div class="row">
                                           <div class="col-lg-12 col-md-12 d-none">
                                              <div class="form-group">
                                                 <label>Title<span class="text-danger">*</span></label>
                                                 <input type="text" name="title" class="form-control" value="{{ @$about->title }}">
                                              </div>
                                                @error('title')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                          <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Description<span class="text-danger">*</span></label>
                                                 <textarea type="text" name="description" class="form-control tinymce" id="editor1" >{{ @$about->description }}</textarea>
                                              </div>
                                                @error('description')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                          <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Description 1<span class="text-danger">*</span></label>
                                                 <textarea type="text" name="description1" class="form-control tinymce" id="editor1" >{{ @$about->description1 }}</textarea>
                                              </div>
                                                @error('description1')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                          <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Description 2<span class="text-danger">*</span></label>
                                                 <textarea type="text" name="description2" class="form-control tinymce" id="editor1" >{{ @$about->description2 }}</textarea>
                                              </div>
                                                @error('description2')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                          <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Description 3<span class="text-danger">*</span></label>
                                                 <textarea type="text" name="description3" class="form-control tinymce" id="editor1" >{{ @$about->description3 }}</textarea>
                                              </div>
                                                @error('description3')
                                                  <p style="color:red;">{{ $message }}</p>
                                                @enderror
                                          </div>
                                        <div class="col-lg-12 col-md-12">
                                        <div class="form-group ">
                                            <label>Upload  image<span class="text-danger">*</span></label>
                                               <input type="file" class="form-control" name="image">
                                                @if(!empty(@$about->image))
                                                <img src="{{url('images/'.@$about->image ) }}" width="150px">
                                                @else
                                                @endif
                                                @error('image')
                                                        <p  style="color:red;">{{ $message }}</p>
                                                    @enderror
                                            </div>
                                        </div>
                                        <div class="bank-details-btn ">
                                            <button type="submit" class="btn bank-cancel-btn me-2">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
