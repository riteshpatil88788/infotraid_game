<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\SattaMatka;
use Illuminate\Support\Facades\Auth;

class SattaMatkaController extends Controller
{
    public function index()
    {
       
        $data['title'] = 'Satta Matka';
        $data['sattaMatka'] = DB::table('satta_matkas')->where('id', 1)->first();
        if (!$data['sattaMatka']) {
            return response()->json(['status' => false, 'data' => [] , 'message' => 'Record not found']);
        }
    return response()->json(['status' => true, 'data' => $data, 'message' => 'Record Successfully']);
    }
    
}
