<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use DB;
use App\Models\KnowAbout;

class KnowAboutController extends Controller
{
 
    public function index(){
       
        $data['title'] = "Know About";
        $data['KnowAbouts'] = DB::table('know_abouts')->where('id',1)->first();
        if (!$data['KnowAbouts']) {
            return response()->json(['status' => false,  'data' => [] ,'message' => 'Record not found']);
        }
       return response()->json(['status' => true, 'data' => $data , 'message' => 'Record Successfully']);
    }

   



    
}
