<?php $__env->startSection('content'); ?>
<div class="page-wrapper" style="min-height: 366px;">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-xl-12"> 

                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Add <?php echo e($title); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="bank-inner-details">
                            <div class="row">
                                <div class="col-lg-12 col-md-12">
                                    <form id="formSubmit" action="<?php echo e(route('admin.matkaresult.store')); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                        <div class="col-lg-12 col-md-12">
                                              <div class="form-group ">
                                                 <label>Title<span class="text-danger">*</span></label>
                                                 <input type="text" name="title" class="form-control" id="title" value="<?php echo e(old('title')); ?>">
                                              </div>
                                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                  <p style="color:red;"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>
                                       
                                          <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Open Time<span class="text-danger">*</span></label>
                                                 <input type="time" name="firsttime" class="form-control" id="firsttime" value="<?php echo e(old('firsttime')); ?>">
                                              </div>
                                                <?php $__errorArgs = ['firsttime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                  <p style="color:red;"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>  
                                           <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Close Time<span class="text-danger">*</span></label>
                                                 <input type="time" name="lasttime" class="form-control" id="lasttime" value="<?php echo e(old('lasttime')); ?>">
                                              </div>
                                                <?php $__errorArgs = ['lasttime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                  <p style="color:red;"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>   
                                           <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Jodi Link<span class="text-danger">*</span></label>
                                                 <input type="text" name="jodi_url" class="form-control" id="jodi_url" value="<?php echo e(old('jodi_url')); ?>">
                                              </div>
                                                <?php $__errorArgs = ['jodi_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                  <p style="color:red;"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>   
                                           <div class="col-lg-12 col-md-12">
                                              <div class="form-group">
                                                 <label>Panel Link<span class="text-danger">*</span></label>
                                                 <input type="text" name="panel_url" class="form-control" id="panel_url" value="<?php echo e(old('panel_url')); ?>">
                                              </div>
                                                <?php $__errorArgs = ['panel_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                  <p style="color:red;"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                          </div>   
                                        </div>
                                        <div class="bank-details-btn ">
                                            <button type="submit" class="btn bank-cancel-btn me-2">Add <?php echo e($title); ?></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u901267388/domains/infotrain.shop/public_html/resources/views/admin/matka-result/create.blade.php ENDPATH**/ ?>