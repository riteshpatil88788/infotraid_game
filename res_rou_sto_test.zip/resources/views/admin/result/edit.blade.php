@extends('admin.layout.app')
@section('content')
<div class="page-wrapper" style="min-height: 366px;">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-xl-12">

                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Edit {{$title}}</h3>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="bank-inner-details">
                            <div class="row">
                           
                                <div class="col-lg-12 col-md-12">
                                    <form id="formSubmit" action="{{ route('admin.result.update')}}" method="post" enctype="multipart/form-data">
                                        @csrf
                                     <input type="hidden"  name="id" value="{{$result->id}}" />
                                     <div class="row">
                                     <div class="col-lg-12 col-md-12">
                                                <div class="form-group ">
                                                    <label>Game Name<span class="login-danger">*</span></label>
                                                    <select class="form-control" name="matka_result_id" id="selectcategory" required>
                                                        <option value="">Select Game</option>
                                                        @foreach($matkaresults as $matkaresult)
                                                        <option value="{{ $matkaresult->id }}" {{ $matkaresult->id == $result->matka_result_id ? 'selected' : '' }}>{{ $matkaresult->title }}</option>
                                                        @endforeach
                                                    </select>
                                                    @error('matka_result_id')
                                                    <p style="color:red;">{{ $message }}</p>
                                                    @enderror
                                                </div>
                                            </div>
                                          <div class="col-lg-12 col-md-12">
                                            <div class="form-group">
                                            <label>Patta1<span class="login-danger">*</span></label>
                                            <input type="text" name="patta1" class="form-control" id="patta1" value="{{ $result->patta1 }}" readonly>
                                                  @error('patta1')
                                                      <p style="color:red;">{{ $message }}</p>
                                                  @enderror
                                                <div>
                                            </div>
                                             <div class="col-lg-12 col-md-12">
                                            <div class="form-group">
                                            <label>Patta2<span class="login-danger">*</span></label>
                                            <input type="text" name="patta2" class="form-control" id="patta2" value="{{ $result->patta2 }}">
                                                  @error('patta2')
                                                      <p style="color:red;">{{ $message }}</p>
                                                  @enderror
                                                <div>
                                            </div>
                                        </div>
                                        </div>
                                        <div class="bank-details-btn ">
                                            <button type="submit" class="btn bank-cancel-btn me-2">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
